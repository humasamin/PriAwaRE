package problems;

public interface ObservationFunction<S,A,O> {

	public double observationProbability(A action, S statePrime, O observation);
	public O getObservation(A action, S statePrime);
}
