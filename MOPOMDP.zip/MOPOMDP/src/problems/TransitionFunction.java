package problems;

public interface TransitionFunction<S,A> {
	
	public double probabilityOfTransition(S state, A action, S statePrime);
	public double[] probabilityVector(S state, A action);
	public S nextState(S currentState, A action);
}
