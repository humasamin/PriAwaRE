package problems.vacuumcleaner;

import problems.EnumerableStates;


public class VacuumCleanerStates implements EnumerableStates<Integer> {

	public static final Integer S1 = new Integer(0);
	public static final Integer S2 = new Integer(1);
	public static final Integer S3 = new Integer(2);
	public static final Integer S4 =new Integer(3);
	
	public static final boolean DEBUG   = false;
	
	@Override
	public int numberOfStates() {
		// TODO Auto-generated method stub
		
		return 4;
	}

	@Override
	public int stateNumber(Integer identifier) {
		// TODO Auto-generated method stub
		return identifier.intValue();
	}

	@Override
	public Integer stateIdentifier(int number) {
		// TODO Auto-generated method stub
		if(DEBUG){
			System.out.print("Called state id retrieval: "+number);
		}
		if(number == 0){
			if(DEBUG) System.out.println(" (S1)");
			return VacuumCleanerStates.S1;
		}
		if(number == 1){
			if(DEBUG) System.out.println(" (S2)");
			return VacuumCleanerStates.S2;
		}
		if(number == 2){
			if(DEBUG) System.out.println(" (S3)");
			return VacuumCleanerStates.S3;
		}
		if(number == 3){
			if(DEBUG) System.out.println(" (S4)");
			return VacuumCleanerStates.S4;
		}
		System.err.println("Invalid Vacuum Cleaner State");
		return null;
		
	}

	@Override
	public boolean isTerminal(Integer identifier) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isTerminal(int number) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String printState(Integer identifier) {
		// TODO Auto-generated method stub
		if(identifier.intValue()==VacuumCleanerStates.S1.intValue()){
			return "S1";
		}
		if(identifier.intValue()==VacuumCleanerStates.S2.intValue()){
			return "S2";
		}
		if(identifier.intValue()==VacuumCleanerStates.S3.intValue()){
			return "S3";
		}
		if(identifier.intValue()==VacuumCleanerStates.S4.intValue()){
			return "S4";
		}
		return "UKNOWN STATE";
		
	}

	@Override
	public String[] stateList() {
		// TODO Auto-generated method stub
		String[] result = new String[this.numberOfStates()];
		for(int i=0; i<this.numberOfStates(); i++){
			result[i] = this.printState(this.stateIdentifier(i));
		}
		return result;
	}
	

}
