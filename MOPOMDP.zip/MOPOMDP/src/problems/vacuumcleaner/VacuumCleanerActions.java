package problems.vacuumcleaner;

import java.util.Random;

import globals.CentralStatics;
import problems.DiscreteActions;
import problems.tiger.TigerActions;

public class VacuumCleanerActions implements DiscreteActions<Integer, Integer>{

	public final static Integer CleanNight = new Integer(0);
	public final static Integer CleanEmpty = new Integer(1);
	
	private Integer[] all;
	
	public VacuumCleanerActions() {
		// TODO Auto-generated constructor stub
		this.all=new Integer[2];
		this.all[0]=CleanNight;
		this.all[1]=CleanEmpty;
		
	}
	
	@Override
	public boolean isDiscrete() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean validAction(Integer action) {
		// TODO Auto-generated method stub
		return action.intValue()==0||action.intValue()==1;
	}

	@Override
	public Integer randomAction() {
		// TODO Auto-generated method stub
		Random r = CentralStatics.getCentralRandom();
		if(r.nextBoolean()){
			return VacuumCleanerActions.CleanEmpty;
		} 
		else 
		{
			return VacuumCleanerActions.CleanNight;
		}
		
		
	}

	@Override
	public String printAction(Integer action) {
		// TODO Auto-generated method stub
		if(VacuumCleanerActions.CleanEmpty.intValue() == action.intValue()){
			return "CleanEmpty"; 
		}
		if(VacuumCleanerActions.CleanNight.intValue() == action.intValue()){
			return "CleanNight"; 
		}
		
		return "UKNOWN ACTION";
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public Integer actionIdentifier(int a) {
		// TODO Auto-generated method stub
		return this.all[a];
	}

	@Override
	public Integer[] allActions() {
		// TODO Auto-generated method stub
		return this.all;
	}

	@Override
	public Integer[] actionsInState(Integer state) {
		// TODO Auto-generated method stub
		return this.all;
	}

	@Override
	public int numberOfActionsInState(Integer state) {
		// TODO Auto-generated method stub
		return 2;
	}

}
