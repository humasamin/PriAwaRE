package problems.vacuumcleaner;

import problems.TransitionFunction;

public class VacuumCleanerTransitions implements TransitionFunction<Integer, Integer> {

	@Override
	public double probabilityOfTransition(Integer state, Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double[] probabilityVector(Integer state, Integer action) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer nextState(Integer currentState, Integer action) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
