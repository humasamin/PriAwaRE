package problems.rdm;

public class RDMTransitionProbability {
	
	double MC_MST[]= {0.9,0.8,0.75,0.7};
	double MR_MST[]= {0.4,0.45,0.4,0.45};
	
	
	double MC_RT[]= {0.45,0.47,0.35,0.3};
	double MR_RT[]= {0.9,0.75,0.8,0.65};
	
	
	double vec[];
	public static int random_int;
	public static int random_int1;
	public static int random_int2;
	public static int deviation;
	public static int deviation_timesteps;
	
	public RDMTransitionProbability() {
		// TODO Auto-generated constructor stub
	
		// TODO Auto-generated constructor stub
		
		vec=new double[4];
		
	}
	//stable scenario
	
	public double[] getCaseRT(int casenum)
	{
		
	    
		vec[0]=(MC_RT[casenum])*(MR_RT[casenum]);
		vec[1]=(MC_RT[casenum])*((1-MR_RT[casenum]));
		vec[2]=((1-MC_RT[casenum]))*(MR_RT[casenum]);
		vec[3]=((1-MC_RT[casenum]))*((1-MR_RT[casenum]));
		
		
		return vec;
		
	}
	
	///stable scenario
	public double[] getCaseMST(int casenum)
	{
		vec[0]=(MC_MST[casenum])*(MR_MST[casenum]);
		vec[1]=(MC_MST[casenum])*((1-MR_MST[casenum]));
		vec[2]=((1-MC_MST[casenum]))*(MR_MST[casenum]);
		vec[3]=((1-MC_MST[casenum]))*((1-MR_MST[casenum]));
		
		
		return vec;
		
	}
	



}
