package problems.rdm;

import java.util.Random;

import globals.CentralStatics;
import problems.DiscreteActions;
import problems.tiger.TigerActions;

public class RDMActions implements DiscreteActions<Integer,Integer> {
	
	public final static Integer MST = new Integer(0); //MST topology
	public final static Integer RT = new Integer(1);  //Redundant Topology
	
	private Integer[] all;
	
	public RDMActions()
	{
		this.all = new Integer[2];
		this.all[0] = RDMActions.MST;
		this.all[1] = RDMActions.RT;
		
	}

	@Override
	public boolean isDiscrete() {
		// TODO Auto-generated method stub
		return true;
	}

	/////Both MST and RT are valid actions to be taken???????
	@Override
	public boolean validAction(Integer action) {
		// TODO Auto-generated method stub
		return action.intValue()==0||action.intValue()==1;
	}

	@Override
	public Integer randomAction() {
		// TODO Auto-generated method stub
		
		
		int r = CentralStatics.getCentralRandom().nextInt(2);
		return this.actionIdentifier(r);
		
	}

	@Override
	public String printAction(Integer action) {
		// TODO Auto-generated method stub
		if(RDMActions.MST.intValue() == action.intValue()){
			return "MST"; 
		}
		if(RDMActions.RT.intValue() == action.intValue()){
			return "RT"; 
		}
		
		return "UKNOWN ACTION";
		
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public Integer actionIdentifier(int a) {
		// TODO Auto-generated method stub
		return this.all[a];
	}

	@Override
	public Integer[] allActions() {
		// TODO Auto-generated method stub
		return this.all;
	}

	@Override
	public Integer[] actionsInState(Integer state) {
		// TODO Auto-generated method stub
		return this.all;
	}

	@Override
	public int numberOfActionsInState(Integer state) {
		// TODO Auto-generated method stub
		return 2;
	}

}
