package problems.rdm;

import problems.DiscreteObservations;

public class RDMObservations implements DiscreteObservations<Integer>{
	
	public final static Integer O1 = new Integer(0);//RES<x and ANL<r
	public final static Integer O2 = new Integer(1);//RES<x and ANL in r_s
	public final static Integer O3 = new Integer(2);//RES<x and ANL>=s
	public final static Integer O4 = new Integer(3);//RES in x_y and ANL<r
	public final static Integer O5 = new Integer(4);//RES in x_y and ANL in r_s
	public final static Integer O6 = new Integer(5);//RES in x_y ANL >=s
	public final static Integer O7 = new Integer(6);//RES in y_z and ANL<r
	public final static Integer O8 = new Integer(7);//RES in y_z and ANL in r_s
	public final static Integer O9 = new Integer(8);//RES in y_z and ANL >=s
	
	private Integer[] allObs;
	
	public RDMObservations()
	{
		allObs = new Integer[]{O1,O2,O3,O4,O5,O6,O7,O8,O9};
	}
	
	@Override
	public boolean isDiscrete() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean validObservation(Integer action) {
		// TODO Auto-generated method stub
		return action.intValue()>=0 && action.intValue()<=8;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 9;
	}

	@Override
	public Integer[] allObservations() {
		// TODO Auto-generated method stub
		
		return allObs;
	}

	@Override
	public Integer observationIdentifier(int o) {
		// TODO Auto-generated method stub
		if(o<0||o>8){
			System.err.println("Observation number (RDM) out of range: "+o);
			return null;
		}
		return this.allObs[o];
	}

	@Override
	public String toString(Integer obs) {
		// TODO Auto-generated method stub
		int o = obs.intValue();
		String[] os = {"O1","O2","O3","O4","O5","O6","O7","O8","O9"};
		return os[obs];
	}

}
