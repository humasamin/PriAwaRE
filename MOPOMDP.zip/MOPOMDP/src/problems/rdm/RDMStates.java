package problems.rdm;

import problems.EnumerableStates;
import problems.maze20.Maze20States;
import problems.tiger.TigerStates;

public class RDMStates implements EnumerableStates<Integer>{
	
	public static final Integer S1  = new Integer(0); //MEC=T, MR=T
	public static final Integer S2  = new Integer(1); //MEC=T, MR=F
	public static final Integer S3  = new Integer(2); //MEC=F, MR=T
	public static final Integer S4  = new Integer(3); //MEC=F, MR=F
	private static RDMStates sts = null;
	
	public static final boolean DEBUG   = false;
	public Integer[] statesRDM;
	
	public RDMStates()
	{
		statesRDM=new Integer[4];
		statesRDM[0]=S1;
		statesRDM[1]=S2;
		statesRDM[2]=S3;
		statesRDM[3]=S4;
		
		
	}

	@Override
	public int numberOfStates() {
		// TODO Auto-generated method stub
		return 4;
	}
//need to change it
	@Override
	public int stateNumber(Integer identifier) {
		// TODO Auto-generated method stub
		int result = identifier.intValue();
		if(result<0||result>3){
			System.err.println("RDM state identifier not in range");
			return -1;
		}
		return result;
	}

	
	@Override
	public Integer stateIdentifier(int number) {
		// TODO Auto-generated method stub
		if(number<0||number>3){
			System.err.println("RDM state number not in range");
			return -1;
		}
		
		return this.statesRDM[number];
		
	}

	///S4 considered as terminal state ??????
	@Override
	public boolean isTerminal(Integer identifier) {
		// TODO Auto-generated method stub
		return identifier.equals(RDMStates.S4);
	}

	@Override
	public boolean isTerminal(int number) {
		// TODO Auto-generated method stub
		
		return this.isTerminal(this.stateIdentifier(number));
	}

	@Override
	public String printState(Integer identifier) {
		// TODO Auto-generated method stub
		String res="";
		if(identifier.intValue()<0||identifier.intValue()>3)
		{
			res= "UKNOWN STATE";
		}
		else
		{
			if(identifier.intValue()==RDMStates.S1.intValue()){
				res= "S1";
			}
			if(identifier.intValue()==RDMStates.S2.intValue()){
				res="S2";
			}
			if(identifier.intValue()==RDMStates.S3.intValue()){
				res="S3";
			}
			if(identifier.intValue()==RDMStates.S4.intValue()){
				res="S4";
			}
		}
		return res;
		
		
	}

	@Override
	public String[] stateList() {
		// TODO Auto-generated method stub
		String[] result = new String[this.numberOfStates()];
		for(int i=0; i<this.numberOfStates(); i++){
			result[i] = this.printState(this.stateIdentifier(i));
		}
		return result;
	}
	
	public static RDMStates getStates(){
		if(RDMStates.sts == null){
			RDMStates.sts = new RDMStates();
		}
		return RDMStates.sts;
	}
	

}
