
package problems.rdm;

import problems.DiscreteActions;
import problems.DiscreteObservations;
import problems.Mopomdp;


public class MORDM extends Mopomdp<Integer, Integer, Integer>{

	public MORDM(boolean obj3, double[] b0, double gamma){
		
		super(RDMStates.getStates(), RDMTransitions.getTransitions(), 
				new RDMActions(), new RDMRewards(obj3), //add dim/obj to reward
				new RDMObsFunction(), 
				new RDMObservations(), b0);
		
		this.finiteHorizon=false;
		this.discountFactor=gamma;
		this.horizon = Integer.MAX_VALUE;
		this.problemName+=""+this.numberOfObjectives()+"-objective RDM";
	}

	@Override
	public DiscreteActions<Integer,Integer> getActionSet(){
		return ((DiscreteActions<Integer,Integer>) this.actions);
	}

	@Override
	public DiscreteObservations<Integer> getObservationSet(){
		return ((DiscreteObservations<Integer>) this.omega);
	}
}
