package problems.rdm;

import problems.RewardFunction;

public class RDMRewards implements RewardFunction<Integer,Integer>{

	private boolean threeObjectives;
	
	public RDMRewards(boolean obj) {
		// TODO Auto-generated constructor stub
		threeObjectives=obj;
	}
	@Override
	public int numberOfObjectives() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public double[] expectedReward(Integer state, Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		
		//if previous state was MEC=true and MR=true i.e. S1 then regardless of the action , if statePrime is S1
		//then positive reward
		/*if(statePrime.equals(RDMStates.S1))//goal state to be achieved
		{
			//reward for two objectives  MEC and MR  rew[MEC, MR]
			double[] rew = {100.0,100.0};
			return rew;
		}
		//if statePrime is S4 then regardless of the previous state and action, negative reward
		else if(statePrime.equals(RDMStates.S4))
		{
			double[] rew= {-100.0,-100.0};
			return rew;
			
			
		}
		else if(state.equals(RDMStates.S2)&& action.equals(RDMActions.MST))
		{
			if(statePrime.equals(RDMStates.S2))
			{
				double[] rew= {0,-50};
				return rew;
			}
			
		}
		else if(state.equals(RDMStates.S2)&&action.equals(RDMActions.MST))
		{
			if(statePrime.equals(RDMStates.S3))
			{
				double[] rew= {-25,+25};
				return rew;
			}
		}
		else if(state.equals(RDMStates.S3)&&action.equals(RDMActions.MST))
		{
			if(statePrime.equals(RDMStates.S3))
			{
				double[] rew= {25,-25};
				return rew;
			}
		}
		else if(state.equals(RDMStates.S3)&&action.equals(RDMActions.MST))
		{
			if(statePrime.equals(RDMStates.S2))
			{
				double[] rew= {50,-50};
				return rew;
			}
		}
		else if(state.equals(RDMStates.S2)&&action.equals(RDMActions.RT))
		{
			if(statePrime.equals(RDMStates.S2))
			{
				double[] rew= {-25,50};
				return rew;
			}
		}
		
		else if(state.equals(RDMStates.S2)&&action.equals(RDMActions.RT))
		{
			if(statePrime.equals(RDMStates.S3))
			{
				double[] rew= {-50,50};
				return rew;
			}
		}
		
				
		else if(state.equals(RDMStates.S3)&& action.equals(RDMActions.RT))
		{
			if(statePrime.equals(RDMStates.S3))
			{
				double[] rew= {-50,0};
				return rew;
			}
			
		}
		
		else {
			double[] rew= {0,0};
			return rew;
					
		}
				
		return new double[] {0,0};*/
		
		
		double[] rew=null;
		if(statePrime.equals(RDMStates.S1)&& action.equals(RDMActions.MST))
		{
			rew=new double[]{90,80};
			//rew=new double[]{100,100};
		}
		else if(statePrime.equals(RDMStates.S2)&& action.equals(RDMActions.MST))
		{
			rew=new double[]{75,-50};
			//rew=new double[]{75,-50};
		}
		else if(statePrime.equals(RDMStates.S3)&& action.equals(RDMActions.MST))
		{
			rew=new double[]{-25,40};
			//rew=new double[]{50,-25};
		}
		else if(statePrime.equals(RDMStates.S4)&& action.equals(RDMActions.MST))
		{
			rew=new double[]{-30,-60};
			//rew=new double[]{-100,-100};
		}
		if(statePrime.equals(RDMStates.S1)&& action.equals(RDMActions.RT))
		{
			rew=new double[]{80,90};
			//rew=new double[]{100,100};
		}
		else if(statePrime.equals(RDMStates.S2)&& action.equals(RDMActions.RT))
		{
			rew=new double[]{40,-25};
			//rew=new double[]{-25,50};
		}
		else if(statePrime.equals(RDMStates.S3)&& action.equals(RDMActions.RT))
		{
			rew=new double[]{-50,75};
			//rew=new double[]{-50,75};
		}
		else if(statePrime.equals(RDMStates.S4)&& action.equals(RDMActions.RT))
		{
			rew=new double[]{-60,-30};
			//rew=new double[]{-100,-100};
		}
		
		
		return rew;
	}

	@Override
	public double[] expectedReward(Integer state, Integer action) {
		// TODO Auto-generated method stub
		
		double[] rew=null;
		if(state.equals(RDMStates.S1)&& action.equals(RDMActions.MST))
		{
			rew=new double[]{90,80};
			//rew=new double[]{100,100};
		}
		else if(state.equals(RDMStates.S2)&& action.equals(RDMActions.MST))
		{
			rew=new double[]{75,-50};
			//rew=new double[]{75,-50};
		}
		else if(state.equals(RDMStates.S3)&& action.equals(RDMActions.MST))
		{
			rew=new double[]{-25,40};
			//rew=new double[]{50,-25};
		}
		else if(state.equals(RDMStates.S4)&& action.equals(RDMActions.MST))
		{
			rew=new double[]{-30,-60};
			//rew=new double[]{-100,-100};
		}
		if(state.equals(RDMStates.S1)&& action.equals(RDMActions.RT))
		{
			rew=new double[]{80,90};
			//rew=new double[]{100,100};
		}
		else if(state.equals(RDMStates.S2)&& action.equals(RDMActions.RT))
		{
			rew=new double[]{40,-25};
			//rew=new double[]{-25,50};
		}
		else if(state.equals(RDMStates.S3)&& action.equals(RDMActions.RT))
		{
			rew=new double[]{-50,75};
			//rew=new double[]{-50,75};
		}
		else if(state.equals(RDMStates.S4)&& action.equals(RDMActions.RT))
		{
			rew=new double[]{-60,-30};
			//rew=new double[]{-100,-100};
		}
		
		
		return rew;
	}

	@Override
	public double[] getReward(Integer state, Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		return this.expectedReward(state, action, statePrime);
	}

	@Override
	public double[] getReward(Integer state, Integer action) {
		// TODO Auto-generated method stub
		return this.expectedReward(state, action);
	}

	@Override
	public double[] minRewards() {
		// TODO Auto-generated method stub
		double[] rew = {50, 50};
		return rew;
		
	}

}
