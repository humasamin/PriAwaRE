package problems.rdm;

import java.util.Random;

import globals.CentralStatics;
import problems.ObservationFunction;
import problems.tiger.TigerObservations;
import problems.tiger.TigerStates;

public class RDMObsFunction implements ObservationFunction<Integer, Integer, Integer>{

	@Override
	public double observationProbability(Integer action, Integer statePrime, Integer observation) {
		// TODO Auto-generated method stub
		
		//Case 1
		//P(O|Action=MST,State=S1)
		if(statePrime.equals(RDMStates.S1)&&action.equals(RDMActions.MST)){
			
			if(observation.equals(RDMObservations.O1)){
				return 0.048;
			} 
			else if(observation.equals(RDMObservations.O2)){
				return 0.128;
			}
			else if(observation.equals(RDMObservations.O3)){
				return 0.624;
			}
			else if(observation.equals(RDMObservations.O4)){
				return 0.009;
			}
			else if(observation.equals(RDMObservations.O5)){
				return 0.0024;
			}
			else if(observation.equals(RDMObservations.O6)){
				return 0.117;
			}
			else if(observation.equals(RDMObservations.O7)){
				return 0.003;
			}
			else if(observation.equals(RDMObservations.O8)){
				return 0.008;
			}
			else if(observation.equals(RDMObservations.O9)){
				return 0.039;
			}
		}
		
		//Case 2
		//P(O|Action=MST,State=S2)
				if(statePrime.equals(RDMStates.S2)&&action.equals(RDMActions.MST)){
					if(observation.equals(RDMObservations.O1)){
						return 0.096;
					} 
					else if(observation.equals(RDMObservations.O2)){
						return 0.16;
					}
					else if(observation.equals(RDMObservations.O3)){
						return 0.544;
					}
					else if(observation.equals(RDMObservations.O4)){
						return 0.018;
					}
					else if(observation.equals(RDMObservations.O5)){
						return 0.03;
					}
					else if(observation.equals(RDMObservations.O6)){
						return 0.102;
					}
					else if(observation.equals(RDMObservations.O7)){
						return 0.006;
					}
					else if(observation.equals(RDMObservations.O8)){
						return 0.01;
					}
					else if(observation.equals(RDMObservations.O9)){
						return 0.034;
					}
				}
				
				
				//Case 3
				//P(O|Action=MST,State=S3)
						if(statePrime.equals(RDMStates.S3)&&action.equals(RDMActions.MST)){
							if(observation.equals(RDMObservations.O1)){
								return 0.0432;
							} 
							else if(observation.equals(RDMObservations.O2)){
								return 0.1152;
							}
							else if(observation.equals(RDMObservations.O3)){
								return 0.5616;
							}
							else if(observation.equals(RDMObservations.O4)){
								return 0.0108;
							}
							else if(observation.equals(RDMObservations.O5)){
								return 0.0288;
							}
							else if(observation.equals(RDMObservations.O6)){
								return 0.1404;
							}
							else if(observation.equals(RDMObservations.O7)){
								return 0.006;
							}
							else if(observation.equals(RDMObservations.O8)){
								return 0.016;
							}
							else if(observation.equals(RDMObservations.O9)){
								return 0.078;
							}
						}
						
						//Case 4
						//P(O|Action=MST,State=S4)
								if(statePrime.equals(RDMStates.S4)&&action.equals(RDMActions.MST)){
									if(observation.equals(RDMObservations.O1)){
										return 0.0864;
									} 
									else if(observation.equals(RDMObservations.O2)){
										return 0.144;
									}
									else if(observation.equals(RDMObservations.O3)){
										return 0.4896;
									}
									else if(observation.equals(RDMObservations.O4)){
										return 0.0216;
									}
									else if(observation.equals(RDMObservations.O5)){
										return 0.036;
									}
									else if(observation.equals(RDMObservations.O6)){
										return 0.1224;
									}
									else if(observation.equals(RDMObservations.O7)){
										return 0.012;
									}
									else if(observation.equals(RDMObservations.O8)){
										return 0.02;
									}
									else if(observation.equals(RDMObservations.O9)){
										return 0.068;
									}
								}
								
								//Case 5
								//P(O|Action=RT,State=S1)
								if(statePrime.equals(RDMStates.S1)&&action.equals(RDMActions.RT)){
									if(observation.equals(RDMObservations.O1)){
										return 0.039;
									} 
									else if(observation.equals(RDMObservations.O2)){
										return 0.117;
									}
									else if(observation.equals(RDMObservations.O3)){
										return 0.624;
									}
									else if(observation.equals(RDMObservations.O4)){
										return 0.008;
									}
									else if(observation.equals(RDMObservations.O5)){
										return 0.024;
									}
									else if(observation.equals(RDMObservations.O6)){
										return 0.128;
									}
									else if(observation.equals(RDMObservations.O7)){
										return 0.003;
									}
									else if(observation.equals(RDMObservations.O8)){
										return 0.009;
									}
									else if(observation.equals(RDMObservations.O9)){
										return 0.048;
									}
								}
								
								//Case 6
								//P(O|Action=RT,State=S2)
								if(statePrime.equals(RDMStates.S2)&&action.equals(RDMActions.RT)){
									if(observation.equals(RDMObservations.O1)){
										return 0.078;
									} 
									else if(observation.equals(RDMObservations.O2)){
										return 0.1404;
									}
									else if(observation.equals(RDMObservations.O3)){
										return 0.5616;
									}
									else if(observation.equals(RDMObservations.O4)){
										return 0.016;
									}
									else if(observation.equals(RDMObservations.O5)){
										return 0.0288;
									}
									else if(observation.equals(RDMObservations.O6)){
										return 0.1552;
									}
									else if(observation.equals(RDMObservations.O7)){
										return 0.006;
									}
									else if(observation.equals(RDMObservations.O8)){
										return 0.0108;
									}
									else if(observation.equals(RDMObservations.O9)){
										return 0.0432;
									}
								}
								
								//Case 7
								//P(O|Action=RT,State=S3)
								if(statePrime.equals(RDMStates.S3)&&action.equals(RDMActions.RT)){
									if(observation.equals(RDMObservations.O1)){
										return 0.034;
									} 
									else if(observation.equals(RDMObservations.O2)){
										return 0.102;
									}
									else if(observation.equals(RDMObservations.O3)){
										return 0.544;
									}
									else if(observation.equals(RDMObservations.O4)){
										return 0.01;
									}
									else if(observation.equals(RDMObservations.O5)){
										return 0.03;
									}
									else if(observation.equals(RDMObservations.O6)){
										return 0.16;
									}
									else if(observation.equals(RDMObservations.O7)){
										return 0.006;
									}
									else if(observation.equals(RDMObservations.O8)){
										return 0.018;
									}
									else if(observation.equals(RDMObservations.O9)){
										return 0.096;
									}
								}
								
								//Case 8
								//P(O|Action=RT,State=S4)
								if(statePrime.equals(RDMStates.S4)&&action.equals(RDMActions.RT)){
									if(observation.equals(RDMObservations.O1)){
										return 0.068;
									} 
									else if(observation.equals(RDMObservations.O2)){
										return 0.1224;
									}
									else if(observation.equals(RDMObservations.O3)){
										return 0.4896;
									}
									else if(observation.equals(RDMObservations.O4)){
										return 0.02;
									}
									else if(observation.equals(RDMObservations.O5)){
										return 0.036;
									}
									else if(observation.equals(RDMObservations.O6)){
										return 0.144;
									}
									else if(observation.equals(RDMObservations.O7)){
										return 0.012;
									}
									else if(observation.equals(RDMObservations.O8)){
										return 0.0216;
									}
									else if(observation.equals(RDMObservations.O9)){
										return 0.0864;
									}
								}
								
		return 0.0;
	}

	@Override
	public Integer getObservation(Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		
		Integer obs=null;
		
		double rec_sMEC =CentralStatics.getCentralRandom().nextDouble();
		double anl_sMR = CentralStatics.getCentralRandom().nextDouble();
		/*if(action.equals(RDMActions.MST)&&statePrime.equals(RDMStates.S1))
		{
			
		}*/
		/*if(rec_sMEC<0.80&& anl_sMR<0.08)
		{
			//return the observation
			obs=RDMObservations.O1;
			
			
		}
		else if(rec_sMEC<0.80 && (anl_sMR>=0.08&&anl_sMR<=0.4))
		{
			obs= RDMObservations.O2;
		}
		else if(rec_sMEC<0.80 && anl_sMR>0.4)
		{
			obs= RDMObservations.O3;
		}
		else if((rec_sMEC>=0.80&& rec_sMEC <=0.90) && anl_sMR<0.08)
		{
			//return the observation
			obs=RDMObservations.O4;
		}
		else if((rec_sMEC>=0.80&& rec_sMEC <=0.90) && (anl_sMR>=0.08&&anl_sMR<=0.4))
		{
			obs=RDMObservations.O5;
		}
		else if((rec_sMEC>=0.80&& rec_sMEC <=0.90) && anl_sMR>0.40)
		{
			obs=RDMObservations.O6;
		}
		else if((rec_sMEC>=0.90&& rec_sMEC<=1.0) && anl_sMR<0.08)
		{
			//return the observation
			obs=RDMObservations.O7;
		}
		else if((rec_sMEC>=0.90&& rec_sMEC<=1.0) && (anl_sMR>=0.08&&anl_sMR<=0.40))
		{
			obs=RDMObservations.O8;
		}
		else if((rec_sMEC>=0.90&& rec_sMEC<=1.0) && anl_sMR>0.40)
		{
			obs=RDMObservations.O9;
		}*/
		

			if(rec_sMEC<0.70&& anl_sMR<0.08)
			{
				//return the observation
				obs=RDMObservations.O1;
				
			}
			else if(rec_sMEC<0.70 && (anl_sMR>=0.08&&anl_sMR<=0.4))
			{
				obs= RDMObservations.O2;
			}
			else if(rec_sMEC<0.70 && anl_sMR>0.4)
			{
				obs= RDMObservations.O3;
			}
			else if((rec_sMEC>=0.70&& rec_sMEC <=0.80) && anl_sMR<0.08)
			{
				//return the observation
				obs=RDMObservations.O4;
			}
			else if((rec_sMEC>=0.70&& rec_sMEC <=0.80) && (anl_sMR>=0.08&&anl_sMR<=0.4))
			{
				obs=RDMObservations.O5;
			}
			else if((rec_sMEC>=0.70&& rec_sMEC <=0.80) && anl_sMR>0.40)
			{
				obs=RDMObservations.O6;
			}
			else if((rec_sMEC>=0.80&& rec_sMEC<=1.0) && anl_sMR<0.08)
			{
				//return the observation
				obs=RDMObservations.O7;
			}
			else if((rec_sMEC>=0.80&& rec_sMEC<=1.0) && (anl_sMR>=0.08&&anl_sMR<=0.40))
			{
				obs=RDMObservations.O8;
			}
			else if((rec_sMEC>=0.80&& rec_sMEC<=1.0) && anl_sMR>0.40)
			{
				obs=RDMObservations.O9;
			}
			
		
		
		//System.out.println("observation: "+obs.intValue());			
		return obs;
	}

}
