package problems.maze20;

import java.util.ArrayList;

public class Walls {

	private static Walls zeWalls=null;
	
	private boolean[] north;
	private boolean[] east;
	private boolean[] south;
	private boolean[] west;
	
	private Walls(){
		north = new boolean[20];
		east  = new boolean[20];
		south = new boolean[20];
		west  = new boolean[20];
		for(int i=0; i<20; i++){
			north[i] = false;
			east[i]  = false;
			south[i] = false;
			west[i]  = false;
		}
		int[] n = {1,2,4,8,11,14,15,16,17,18,19};
		int[] e = {4,6,7,9,11,12,14,19};
		int[] s = {0,1,2,3,4,6,7,9,13,16,19};
		int[] w = {0,5,7,8,10,12,13,15};
		for(int i=0; i<n.length; i++){
			north[n[i]]=true;
		}
		for(int i=0; i<e.length; i++){
			east[e[i]]=true;
		}
		for(int i=0; i<s.length; i++){
			south[s[i]]=true;
		}
		for(int i=0; i<w.length; i++){
			west[w[i]]=true;
		}
	}
	
	public boolean northSouth(int i){
		return north[i]&&south[i];
	}
	
	public boolean eastWest(int i){
		return east[i]&&west[i];
	}
	
	public boolean north(int i){
		return north[i];
	}
	
	public boolean east(int i){
		return east[i];
	}
	
	public boolean south(int i){
		return south[i];
	}
	
	public boolean west(int i){
		return west[i];
	}
	
	public static Walls theWalls(){
		if(Walls.zeWalls==null){
			Walls.zeWalls = new Walls();
		}
		return Walls.zeWalls;
	}
	
}
