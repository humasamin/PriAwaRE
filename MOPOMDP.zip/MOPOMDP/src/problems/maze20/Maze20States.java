package problems.maze20;

import problems.EnumerableStates;

public class Maze20States implements EnumerableStates<Integer>{

	public Integer[] statesMaze;
	private static Maze20States sts = null;
	
	private Maze20States(){
		this.statesMaze = new Integer[20];
		for(int i=0; i<20; i++){
			this.statesMaze[i] = new Integer(i);
		}
	}
	
	@Override
	public int numberOfStates() {
		return 20;
	}

	@Override
	public int stateNumber(Integer identifier) {
		int result = identifier.intValue();
		if(result<0||result>19){
			System.err.println("Maze20 state identifier not in range");
			return -1;
		}
		return result;
	}

	@Override
	public Integer stateIdentifier(int number) {
		if(number<0||number>19){
			System.err.println("Maze20 state number not in range");
			return null;
		}
		return this.statesMaze[number];
	}

	@Override
	public boolean isTerminal(Integer identifier) {
		return identifier.intValue()==7;
	}

	@Override
	public boolean isTerminal(int number) {
		return number==7;
	}

	@Override
	public String printState(Integer identifier) {
		if(identifier.intValue()<0||identifier.intValue()>19){
			return "UNKNOWN STATE";
		} else {
			if(identifier.intValue()<10){
				return "M0"+identifier.intValue();
			} else {
				return "M"+identifier.intValue();
			}
		}
	}

	@Override
	public String[] stateList() {
		String[] result = new String[20];
		for(int i=0; i<20; i++){
			result[i] = ""+i;
		}
		return result;
	}
	
	public static Maze20States getStates(){
		if(Maze20States.sts == null){
			Maze20States.sts = new Maze20States();
		}
		return Maze20States.sts;
	}

}
