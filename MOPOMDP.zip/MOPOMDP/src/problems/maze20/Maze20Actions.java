package problems.maze20;

import globals.CentralStatics;
import problems.DiscreteActions;

public class Maze20Actions implements DiscreteActions<Integer,Integer>{

	public final static Integer NORTH = new Integer(0);
	public final static Integer EAST = new Integer(1);
	public final static Integer SOUTH = new Integer(2);
	public final static Integer WEST = new Integer(3);
	public final static Integer SENSENS = new Integer(4);//North-South
	public final static Integer SENSEEW = new Integer(5);//East-West
	
	
	public Maze20Actions(){
		
	}
	
	@Override
	public boolean isDiscrete() {
		return true;
	}

	@Override
	public boolean validAction(Integer action) {
		return action.intValue()>=0&&action.intValue()<=5;
	}

	@Override
	public Integer randomAction() {
		int r = CentralStatics.getCentralRandom().nextInt(6);
		return this.actionIdentifier(r);
	}

	@Override
	public String printAction(Integer action) {
		if(action.intValue()==0){
			return "N";
		}
		if(action.intValue()==1){
			return "E";
		}
		if(action.intValue()==2){
			return "S";
		}
		if(action.intValue()==3){
			return "W";
		}
		if(action.intValue()==4){
			return "V";//Sense vertically, i.e., north-south
		}
		if(action.intValue()==5){
			return "H";//Sense horizontally, i.e., east-west
		}
		
		return null;
	}

	@Override
	public int size() {
		return 6;
	}

	@Override
	public Integer actionIdentifier(int a) {
		if(a==0){
			return Maze20Actions.NORTH;
		}
		if(a==1){
			return Maze20Actions.EAST;
		}
		if(a==2){
			return Maze20Actions.SOUTH;
		}
		if(a==3){
			return Maze20Actions.WEST;
		}
		if(a==4){
			return Maze20Actions.SENSENS;//Sense vertically, i.e., north-south
		}
		if(a==5){
			return Maze20Actions.SENSEEW;//Sense horizontally, i.e., east-west
		}
		return null;
	}

	@Override
	public Integer[] allActions() {
		Integer[] as = {NORTH, EAST, SOUTH, WEST, SENSENS, SENSEEW};
		return as;
	}

	@Override
	public Integer[] actionsInState(Integer state) {
		Integer[] as = {NORTH, EAST, SOUTH, WEST, SENSENS, SENSEEW};
		return as;
	}

	@Override
	public int numberOfActionsInState(Integer state) {
		return 6;
	}

}
