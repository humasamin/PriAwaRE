package problems.maze20;

import problems.DiscreteObservations;

public class Maze20Observations implements DiscreteObservations<Integer>{

	// Observations: numbered from 0 to 7
	public final static Integer NOOBS = new Integer(0);// no-observation (unknown)
	public final static Integer NOWALL = new Integer(1);//no wall
	public final static Integer NORTH = new Integer(2);
	public final static Integer SOUTH = new Integer(3);
	public final static Integer BOTHNS = new Integer(4);//North-South
	public final static Integer EAST = new Integer(5);
	public final static Integer WEST = new Integer(6);
	public final static Integer BOTHEW = new Integer(7);//East-West
	

	
	@Override
	public boolean isDiscrete() {
		return true;
	}

	@Override
	public boolean validObservation(Integer action) {
		return action.intValue()>=0 && action.intValue()<=7;
	}

	@Override
	public int size() {
		return 8;
	}

	@Override
	public Integer[] allObservations() {
		Integer[] os = {NOOBS, NOWALL, NORTH, SOUTH, BOTHNS, EAST, WEST, BOTHEW};
		return os;
	}

	@Override
	public Integer observationIdentifier(int o) {
		if(o<0||o>7){
			System.err.println("Observation number (Maze20) out of range: "+o);
			return null;
		}
		Integer[] os = {NOOBS, NOWALL, NORTH, SOUTH, BOTHNS, EAST, WEST, BOTHEW};
		return os[o];
	}

	public String toString(Integer obs){
		int o = obs.intValue();
		String[] os = {"NOOBS", "NOWALL", "NORTH", "SOUTH", "BOTHNS", "EAST", "WEST", "BOTHEW"};
		return os[o];
	}
	
}
