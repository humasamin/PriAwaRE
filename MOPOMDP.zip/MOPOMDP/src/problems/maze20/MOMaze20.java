package problems.maze20;

import problems.DiscreteActions;
import problems.DiscreteObservations;
import problems.Mopomdp;

public class MOMaze20 extends Mopomdp<Integer, Integer, Integer> {

	//Infinite horizon discounted MO Maze20 (extending Hauskrecht 2000)
	public MOMaze20(boolean obj3, double[] b0, double gamma){
		
		super(Maze20States.getStates(), Maze20Transitions.getTransitions(), 
				new Maze20Actions(), new Maze20Rewards(obj3), 
				new Maze20ObsFunction(), 
				new Maze20Observations(), b0);
		
		this.finiteHorizon=false;
		this.discountFactor=gamma;
		this.horizon = Integer.MAX_VALUE;
		this.problemName+=""+this.numberOfObjectives()+"-objective Maze20";
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public DiscreteActions<Integer,Integer> getActionSet(){
		return ((DiscreteActions<Integer,Integer>) this.actions);
	}
	
	@Override
	public DiscreteObservations<Integer> getObservationSet(){
		return ((DiscreteObservations<Integer>) this.omega);
	}
}
