package problems;

public interface DiscreteObservations<O> extends Observations<O> {
	public int size();
	public O[] allObservations();
	public O   observationIdentifier(int o);
	public String toString(O obs);
}
