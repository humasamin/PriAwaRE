package problems;

public interface RewardFunction<S,A> {
	
	public int numberOfObjectives();
	public double[] expectedReward(S state, A action, S statePrime);//For planning
	public double[] expectedReward(S state, A action);//For planning
	public double[] getReward(S state, A action, S statePrime);//Actual reward for simulation
	public double[] getReward(S state, A action);//Actual reward for simulation
	public double[] minRewards();//minimal rewards for each dimension
}
