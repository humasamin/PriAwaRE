package problems;

public interface DiscreteActions<A,S> extends Actions<A> {

	public int size();
	public A actionIdentifier(int a);
	public A[] allActions();
	public A[] actionsInState(S state);
	public int numberOfActionsInState(S state);
}
