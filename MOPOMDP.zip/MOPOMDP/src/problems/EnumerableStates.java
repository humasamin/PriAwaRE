package problems;

public interface EnumerableStates<T> {

	public int numberOfStates();
	public int stateNumber(T identifier);
	public T   stateIdentifier(int number);
	public boolean  isTerminal(T identifier);
	public boolean  isTerminal(int number);
	public String   printState(T identifier);
	public String[] stateList();
}
