package problems.rdmthreeobjectives;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class RDMConfiguration {
	
	public static double MC_MST[];
	public static double MR_MST[];
	public static double MP_MST[];
	
	public static double MC_RT[];
	public static double MR_RT[];
	public static double MP_RT[];
	
	public static int nsamples;
	public static double precision;
	public static long maxtime;
	
	public static int deviation_timesteps_min;
	public static int deviation_timesteps_max;
	
	public static int deviation_min;
	public static int deviation_max;
	
	
	
	
	
	public static double rewards_mec_mst[];
	public static double rewards_mec_rt[];
	
	public static double rewards_mr_mst[];
	public static double rewards_mr_rt[];
	
	public static double rewards_mp_mst[];
	public static double rewards_mp_rt[];
	
	public static double[] min_rewards;
	
	
	public RDMConfiguration() {
		// TODO Auto-generated constructor stub
		
		
		JSONParser parser = new JSONParser();
		

		try {
			Object obj1 = parser.parse(new FileReader("rdm3configuration.json"));
			

			JSONObject jsonObject = (JSONObject) obj1;
		

			JSONArray mc_mst = (JSONArray) jsonObject.get("MC_MST");			
			JSONArray mr_mst = (JSONArray) jsonObject.get("MR_MST");
			JSONArray mp_mst = (JSONArray) jsonObject.get("MP_MST");
			
			JSONArray mc_rt = (JSONArray) jsonObject.get("MC_RT");			
			JSONArray mr_rt = (JSONArray) jsonObject.get("MR_RT");
			JSONArray mp_rt = (JSONArray) jsonObject.get("MP_RT");
			
			
			MC_MST=new double[8];
			MR_MST=new double[8];
			MP_MST=new double[8];
			
			MC_RT=new double[8];
			MR_RT=new double[8];
			MP_RT=new double[8];
			
					
			
			for(int i=0;i<mc_mst.size();i++)
			{
			     MC_MST[i]=(double) mc_mst.get(i);
			     MR_MST[i]=(double) mr_mst.get(i);
			     MP_MST[i]=(double) mp_mst.get(i);
				
				//System.out.println(MC_MST[i]+"  "+MR_MST[i]+"  "+MP_MST[i]);
			}
			
			//System.out.println();
			
			for(int i=0;i<mc_rt.size();i++)
			{
			     MC_RT[i]=(double) mc_rt.get(i);
			     MR_RT[i]=(double) mr_rt.get(i);
			     MP_RT[i]=(double) mp_rt.get(i);
				
			    // System.out.println(MC_RT[i]+"  "+MR_RT[i]+"  "+MP_RT[i]);
			}
			
			//System.out.println();
			
			String sampleset = (String) jsonObject.get("sampleset");
			nsamples=(int)Integer.parseInt(sampleset);
			//System.out.println(nsamples);
			
			String prec = (String) jsonObject.get("precision");
			precision=(double)Double.parseDouble(prec);
			//System.out.println(precision);
			
			String maxtim = (String) jsonObject.get("maxtime");
			maxtime=(long)Long.parseLong(maxtim);
			//System.out.println(maxtime);
			
			String dev_timemin = (String) jsonObject.get("deviation_timesteps_min");
			deviation_timesteps_min=(int)Integer.parseInt(dev_timemin);
			
			String dev_timemax = (String) jsonObject.get("deviation_timesteps_max");
			deviation_timesteps_max=(int)Integer.parseInt(dev_timemax);
			
			String dev_min = (String) jsonObject.get("deviation_min");
			deviation_min=(int)Integer.parseInt(dev_min);
			
			String dev_max = (String) jsonObject.get("deviation_max");
			deviation_max=(int)Integer.parseInt(dev_max);
			
			//System.out.println("deviation");
			//System.out.println(deviation_timesteps_min+"  "+deviation_timesteps_max+" "+deviation_min+ " "+deviation_max);
			
			JSONArray r_mc_mst = (JSONArray) jsonObject.get("rewards_mec_mst");			
			JSONArray r_mr_mst = (JSONArray) jsonObject.get("rewards_mr_mst");
			JSONArray r_mp_mst = (JSONArray) jsonObject.get("rewards_mp_mst");
			
			JSONArray r_mc_rt = (JSONArray) jsonObject.get("rewards_mec_rt");			
			JSONArray r_mr_rt = (JSONArray) jsonObject.get("rewards_mr_rt");
			JSONArray r_mp_rt = (JSONArray) jsonObject.get("rewards_mp_rt");
			
			JSONArray min_rew = (JSONArray) jsonObject.get("min_rewards");
			
			rewards_mec_mst=new double[8];
			rewards_mr_mst=new double[8];
			rewards_mp_mst=new double[8];
			
			rewards_mec_rt=new double[8];
			rewards_mr_rt=new double[8];
			rewards_mp_rt=new double[8];
			
			min_rewards=new double[3];
			
			for(int i=0;i<min_rew.size();i++)
			{
			     min_rewards[i]=(double) min_rew.get(i);
			    
				
			     System.out.println(min_rewards[i]);
			}
			
			
			for(int i=0;i<r_mc_mst.size();i++)
			{
			     rewards_mec_mst[i]=(double) r_mc_mst.get(i);
			     rewards_mr_mst[i]=(double) r_mr_mst.get(i);
			     rewards_mp_mst[i]=(double) r_mp_mst.get(i);
				
			     System.out.println(rewards_mec_mst[i]+"  "+rewards_mr_mst[i]+"  "+rewards_mp_mst[i]);
			}
			
			for(int i=0;i<r_mc_rt.size();i++)
			{
			     rewards_mec_rt[i]=(double) r_mc_rt.get(i);
			     rewards_mr_rt[i]=(double) r_mr_rt.get(i);
			     rewards_mp_rt[i]=(double) r_mp_rt.get(i);
				
			    System.out.println(rewards_mec_rt[i]+"  "+rewards_mr_rt[i]+"  "+rewards_mp_rt[i]);
			}
			
			
		

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		catch(ParseException pe)
		{
			pe.printStackTrace();
		}

		
		
		
		
	}
	
	

}
