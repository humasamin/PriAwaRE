package problems.rdmthreeobjectives;

import problems.DiscreteActions;
import problems.DiscreteObservations;
import problems.Mopomdp;
import problems.rdm.RDMActions;
import problems.rdm.RDMObsFunction;
import problems.rdm.RDMObservations;
import problems.rdm.RDMRewards;
import problems.rdm.RDMStates;
import problems.rdm.RDMTransitions;

public class MORDMThree extends Mopomdp<Integer, Integer, Integer> {

	public MORDMThree(boolean obj3, double[] b0, double gamma) {

		super(RDMStatesThree.getStates(), RDMTransitionsThree.getTransitions(), new RDMActionsThree(),
				new RDMRewardsThree(obj3), // add dim/obj to reward
				new RDMObsFunctionThree(), new RDMObservationsThree(), b0);

		this.finiteHorizon = false;
		this.discountFactor = gamma;
		this.horizon = Integer.MAX_VALUE;
		this.problemName += "" + this.numberOfObjectives() + "-objective RDM";
	}

	@Override
	public DiscreteActions<Integer, Integer> getActionSet() {
		return ((DiscreteActions<Integer, Integer>) this.actions);
	}

	@Override
	public DiscreteObservations<Integer> getObservationSet() {
		return ((DiscreteObservations<Integer>) this.omega);
	}

}
