package problems.rdmthreeobjectives.connected;

import problems.EnumerableStates;
import problems.rdm.RDMStates;

public class RDMStatesThree implements EnumerableStates<Integer>{

	//Check these states from pomdp configuration file
	public static final Integer S1  = new Integer(0); //MC=T, MR=T, MP=T
	public static final Integer S2  = new Integer(1); //MC=T, MR=T, MP=F
	public static final Integer S3  = new Integer(2); //MC=T, MR=F, MP=T
	public static final Integer S4  = new Integer(3); //MC=T, MR=F, MP=F
	public static final Integer S5  = new Integer(4); //MC=F, MR=T, MP=T
	public static final Integer S6  = new Integer(5); //MC=F, MR=T, MP=F
	public static final Integer S7  = new Integer(6); //MC=F, MR=F, MP=T
	public static final Integer S8  = new Integer(7); //MC=F, MR=F, MP=F
	private static RDMStatesThree sts = null;
	
	public static final boolean DEBUG   = false;
	public Integer[] statesRDM;
	
	public RDMStatesThree()
	{
		statesRDM=new Integer[8];
		statesRDM[0]=S1;
		statesRDM[1]=S2;
		statesRDM[2]=S3;
		statesRDM[3]=S4;
		statesRDM[4]=S5;
		statesRDM[5]=S6;
		statesRDM[6]=S7;
		statesRDM[7]=S8;
	}
	
	@Override
	public int numberOfStates() {
		// TODO Auto-generated method stub
		return 8;
	}

	@Override
	public int stateNumber(Integer identifier) {
		// TODO Auto-generated method stub
		int result = identifier.intValue();
		if(result<0||result>7){
			System.err.println("RDM state identifier not in range");
			return -1;
		}
		return result;
		
	}

	@Override
	public Integer stateIdentifier(int number) {
		// TODO Auto-generated method stub
		if(number<0||number>7){
			System.err.println("RDM state number not in range");
			return -1;
		}
		
		return this.statesRDM[number];
	}

	@Override
	public boolean isTerminal(Integer identifier) {
		// TODO Auto-generated method stub
		return identifier.equals(RDMStatesThree.S1);
		//return false;
	}

	@Override
	public boolean isTerminal(int number) {
		// TODO Auto-generated method stub
		return this.isTerminal(this.stateIdentifier(number));
	}

	@Override
	public String printState(Integer identifier) {
		// TODO Auto-generated method stub
		String res="";
		if(identifier.intValue()<0||identifier.intValue()>7)
		{
			res= "UKNOWN STATE";
		}
		else
		{
			if(identifier.intValue()==RDMStatesThree.S1.intValue()){
				res= "S1";
			}
			if(identifier.intValue()==RDMStatesThree.S2.intValue()){
				res="S2";
			}
			if(identifier.intValue()==RDMStatesThree.S3.intValue()){
				res="S3";
			}
			if(identifier.intValue()==RDMStatesThree.S4.intValue()){
				res="S4";
			}
			
			if(identifier.intValue()==RDMStatesThree.S5.intValue()){
				res= "S5";
			}
			if(identifier.intValue()==RDMStatesThree.S6.intValue()){
				res="S6";
			}
			if(identifier.intValue()==RDMStatesThree.S7.intValue()){
				res="S7";
			}
			if(identifier.intValue()==RDMStatesThree.S8.intValue()){
				res="S8";
			}
		}
		return res;
	}

	@Override
	public String[] stateList() {
		// TODO Auto-generated method stub
		String[] result = new String[this.numberOfStates()];
		for(int i=0; i<this.numberOfStates(); i++){
			result[i] = this.printState(this.stateIdentifier(i));
		}
		return result;
	}
	
	public static RDMStatesThree getStates(){
		if(RDMStatesThree.sts == null){
			RDMStatesThree.sts = new RDMStatesThree();
		}
		return RDMStatesThree.sts;
	}
	

}
