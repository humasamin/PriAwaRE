package problems.rdmthreeobjectives.connected;

import rdm.management.Effector;
import rdm.management.NetworkManagment;
import rdm.management.Probe;
import rdm.network.Monitorables;

public class RDMSimConnector {
	
	public static NetworkManagment network_management;
	public static boolean refsetcreation=false;
	public static Probe probe;
	public static Effector effector;
	public static int timestep;
	public static Monitorables monitorables;
	
	public RDMSimConnector() {
		// TODO Auto-generated constructor stub
		
		network_management=new NetworkManagment();
		probe=network_management.getProbe();
		effector=network_management.getEffector();
		
	}
	

}
