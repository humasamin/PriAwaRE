package problems.rdmthreeobjectives.connected;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ResultsLog {

	public int rtnum,mstnum;
	public String res="";
	public String reg_mc="";
	public String reg_mr="";
	public String reg_mp="";

	
	//For logging satisfaction probabilities
	FileWriter fwmecsat;
	PrintWriter pwmecsat;
	FileWriter fwmrsat;
	PrintWriter pwmRsat;
	FileWriter fwmpsat;
	PrintWriter pwmpsat;

	FileWriter fw;
	PrintWriter pw;

	////Files for regression analysis
	FileWriter fwreg_mr;
	PrintWriter pwreg_mr;
	FileWriter fwreg_mc;
	PrintWriter pwreg_mc;
	FileWriter fwreg_mp;
	PrintWriter pwreg_mp;

	FileWriter fnum;
	PrintWriter pnum;




	public ResultsLog()
	{


		//For logging satisfaction probabilities
		try {

			fwmecsat=new FileWriter("RDMMECSAT.txt");
			pwmecsat=new PrintWriter(fwmecsat);
			fwmrsat=new FileWriter("RDMMRSAT.txt");
			pwmRsat=new PrintWriter(fwmrsat);
			fwmpsat=new FileWriter("RDMMPSAT.txt");
			pwmpsat=new PrintWriter(fwmpsat);


			fw=new FileWriter("Results.txt");
			pw=new PrintWriter(fw);
			fnum=new FileWriter("RDMTopologySelection.txt");
			pnum=new PrintWriter(fnum);


			fwreg_mr=new FileWriter("ResultsRegressionMR.txt");
			pwreg_mr=new PrintWriter(fwreg_mr);
			fwreg_mc=new FileWriter("ResultsRegressionMC.txt");
			pwreg_mc=new PrintWriter(fwreg_mc);
			fwreg_mp=new FileWriter("ResultsRegressionMP.txt");
			pwreg_mp=new PrintWriter(fwreg_mp);



		}
		catch(IOException ioex)
		{
			ioex.printStackTrace();
		}



	}
	
	

	/**
	 * Method to marginalize current belief value
	 */
	public void marginalizeCurrentBelief(MORDMThree mordm)
	{


		//////Current Belief Marginilization/////////////////////////////////////////////////////////////

		String MECSat="";
		double mecsat=mordm.currentBelief()[0]+mordm.currentBelief()[1]+mordm.currentBelief()[2]+mordm.currentBelief()[3];
		MECSat=MECSat+RDMSimConnector.timestep+" "+mecsat;	
		pwmecsat.println(MECSat);

		String MRSat="";
		double mRsat=mordm.currentBelief()[0]+mordm.currentBelief()[1]+mordm.currentBelief()[4]+mordm.currentBelief()[5];
		MRSat=MRSat+RDMSimConnector.timestep+" "+mRsat;	
		pwmRsat.println(MRSat);

		String MPSat="";
		double mpsat=mordm.currentBelief()[0]+mordm.currentBelief()[2]+mordm.currentBelief()[4]+mordm.currentBelief()[6];
		MPSat=MPSat+RDMSimConnector.timestep+" "+mpsat;	
		pwmpsat.println(MPSat);

		
		regressionAnalysisResults(mRsat, mecsat, mpsat);



	}



	public void outputResultLog(String results)
	{
		pw.println(results);




	}

	/**
	 * Method to close connection to log files
	 */
	public void closeConn() throws IOException
	{


		pw.flush();						
		pwmecsat.flush();
		pwmRsat.flush();
		pwmpsat.flush();


		pwreg_mr.flush();
		pwreg_mc.flush();
		pwreg_mp.flush();

		pwreg_mr.close();
		pwreg_mc.close();
		pwreg_mp.close();
		fwreg_mr.close();
		fwreg_mc.close();
		fwreg_mp.close();

		pnum.println("RT: "+rtnum);
		pnum.println("MST: "+mstnum);
		pnum.flush();
		pnum.close();
		fnum.close();

	}
	
	/**
	 * Method to evaluate results for Regression analysis  
	 */
	public void regressionAnalysisResults(double mRsat,double mecsat,double mpsat)
	{
		
		
		//Get Monitorable values from simulator
		RDMSimConnector.monitorables=RDMSimConnector.network_management.getMonitorables();
		////regression code
		reg_mr=reg_mr+RDMSimConnector.monitorables.getActiveLinks();
		reg_mc=reg_mc+RDMSimConnector.monitorables.getBandwidthConsumption();
		reg_mp=reg_mp+RDMSimConnector.monitorables.getTimeToWrite();
		
		////////////////////////////////////////////////////////////////////////////////
		//regression analysis results

		reg_mr=reg_mr+","+mRsat;
		reg_mc=reg_mc+","+mecsat;
		reg_mp=reg_mp+","+mpsat;

		pwreg_mr.println(reg_mr);
		pwreg_mc.println(reg_mc);
		pwreg_mp.println(reg_mp);

		reg_mc="";
		reg_mr="";
		reg_mp="";
	}

}
