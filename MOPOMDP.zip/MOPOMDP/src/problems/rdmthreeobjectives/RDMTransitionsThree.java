package problems.rdmthreeobjectives;

import java.util.ArrayList;
import java.util.Random;

import globals.CentralStatics;
import problems.TransitionFunction;
import problems.rdm.RDMActions;
import problems.rdm.RDMStates;
import problems.rdm.RDMTransitions;

public class RDMTransitionsThree implements TransitionFunction<Integer, Integer> {

	private static RDMTransitionsThree trans = null;
	public static boolean stable_scenario;
	double[] randomTrans;
	
	int casenum;

	@Override
	public double probabilityOfTransition(Integer state, Integer action, Integer statePrime) {
		// TODO Auto-generated method stub

		double[] vec = this.probabilityVector(state, action);
		return vec[statePrime.intValue()];

	}

	@Override
	public double[] probabilityVector(Integer state, Integer action) {
		// TODO Auto-generated method stub
		double[] vec = { 0, 0, 0, 0, 0, 0, 0, 0 };
		
		//double[] vec = { 0.125, 0.125, 0.125, 0.125, 0.125, 0.125, 0.125, 0.125 };
		
		RDMTransitionProb rtp=new RDMTransitionProb();
		//System.out.println("stable scenario:  "+stable_scenario);
		
		//randomTrans=new double[8];
		//System.out.println("stable:  "+stable_scenario);
	
		// For MST
		// First Case
		if (action.equals(RDMActionsThree.MST) && state.equals(RDMStatesThree.S1)) {

						
			if(stable_scenario==true)
			{
				casenum=0;
				vec=rtp.getCaseMST(casenum);
				//System.out.println("stable scenario:  "+stable_scenario);
			}
			else {
				
				casenum=0;
				vec=rtp.getCaseMSTDet(casenum);
				//vec=rtp.getCaseMST(casenum);
			
				
			}
				
		}

		// Second Case
		if (action.equals(RDMActionsThree.MST) && state.equals(RDMStatesThree.S2)) {
			
			if(stable_scenario==true)
			{

				casenum=1;
				vec=rtp.getCaseMST(casenum);
			}
			else {
				
				casenum=1;
				vec=rtp.getCaseMSTDet(casenum);
				//vec=rtp.getCaseMST(casenum);
				
				
			}

		}

		// third case

		if (action.equals(RDMActionsThree.MST) && state.equals(RDMStatesThree.S3)) {

			if(stable_scenario==true)
			{
				
			
				casenum=2;
				vec=rtp.getCaseMST(casenum);
			}
			else {
				
				casenum=2;
				vec=rtp.getCaseMSTDet(casenum);
				//vec=rtp.getCaseMST(casenum);
				
			}
		}

		// Fourth case

		if (action.equals(RDMActionsThree.MST) && state.equals(RDMStatesThree.S4)) {

			if(stable_scenario==true)
			{
				casenum=3;
				vec=rtp.getCaseMST(casenum);
			}
			else {
				casenum=3;
				vec=rtp.getCaseMSTDet(casenum);
				//vec=rtp.getCaseMST(casenum);
			}

		}

		// Fifth Case
		if (action.equals(RDMActionsThree.MST) && state.equals(RDMStatesThree.S5)) {
			
			if(stable_scenario==true)
			{

				casenum=4;
				vec=rtp.getCaseMST(casenum);
			}
			else {
				
				casenum=4;
				vec=rtp.getCaseMSTDet(casenum);
				//vec=rtp.getCaseMST(casenum);
				
			}

		}

		// Sixth Case
		if (action.equals(RDMActionsThree.MST) && state.equals(RDMStatesThree.S6)) {
			
		if(stable_scenario==true)
			{

			casenum=5;
			vec=rtp.getCaseMST(casenum);
			}
			else {
				
				casenum=5;
				vec=rtp.getCaseMSTDet(casenum);
				//vec=rtp.getCaseMST(casenum);
				
			}

		}

		// Seventh case

		if (action.equals(RDMActionsThree.MST) && state.equals(RDMStatesThree.S7)) {

			if(stable_scenario==true)
			{
				casenum=6;
				vec=rtp.getCaseMST(casenum);
			}
			else {
				
				casenum=6;
				vec=rtp.getCaseMSTDet(casenum);
				//vec=rtp.getCaseMST(casenum);
				
			}
		}

		// Eighth case

		if (action.equals(RDMActionsThree.MST) && state.equals(RDMStatesThree.S8)) {
			if(stable_scenario==true)
		    {

				casenum=7;
				vec=rtp.getCaseMST(casenum);
			}
			else {
				
				casenum=7;
				vec=rtp.getCaseMSTDet(casenum);
				//vec=rtp.getCaseMST(casenum);
			}

		}
		
		
			
		

		// For RT
		// First Case
		if (action.equals(RDMActionsThree.RT) && state.equals(RDMStatesThree.S1)) {

			if(stable_scenario==true) {
				
				casenum=0;
				vec=rtp.getCaseRT(casenum);
				
			}else {
					
					casenum=0;
					//vec=rtp.getCaseRTDet(casenum);
					vec=rtp.getCaseRT(casenum);
			}
			
		}

		// Second Case
		if (action.equals(RDMActionsThree.RT) && state.equals(RDMStatesThree.S2)) {

			
			
			if(stable_scenario==true) {
				
				casenum=1;
				vec=rtp.getCaseRT(casenum);
				
			}else {
					
					casenum=1;
					//vec=rtp.getCaseRTDet(casenum);
					vec=rtp.getCaseRT(casenum);
			}

		}

		// third case

		if (action.equals(RDMActionsThree.RT) && state.equals(RDMStatesThree.S3)) {

			
			
			if(stable_scenario==true) {
				
				casenum=2;
				vec=rtp.getCaseRT(casenum);
				
			}else {
					
					casenum=2;
					//vec=rtp.getCaseRTDet(casenum);
					vec=rtp.getCaseRT(casenum);
			}
		}

		// Fourth case

		if (action.equals(RDMActionsThree.RT) && state.equals(RDMStatesThree.S4)) {

			
			
			
			if(stable_scenario==true) {
				casenum=3;
				vec=rtp.getCaseRT(casenum);
				
				
			}else {
					
					casenum=3;
					//vec=rtp.getCaseRTDet(casenum);
					vec=rtp.getCaseRT(casenum);
			}
		}

		// Fifth Case
		if (action.equals(RDMActionsThree.RT) && state.equals(RDMStatesThree.S5)) {

			
			
			if(stable_scenario==true) {
				casenum=4;
				vec=rtp.getCaseRT(casenum);
			}else {
					
					casenum=4;
					//vec=rtp.getCaseRTDet(casenum);
					vec=rtp.getCaseRT(casenum);
			}

		}

		// Sixth Case
		if (action.equals(RDMActionsThree.RT) && state.equals(RDMStatesThree.S6)) {

			
			
			
			if(stable_scenario==true) {
				
				casenum=5;
				vec=rtp.getCaseRT(casenum);
				
			}else {
					
					casenum=5;
					//vec=rtp.getCaseRTDet(casenum);
					vec=rtp.getCaseRT(casenum);
			}

		}

		// Seventh case

		if (action.equals(RDMActionsThree.RT) && state.equals(RDMStatesThree.S7)) {

			
			
			if(stable_scenario==true) {
				
				casenum=6;
				vec=rtp.getCaseRT(casenum);
				
				
			}else {
					
					casenum=6;
					//vec=rtp.getCaseRTDet(casenum);
					vec=rtp.getCaseRT(casenum);
			}
		}

		// Eighth case

		if (action.equals(RDMActionsThree.RT) && state.equals(RDMStatesThree.S8)) {

			
			
			if(stable_scenario==true) {
				casenum=7;
				vec=rtp.getCaseRT(casenum);
				
			}else {
					
					casenum=7;
					//vec=rtp.getCaseRTDet(casenum);
					vec=rtp.getCaseRT(casenum);
			}

		}

		return vec;

	}

	@Override
	public Integer nextState(Integer currentState, Integer action) {
		// TODO Auto-generated method stub

		// Exceptional case to avoid nullpointer exception
		if (action == null) {
			return currentState;
		}

		double r = CentralStatics.getCentralRandom().nextDouble();

		double[] vec = this.probabilityVector(currentState, action);
		//System.out.println("r: "+r);
		double prob = 0.0;
		RDMStatesThree s = RDMStatesThree.getStates(); // returns an object of RDMStates type

		for (int i = 0; i < vec.length; i++) {

			prob += vec[i];

			if (r <= prob) {

				if (i == RDMStatesThree.S1.intValue()) {

					return RDMStatesThree.S1;
				}
				if (i == RDMStatesThree.S2.intValue()) {

					return RDMStatesThree.S2;
				}
				if (i == RDMStatesThree.S3.intValue()) {

					return RDMStatesThree.S3;
				}
				if (i == RDMStatesThree.S4.intValue()) {

					return RDMStatesThree.S4;
				}

				if (i == RDMStatesThree.S5.intValue()) {

					return RDMStatesThree.S5;
				}
				if (i == RDMStatesThree.S6.intValue()) {

					return RDMStatesThree.S6;
				}
				if (i == RDMStatesThree.S7.intValue()) {

					return RDMStatesThree.S7;
				}
				if (i == RDMStatesThree.S8.intValue()) {

					return RDMStatesThree.S8;
				}
			}
		}

		return null;

	}

	// Method to return an object of RDMTransitions class
	public static RDMTransitionsThree getTransitions() {
		if (RDMTransitionsThree.trans == null) {
			RDMTransitionsThree.trans = new RDMTransitionsThree();
		}
		return RDMTransitionsThree.trans;
	}

}
