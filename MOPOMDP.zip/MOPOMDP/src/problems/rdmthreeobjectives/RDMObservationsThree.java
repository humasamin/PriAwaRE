package problems.rdmthreeobjectives;

import problems.DiscreteObservations;

public class RDMObservationsThree implements DiscreteObservations<Integer> {

	public final static Integer O1 = new Integer(0);// RES<x and ANL<r
	public final static Integer O2 = new Integer(1);// RES<x and ANL in r_s
	public final static Integer O3 = new Integer(2);// RES<x and ANL>=s
	public final static Integer O4 = new Integer(3);// RES in x_y and ANL<r
	public final static Integer O5 = new Integer(4);// RES in x_y and ANL in r_s
	public final static Integer O6 = new Integer(5);// RES in x_y ANL >=s
	public final static Integer O7 = new Integer(6);// RES in y_z and ANL<r
	public final static Integer O8 = new Integer(7);// RES in y_z and ANL in r_s
	public final static Integer O9 = new Integer(8);// RES in y_z and ANL >=s
	public final static Integer O10 = new Integer(9);// RES<x and ANL<r
	public final static Integer O11 = new Integer(10);// RES<x and ANL in r_s
	public final static Integer O12 = new Integer(11);// RES<x and ANL>=s
	public final static Integer O13 = new Integer(12);// RES in x_y and ANL<r
	public final static Integer O14 = new Integer(13);// RES in x_y and ANL in r_s
	public final static Integer O15 = new Integer(14);// RES in x_y ANL >=s
	public final static Integer O16 = new Integer(15);// RES in y_z and ANL<r
	public final static Integer O17 = new Integer(16);// RES in y_z and ANL in r_s
	public final static Integer O18 = new Integer(17);// RES in y_z and ANL >=s
	public final static Integer O19 = new Integer(18);// RES<x and ANL<r
	public final static Integer O20 = new Integer(19);// RES<x and ANL in r_s
	public final static Integer O21 = new Integer(20);// RES<x and ANL>=s
	public final static Integer O22 = new Integer(21);// RES in x_y and ANL<r
	public final static Integer O23 = new Integer(22);// RES in x_y and ANL in r_s
	public final static Integer O24 = new Integer(23);// RES in x_y ANL >=s
	public final static Integer O25 = new Integer(24);// RES in y_z and ANL<r
	public final static Integer O26 = new Integer(25);// RES in y_z and ANL in r_s
	public final static Integer O27 = new Integer(26);// RES in y_z and ANL >=s

	private Integer[] allObs;

	public RDMObservationsThree() {
		allObs = new Integer[] { O1, O2, O3, O4, O5, O6, O7, O8, O9, O10, O11, O12, O13, O14, O15, O16, O17, O18, O19,
				O20, O21, O22, O23, O24, O25, O26, O27 };
	}

	@Override
	public boolean isDiscrete() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean validObservation(Integer action) {
		// TODO Auto-generated method stub
		return action.intValue() >= 0 && action.intValue() <= 26;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 27;
	}

	@Override
	public Integer[] allObservations() {
		// TODO Auto-generated method stub
		return allObs;
	}

	@Override
	public Integer observationIdentifier(int o) {
		// TODO Auto-generated method stub
		if (o < 0 || o > 26) {
			System.err.println("Observation number (RDM) out of range: " + o);
			return null;
		}
		return this.allObs[o];
	}

	@Override
	public String toString(Integer obs) {
		// TODO Auto-generated method stub
		int o = obs.intValue();
		String[] os = { "O1", "O2", "O3", "O4", "O5", "O6", "O7", "O8", "O9", "O10", "O11", "O12", "O13", "O14", "O15",
				"O16", "O17", "O18", "O19", "O20", "O21", "O22", "O23", "O24", "O25", "O26", "O27" };
		return os[obs];
	}

}
