package problems.rdmthreeobjectives;

import globals.CentralStatics;
import problems.ObservationFunction;
import problems.rdm.RDMActions;
import problems.rdm.RDMObservations;
import problems.rdm.RDMStates;

public class RDMObsFunctionThree implements ObservationFunction<Integer, Integer, Integer> {

	@Override
	public double observationProbability(Integer action, Integer statePrime, Integer observation) {
		// TODO Auto-generated method stub

		// Case 1
		// P(O|Action=MST,State=S1)
		if (statePrime.equals(RDMStatesThree.S1) && action.equals(RDMActionsThree.MST)) {
		
			if (observation.equals(RDMObservationsThree.O1)) {
				return 0.03984;
			} else if (observation.equals(RDMObservationsThree.O2)) {
				return 0.00624;
			} else if (observation.equals(RDMObservationsThree.O3)) {
				return 0.00192;
			} else if (observation.equals(RDMObservationsThree.O4)) {
				return 0.10624;
			} else if (observation.equals(RDMObservationsThree.O5)) {
				return 0.01664;
			} else if (observation.equals(RDMObservationsThree.O6)) {
				return 0.00512;
			} else if (observation.equals(RDMObservationsThree.O7)) {
				return 0.51792;
			} else if (observation.equals(RDMObservationsThree.O8)) {
				return 0.08112;
			} else if (observation.equals(RDMObservationsThree.O9)) {
				return 0.02496;
			} 
			else if (observation.equals(RDMObservationsThree.O10)) {
				return 0.00747;
			} else if (observation.equals(RDMObservationsThree.O11)) {
				return 0.00117;
			} else if (observation.equals(RDMObservationsThree.O12)) {
				return 0.00036;
			} else if (observation.equals(RDMObservationsThree.O13)) {
				return 0.01992;
			} else if (observation.equals(RDMObservationsThree.O14)) {
				return 0.00312;
			} else if (observation.equals(RDMObservationsThree.O15)) {
				return 0.00096;
			} else if (observation.equals(RDMObservationsThree.O16)) {
				return 0.09711;
			} else if (observation.equals(RDMObservationsThree.O17)) {
				return 0.01521;
			} else if (observation.equals(RDMObservationsThree.O18)) {
				return 0.00468;
			} 
			else if (observation.equals(RDMObservationsThree.O19)) {
				return 0.00249;
			}

			else if (observation.equals(RDMObservationsThree.O20)) {
				return 0.00039;
			} else if (observation.equals(RDMObservationsThree.O21)) {
				return 0.00012;
			} else if (observation.equals(RDMObservationsThree.O22)) {
				return 0.00664;
			} else if (observation.equals(RDMObservationsThree.O23)) {
				return 0.00104;
			} else if (observation.equals(RDMObservationsThree.O24)) {
				return 0.00032;
			} else if (observation.equals(RDMObservationsThree.O25)) {
				return 0.03237;
			} else if (observation.equals(RDMObservationsThree.O26)) {
				return 0.00507;
			} else if (observation.equals(RDMObservationsThree.O27)) {
				return 0.00156;
			}

		}

		// Case 2
		// P(O|Action=MST,State=S2)
		if (statePrime.equals(RDMStatesThree.S2) && action.equals(RDMActionsThree.MST)) {
			if (observation.equals(RDMObservationsThree.O1)) {
				return 0.03216;
			} else if (observation.equals(RDMObservationsThree.O2)) {
				return 0.01104;
			} else if (observation.equals(RDMObservationsThree.O3)) {
				return 0.0048;
			} else if (observation.equals(RDMObservationsThree.O4)) {
				return 0.08576;
			} else if (observation.equals(RDMObservationsThree.O5)) {
				return 0.02944;
			} else if (observation.equals(RDMObservationsThree.O6)) {
				return 0.0128;
			} else if (observation.equals(RDMObservationsThree.O7)) {
				return 0.41808;
			} else if (observation.equals(RDMObservationsThree.O8)) {
				return 0.14352;
			} else if (observation.equals(RDMObservationsThree.O9)) {
				return 0.0624;
			}
						else if (observation.equals(RDMObservationsThree.O10)) {
				return 0.00603;
			} else if (observation.equals(RDMObservationsThree.O11)) {
				return 0.00207;
			} else if (observation.equals(RDMObservationsThree.O12)) {
				return 0.0009;
			} else if (observation.equals(RDMObservationsThree.O13)) {
				return 0.01608;
			} else if (observation.equals(RDMObservationsThree.O14)) {
				return 0.00552;
			} else if (observation.equals(RDMObservationsThree.O15)) {
				return 0.0024;
			} else if (observation.equals(RDMObservationsThree.O16)) {
				return 0.07839;
			} else if (observation.equals(RDMObservationsThree.O17)) {
				return 0.02691;
			} else if (observation.equals(RDMObservationsThree.O18)) {
				return 0.0117;
			} 
			else if (observation.equals(RDMObservationsThree.O19)) {
				return 0.00201;
			} else if (observation.equals(RDMObservationsThree.O20)) {
				return 0.00069;
			} else if (observation.equals(RDMObservationsThree.O21)) {
				return 0.0003;
			} else if (observation.equals(RDMObservationsThree.O22)) {
				return 0.00536;
			} else if (observation.equals(RDMObservationsThree.O23)) {
				return 0.00184;
			} else if (observation.equals(RDMObservationsThree.O24)) {
				return 0.0008;
			} else if (observation.equals(RDMObservationsThree.O25)) {
				return 0.02613;
			} else if (observation.equals(RDMObservationsThree.O26)) {
				return 0.00897;
			} else if (observation.equals(RDMObservationsThree.O27)) {
				return 0.0039;
			}
		}

		// Case 3
		// P(O|Action=MST,State=S3)
		if (statePrime.equals(RDMStatesThree.S3) && action.equals(RDMActionsThree.MST)) {
			
			if (observation.equals(RDMObservationsThree.O1)) {
				return 0.07968;
			} else if (observation.equals(RDMObservationsThree.O2)) {
				return 0.01248;
			} else if (observation.equals(RDMObservationsThree.O3)) {
				return 0.00384;
			} else if (observation.equals(RDMObservationsThree.O4)) {
				return 0.1328;
			} else if (observation.equals(RDMObservationsThree.O5)) {
				return 0.0208;
			} else if (observation.equals(RDMObservationsThree.O6)) {
				return 0.0064;
			} else if (observation.equals(RDMObservationsThree.O7)) {
				return 0.45152;
			} else if (observation.equals(RDMObservationsThree.O8)) {
				return 0.07072;
			} else if (observation.equals(RDMObservationsThree.O9)) {
				return 0.02176;
			} 
			else if (observation.equals(RDMObservationsThree.O10)) {
				return 0.01494;
			} else if (observation.equals(RDMObservationsThree.O11)) {
				return 0.00234;
			} else if (observation.equals(RDMObservationsThree.O12)) {
				return 0.00072;
			} else if (observation.equals(RDMObservationsThree.O13)) {
				return 0.0249;
			} else if (observation.equals(RDMObservationsThree.O14)) {
				return 0.0039;
			} else if (observation.equals(RDMObservationsThree.O15)) {
				return 0.0012;
			} else if (observation.equals(RDMObservationsThree.O16)) {
				return 0.08466;
			} else if (observation.equals(RDMObservationsThree.O17)) {
				return 0.01326;
			} else if (observation.equals(RDMObservationsThree.O18)) {
				return 0.00408;
			} 
			else if (observation.equals(RDMObservationsThree.O19)) {
				return 0.00498;
			} else if (observation.equals(RDMObservationsThree.O20)) {
				return 0.00078;
			} else if (observation.equals(RDMObservationsThree.O21)) {
				return 0.00024;
			} else if (observation.equals(RDMObservationsThree.O22)) {
				return 0.0083;
			} else if (observation.equals(RDMObservationsThree.O23)) {
				return 0.0013;
			} else if (observation.equals(RDMObservationsThree.O24)) {
				return 0.0004;
			} else if (observation.equals(RDMObservationsThree.O25)) {
				return 0.02822;
			} else if (observation.equals(RDMObservationsThree.O26)) {
				return 0.00442;
			} else if (observation.equals(RDMObservationsThree.O27)) {
				return 0.00136;
			}
		}

		// Case 4
		// P(O|Action=MST,State=S4)
		if (statePrime.equals(RDMStatesThree.S4) && action.equals(RDMActionsThree.MST)) {
			
			if (observation.equals(RDMObservationsThree.O1)) {
				return 0.06432;
			} else if (observation.equals(RDMObservationsThree.O2)) {
				return 0.02208;
			} else if (observation.equals(RDMObservationsThree.O3)) {
				return 0.0096;
			} else if (observation.equals(RDMObservationsThree.O4)) {
				return 0.1072;
			} else if (observation.equals(RDMObservationsThree.O5)) {
				return 0.0368;
			} else if (observation.equals(RDMObservationsThree.O6)) {
				return 0.016;
			} else if (observation.equals(RDMObservationsThree.O7)) {
				return 0.36448;
			} else if (observation.equals(RDMObservationsThree.O8)) {
				return 0.12512;
			} else if (observation.equals(RDMObservationsThree.O9)) {
				return 0.0544;
			}
			
			else if (observation.equals(RDMObservationsThree.O10)) {
				return 0.01206;
			} else if (observation.equals(RDMObservationsThree.O11)) {
				return 0.00414;
			} else if (observation.equals(RDMObservationsThree.O12)) {
				return 0.0018;
			} else if (observation.equals(RDMObservationsThree.O13)) {
				return 0.0201;
			} else if (observation.equals(RDMObservationsThree.O14)) {
				return 0.0069;
			} else if (observation.equals(RDMObservationsThree.O15)) {
				return 0.003;
			} else if (observation.equals(RDMObservationsThree.O16)) {
				return 0.06834;
			} else if (observation.equals(RDMObservationsThree.O17)) {
				return 0.02346;
			} else if (observation.equals(RDMObservationsThree.O18)) {
				return 0.0102;
			} 
			else if (observation.equals(RDMObservationsThree.O19)) {
				return 0.00402;
			} else if (observation.equals(RDMObservationsThree.O20)) {
				return 0.00138;
			} else if (observation.equals(RDMObservationsThree.O21)) {
				return 0.0006;
			} else if (observation.equals(RDMObservationsThree.O22)) {
				return 0.0067;
			} else if (observation.equals(RDMObservationsThree.O23)) {
				return 0.0023;
			} else if (observation.equals(RDMObservationsThree.O24)) {
				return 0.001;
			} else if (observation.equals(RDMObservationsThree.O25)) {
				return 0.02278;
			} else if (observation.equals(RDMObservationsThree.O26)) {
				return 0.00782;
			} else if (observation.equals(RDMObservationsThree.O27)) {
				return 0.0034;
			}

		}

		// Case 5
		// P(O|Action=MST,State=S5)
		if (statePrime.equals(RDMStatesThree.S5) && action.equals(RDMActionsThree.MST)) {
			
			if (observation.equals(RDMObservationsThree.O1)) {
				return 0.035856;
			} else if (observation.equals(RDMObservationsThree.O2)) {
				return 0.005616;
			} else if (observation.equals(RDMObservationsThree.O3)) {
				return 0.001728;
			} else if (observation.equals(RDMObservationsThree.O4)) {
				return 0.095616;
			} else if (observation.equals(RDMObservationsThree.O5)) {
				return 0.014976;
			} else if (observation.equals(RDMObservationsThree.O6)) {
				return 0.004608;
			} else if (observation.equals(RDMObservationsThree.O7)) {
				return 0.466128;
			} else if (observation.equals(RDMObservationsThree.O8)) {
				return 0.073008;
			} else if (observation.equals(RDMObservationsThree.O9)) {
				return 0.022464;
			}else if (observation.equals(RDMObservationsThree.O10)) {
				return 0.008964;
			} else if (observation.equals(RDMObservationsThree.O11)) {
				return 0.001404;
			} else if (observation.equals(RDMObservationsThree.O12)) {
				return 0.000432;
			} else if (observation.equals(RDMObservationsThree.O13)) {
				return 0.023904;
			} else if (observation.equals(RDMObservationsThree.O14)) {
				return 0.003744;
			} else if (observation.equals(RDMObservationsThree.O15)) {
				return 0.001152;
			} else if (observation.equals(RDMObservationsThree.O16)) {
				return 0.116532;
			} else if (observation.equals(RDMObservationsThree.O17)) {
				return 0.018252;
			} else if (observation.equals(RDMObservationsThree.O18)) {
				return 0.005616;
			}
			else if (observation.equals(RDMObservationsThree.O19)) {
				return 0.00498;
			} else if (observation.equals(RDMObservationsThree.O20)) {
				return 0.00078;
			} else if (observation.equals(RDMObservationsThree.O21)) {
				return 0.00024;
			} else if (observation.equals(RDMObservationsThree.O22)) {
				return 0.01328;
			} else if (observation.equals(RDMObservationsThree.O23)) {
				return 0.00208;
			} else if (observation.equals(RDMObservationsThree.O24)) {
				return 0.00064;
			} else if (observation.equals(RDMObservationsThree.O25)) {
				return 0.06474;
			} else if (observation.equals(RDMObservationsThree.O26)) {
				return 0.01014;
			} else if (observation.equals(RDMObservationsThree.O27)) {
				return 0.00312;
			}

		}

		// Case 6
		// P(O|Action=MST,State=S6)
		if (statePrime.equals(RDMStatesThree.S6) && action.equals(RDMActionsThree.MST)) {
			
			if (observation.equals(RDMObservationsThree.O1)) {
				return 0.028944;
			} else if (observation.equals(RDMObservationsThree.O2)) {
				return 0.009936;
			} else if (observation.equals(RDMObservationsThree.O3)) {
				return 0.00432;
			} else if (observation.equals(RDMObservationsThree.O4)) {
				return 0.077184;
			} else if (observation.equals(RDMObservationsThree.O5)) {
				return 0.026496;
			} else if (observation.equals(RDMObservationsThree.O6)) {
				return 0.01152;
			} else if (observation.equals(RDMObservationsThree.O7)) {
				return 0.376272;
			} else if (observation.equals(RDMObservationsThree.O8)) {
				return 0.129168;
			} else if (observation.equals(RDMObservationsThree.O9)) {
				return 0.05616;
			}
			else if (observation.equals(RDMObservationsThree.O10)) {
				return 0.007236;
			} else if (observation.equals(RDMObservationsThree.O11)) {
				return 0.002484;
			} else if (observation.equals(RDMObservationsThree.O12)) {
				return 0.00108;
			} else if (observation.equals(RDMObservationsThree.O13)) {
				return 0.019296;
			} else if (observation.equals(RDMObservationsThree.O14)) {
				return 0.006624;
			} else if (observation.equals(RDMObservationsThree.O15)) {
				return 0.00288;
			} else if (observation.equals(RDMObservationsThree.O16)) {
				return 0.094068;
			} else if (observation.equals(RDMObservationsThree.O17)) {
				return 0.032292;
			} else if (observation.equals(RDMObservationsThree.O18)) {
				return 0.01404;
			} 
			else if (observation.equals(RDMObservationsThree.O19)) {
				return 0.00402;
			} else if (observation.equals(RDMObservationsThree.O20)) {
				return 0.00138;
			} else if (observation.equals(RDMObservationsThree.O21)) {
				return 0.0006;
			} else if (observation.equals(RDMObservationsThree.O22)) {
				return 0.01072;
			} else if (observation.equals(RDMObservationsThree.O23)) {
				return 0.00368;
			} else if (observation.equals(RDMObservationsThree.O24)) {
				return 0.0016;
			} else if (observation.equals(RDMObservationsThree.O25)) {
				return 0.05226;
			} else if (observation.equals(RDMObservationsThree.O26)) {
				return 0.01794;
			} else if (observation.equals(RDMObservationsThree.O27)) {
				return 0.0078;
			}
		}

		// Case 7
		// P(O|Action=MST,State=S7)
		if (statePrime.equals(RDMStatesThree.S7) && action.equals(RDMActionsThree.MST)) {
			if (observation.equals(RDMObservationsThree.O1)) {
				return 0.071712;
			} else if (observation.equals(RDMObservationsThree.O2)) {
				return 0.011232;
			} else if (observation.equals(RDMObservationsThree.O3)) {
				return 0.003456;
			} else if (observation.equals(RDMObservationsThree.O4)) {
				return 0.11952;
			} else if (observation.equals(RDMObservationsThree.O5)) {
				return 0.01872;
			} else if (observation.equals(RDMObservationsThree.O6)) {
				return 0.00576;
			} else if (observation.equals(RDMObservationsThree.O7)) {
				return 0.406368;
			} else if (observation.equals(RDMObservationsThree.O8)) {
				return 0.063648;
			} else if (observation.equals(RDMObservationsThree.O9)) {
				return 0.019584;
			}
			else if (observation.equals(RDMObservationsThree.O10)) {
				return 0.017928;
			} else if (observation.equals(RDMObservationsThree.O11)) {
				return 0.002808;
			} else if (observation.equals(RDMObservationsThree.O12)) {
				return 0.000864;
			} else if (observation.equals(RDMObservationsThree.O13)) {
				return 0.02988;
			} else if (observation.equals(RDMObservationsThree.O14)) {
				return 0.00468;
			} else if (observation.equals(RDMObservationsThree.O15)) {
				return 0.00144;
			} else if (observation.equals(RDMObservationsThree.O16)) {
				return 0.101592;
			} else if (observation.equals(RDMObservationsThree.O17)) {
				return 0.015912;
			} else if (observation.equals(RDMObservationsThree.O18)) {
				return 0.004896;
			} 
			else if (observation.equals(RDMObservationsThree.O19)) {
				return 0.00996;
			} else if (observation.equals(RDMObservationsThree.O20)) {
				return 0.00156;
			} else if (observation.equals(RDMObservationsThree.O21)) {
				return 0.00048;
			} else if (observation.equals(RDMObservationsThree.O22)) {
				return 0.0166;
			} else if (observation.equals(RDMObservationsThree.O23)) {
				return 0.0026;
			} else if (observation.equals(RDMObservationsThree.O24)) {
				return 0.0008;
			} else if (observation.equals(RDMObservationsThree.O25)) {
				return 0.05644;
			} else if (observation.equals(RDMObservationsThree.O26)) {
				return 0.00884;
			} else if (observation.equals(RDMObservationsThree.O27)) {
				return 0.00272;
			}
		}

		// Case 8
		// P(O|Action=MST,State=S8)
		if (statePrime.equals(RDMStatesThree.S8) && action.equals(RDMActionsThree.MST)) {
			
			if (observation.equals(RDMObservationsThree.O1)) {
				return 0.057888;
			} else if (observation.equals(RDMObservationsThree.O2)) {
				return 0.019872;
			} else if (observation.equals(RDMObservationsThree.O3)) {
				return 0.00864;
			} else if (observation.equals(RDMObservationsThree.O4)) {
				return 0.09648;
			} else if (observation.equals(RDMObservationsThree.O5)) {
				return 0.03312;
			} else if (observation.equals(RDMObservationsThree.O6)) {
				return 0.0144;
			} else if (observation.equals(RDMObservationsThree.O7)) {
				return 0.328032;
			} else if (observation.equals(RDMObservationsThree.O8)) {
				return 0.112608;
			} else if (observation.equals(RDMObservationsThree.O9)) {
				return 0.04896;
			}
			else if (observation.equals(RDMObservationsThree.O10)) {
				return 0.014472;
			} else if (observation.equals(RDMObservationsThree.O11)) {
				return 0.004968;
			} else if (observation.equals(RDMObservationsThree.O12)) {
				return 0.00216;
			} else if (observation.equals(RDMObservationsThree.O13)) {
				return 0.02412;
			} else if (observation.equals(RDMObservationsThree.O14)) {
				return 0.00828;
			} else if (observation.equals(RDMObservationsThree.O15)) {
				return 0.0036;
			} else if (observation.equals(RDMObservationsThree.O16)) {
				return 0.082008;
			} else if (observation.equals(RDMObservationsThree.O17)) {
				return 0.028152;
			} else if (observation.equals(RDMObservationsThree.O18)) {
				return 0.01224;
			}
			else if (observation.equals(RDMObservationsThree.O19)) {
				return 0.00804;
			} else if (observation.equals(RDMObservationsThree.O20)) {
				return 0.00276;
			} else if (observation.equals(RDMObservationsThree.O21)) {
				return 0.0012;
			} else if (observation.equals(RDMObservationsThree.O22)) {
				return 0.0134;
			} else if (observation.equals(RDMObservationsThree.O23)) {
				return 0.0046;
			} else if (observation.equals(RDMObservationsThree.O24)) {
				return 0.002;
			} else if (observation.equals(RDMObservationsThree.O25)) {
				return 0.04556;
			} else if (observation.equals(RDMObservationsThree.O26)) {
				return 0.01564;
			} else if (observation.equals(RDMObservationsThree.O27)) {
				return 0.0068;
			}
		}
		
				//RT
				// Case 1
				// P(O|Action=RT,State=S1)
				if (statePrime.equals(RDMStatesThree.S1) && action.equals(RDMActionsThree.RT)) {
										
					if (observation.equals(RDMObservationsThree.O1)) {
						return 0.0312;
					} else if (observation.equals(RDMObservationsThree.O2)) {
						return 0.00585;
					} else if (observation.equals(RDMObservationsThree.O3)) {
						return 0.00195;
					} else if (observation.equals(RDMObservationsThree.O4)) {
						return 0.0936;
					} else if (observation.equals(RDMObservationsThree.O5)) {
						return 0.01755;
					} else if (observation.equals(RDMObservationsThree.O6)) {
						return 0.00585;
					} else if (observation.equals(RDMObservationsThree.O7)) {
						return 0.4992;
					} else if (observation.equals(RDMObservationsThree.O8)) {
						return 0.0936;
					} else if (observation.equals(RDMObservationsThree.O9)) {
						return 0.0312;
					} 
					else if (observation.equals(RDMObservationsThree.O10)) {
						return 0.0064;
					} else if (observation.equals(RDMObservationsThree.O11)) {
						return 0.0012;
					} else if (observation.equals(RDMObservationsThree.O12)) {
						return 0.0004;
					} else if (observation.equals(RDMObservationsThree.O13)) {
						return 0.0192;
					} else if (observation.equals(RDMObservationsThree.O14)) {
						return 0.0036;
					} else if (observation.equals(RDMObservationsThree.O15)) {
						return 0.0012;
					} else if (observation.equals(RDMObservationsThree.O16)) {
						return 0.1024;
					} else if (observation.equals(RDMObservationsThree.O17)) {
						return 0.0192;
					} else if (observation.equals(RDMObservationsThree.O18)) {
						return 0.0064;
					} 
					
					else if (observation.equals(RDMObservationsThree.O19)) {
						return 0.0024;
					} else if (observation.equals(RDMObservationsThree.O20)) {
						return 0.00045;
					} else if (observation.equals(RDMObservationsThree.O21)) {
						return 0.00015;
					} else if (observation.equals(RDMObservationsThree.O22)) {
						return 0.0072;
					} else if (observation.equals(RDMObservationsThree.O23)) {
						return 0.00135;
					} else if (observation.equals(RDMObservationsThree.O24)) {
						return 0.00045;
					} else if (observation.equals(RDMObservationsThree.O25)) {
						return 0.0384;
					} else if (observation.equals(RDMObservationsThree.O26)) {
						return 0.0072;
					} else if (observation.equals(RDMObservationsThree.O27)) {
						return 0.0024;
					}

				}
				
				
				//Re check it
				// Case :2
				// P(O|Action=RT,State=S2)
				if (statePrime.equals(RDMStatesThree.S2) && action.equals(RDMActionsThree.RT)) {
					
					if (observation.equals(RDMObservationsThree.O1)) {
						return 0.02457;
					} else if (observation.equals(RDMObservationsThree.O2)) {
						return 0.00975;
					} else if (observation.equals(RDMObservationsThree.O3)) {
						return 0.00468;
					} else if (observation.equals(RDMObservationsThree.O4)) {
						return 0.07371;
					} else if (observation.equals(RDMObservationsThree.O5)) {
						return 0.02925;
					} else if (observation.equals(RDMObservationsThree.O6)) {
						return 0.01404;
					} else if (observation.equals(RDMObservationsThree.O7)) {
						return 0.39312;
					} else if (observation.equals(RDMObservationsThree.O8)) {
						return 0.156;
					} else if (observation.equals(RDMObservationsThree.O9)) {
						return 0.07488;
					} 
					
					else if (observation.equals(RDMObservationsThree.O10)) {
						return 0.00504;
					} else if (observation.equals(RDMObservationsThree.O11)) {
						return 0.002;
					} else if (observation.equals(RDMObservationsThree.O12)) {
						return 0.00096;
					} else if (observation.equals(RDMObservationsThree.O13)) {
						return 0.01512;
					} else if (observation.equals(RDMObservationsThree.O14)) {
						return 0.006;
					} else if (observation.equals(RDMObservationsThree.O15)) {
						return 0.00288;
					} else if (observation.equals(RDMObservationsThree.O16)) {
						return 0.08064;
					} else if (observation.equals(RDMObservationsThree.O17)) {
						return 0.032;
					} else if (observation.equals(RDMObservationsThree.O18)) {
						return 0.01536;
					}
					

					else if (observation.equals(RDMObservationsThree.O19)) {
						return 0.00189;
					} else if (observation.equals(RDMObservationsThree.O20)) {
						return 0.00075;
					} else if (observation.equals(RDMObservationsThree.O21)) {
						return 0.00036;
					} else if (observation.equals(RDMObservationsThree.O22)) {
						return 0.00567;
					} else if (observation.equals(RDMObservationsThree.O23)) {
						return 0.00225;
					} else if (observation.equals(RDMObservationsThree.O24)) {
						return 0.00108;
					} else if (observation.equals(RDMObservationsThree.O25)) {
						return 0.03024;
					} else if (observation.equals(RDMObservationsThree.O26)) {
						return 0.012;
					} else if (observation.equals(RDMObservationsThree.O27)) {
						return 0.00576;
					}
				}
				
				// Case 3
				// P(O|Action=RT,State=S3)
				if (statePrime.equals(RDMStatesThree.S3) && action.equals(RDMActionsThree.RT)) {
					
					if (observation.equals(RDMObservationsThree.O1)) {
						return 0.0624;
					} else if (observation.equals(RDMObservationsThree.O2)) {
						return 0.0117;
					} else if (observation.equals(RDMObservationsThree.O3)) {
						return 0.0039;
					} else if (observation.equals(RDMObservationsThree.O4)) {
						return 0.11232;
					} else if (observation.equals(RDMObservationsThree.O5)) {
						return 0.02106;
					} else if (observation.equals(RDMObservationsThree.O6)) {
						return 0.00702;
					} else if (observation.equals(RDMObservationsThree.O7)) {
						return 0.44928;
					} else if (observation.equals(RDMObservationsThree.O8)) {
						return 0.08424;
					} else if (observation.equals(RDMObservationsThree.O9)) {
						return 0.02808;
					} 
					
					
					else if (observation.equals(RDMObservationsThree.O10)) {
						return 0.0128;
					} else if (observation.equals(RDMObservationsThree.O11)) {
						return 0.0024;
					} else if (observation.equals(RDMObservationsThree.O12)) {
						return 0.0008;
					} else if (observation.equals(RDMObservationsThree.O13)) {
						return 0.02304;
					} else if (observation.equals(RDMObservationsThree.O14)) {
						return 0.00432;
					} else if (observation.equals(RDMObservationsThree.O15)) {
						return 0.00144;
					} else if (observation.equals(RDMObservationsThree.O16)) {
						return 0.09216;
					} else if (observation.equals(RDMObservationsThree.O17)) {
						return 0.01728;
					} else if (observation.equals(RDMObservationsThree.O18)) {
						return 0.00576;
					} 
					else if (observation.equals(RDMObservationsThree.O19)) {
						return 0.0048;
					} else if (observation.equals(RDMObservationsThree.O20)) {
						return 0.0009;
					} else if (observation.equals(RDMObservationsThree.O21)) {
						return 0.0003;
					} else if (observation.equals(RDMObservationsThree.O22)) {
						return 0.00864;
					} else if (observation.equals(RDMObservationsThree.O23)) {
						return 0.00162;
					} else if (observation.equals(RDMObservationsThree.O24)) {
						return 0.00054;
					} else if (observation.equals(RDMObservationsThree.O25)) {
						return 0.03456;
					} else if (observation.equals(RDMObservationsThree.O26)) {
						return 0.00648;
					} else if (observation.equals(RDMObservationsThree.O27)) {
						return 0.00216;
					}

				}
				
				// Case :4
				// P(O|Action=RT,State=S4)
				if (statePrime.equals(RDMStatesThree.S4) && action.equals(RDMActionsThree.RT)) {
					
					if (observation.equals(RDMObservationsThree.O1)) {
						return 0.04914;
					} else if (observation.equals(RDMObservationsThree.O2)) {
						return 0.0195;
					} else if (observation.equals(RDMObservationsThree.O3)) {
						return 0.00936;
					} else if (observation.equals(RDMObservationsThree.O4)) {
						return 0.088452;
					} else if (observation.equals(RDMObservationsThree.O5)) {
						return 0.0351;
					} else if (observation.equals(RDMObservationsThree.O6)) {
						return 0.016848;
					} else if (observation.equals(RDMObservationsThree.O7)) {
						return 0.353808;
					} else if (observation.equals(RDMObservationsThree.O8)) {
						return 0.1404;
					} else if (observation.equals(RDMObservationsThree.O9)) {
						return 0.067392;
					}
					else if (observation.equals(RDMObservationsThree.O10)) {
						return 0.01008;
					} else if (observation.equals(RDMObservationsThree.O11)) {
						return 0.004;
					} else if (observation.equals(RDMObservationsThree.O12)) {
						return 0.00192;
					} else if (observation.equals(RDMObservationsThree.O13)) {
						return 0.018144;
					} else if (observation.equals(RDMObservationsThree.O14)) {
						return 0.0072;
					} else if (observation.equals(RDMObservationsThree.O15)) {
						return 0.003456;
					} else if (observation.equals(RDMObservationsThree.O16)) {
						return 0.072576;
					} else if (observation.equals(RDMObservationsThree.O17)) {
						return 0.0288;
					} else if (observation.equals(RDMObservationsThree.O18)) {
						return 0.013824;
					}
					
					else if (observation.equals(RDMObservationsThree.O19)) {
						return 0.00378;
					} else if (observation.equals(RDMObservationsThree.O20)) {
						return 0.0015;
					} else if (observation.equals(RDMObservationsThree.O21)) {
						return 0.00072;
					} else if (observation.equals(RDMObservationsThree.O22)) {
						return 0.006804;
					} else if (observation.equals(RDMObservationsThree.O23)) {
						return 0.0027;
					} else if (observation.equals(RDMObservationsThree.O24)) {
						return 0.001296;
					} else if (observation.equals(RDMObservationsThree.O25)) {
						return 0.027216;
					} else if (observation.equals(RDMObservationsThree.O26)) {
						return 0.0108;
					} else if (observation.equals(RDMObservationsThree.O27)) {
						return 0.005184;
					}

				}

				// Case 5
				// P(O|Action=RT,State=S1)
				if (statePrime.equals(RDMStatesThree.S5) && action.equals(RDMActionsThree.RT)) {
					
					if (observation.equals(RDMObservationsThree.O1)) {
						return 0.0272;
					} else if (observation.equals(RDMObservationsThree.O2)) {
						return 0.0051;
					} else if (observation.equals(RDMObservationsThree.O3)) {
						return 0.0017;
					} else if (observation.equals(RDMObservationsThree.O4)) {
						return 0.0816;
					} else if (observation.equals(RDMObservationsThree.O5)) {
						return 0.0153;
					} else if (observation.equals(RDMObservationsThree.O6)) {
						return 0.0051;
					} else if (observation.equals(RDMObservationsThree.O7)) {
						return 0.4352;
					} else if (observation.equals(RDMObservationsThree.O8)) {
						return 0.0816;
					} else if (observation.equals(RDMObservationsThree.O9)) {
						return 0.0272;
					} 
					else if (observation.equals(RDMObservationsThree.O10)) {
						return 0.008;
					} else if (observation.equals(RDMObservationsThree.O11)) {
						return 0.0015;
					} else if (observation.equals(RDMObservationsThree.O12)) {
						return 0.0005;
					} else if (observation.equals(RDMObservationsThree.O13)) {
						return 0.024;
					} else if (observation.equals(RDMObservationsThree.O14)) {
						return 0.0045;
					} else if (observation.equals(RDMObservationsThree.O15)) {
						return 0.0015;
					} else if (observation.equals(RDMObservationsThree.O16)) {
						return 0.128;
					} else if (observation.equals(RDMObservationsThree.O17)) {
						return 0.024;
					} else if (observation.equals(RDMObservationsThree.O18)) {
						return 0.008;
					}
					
					else if (observation.equals(RDMObservationsThree.O19)) {
						return 0.0048;
					} else if (observation.equals(RDMObservationsThree.O20)) {
						return 0.0009;
					} else if (observation.equals(RDMObservationsThree.O21)) {
						return 0.0003;
					} else if (observation.equals(RDMObservationsThree.O22)) {
						return 0.0144;
					} else if (observation.equals(RDMObservationsThree.O23)) {
						return 0.0027;
					} else if (observation.equals(RDMObservationsThree.O24)) {
						return 0.0009;
					} else if (observation.equals(RDMObservationsThree.O25)) {
						return 0.0768;
					} else if (observation.equals(RDMObservationsThree.O26)) {
						return 0.0144;
					} else if (observation.equals(RDMObservationsThree.O27)) {
						return 0.0048;
					}

				}
				
				// Case :6
				// P(O|Action=RT,State=S2)
				if (statePrime.equals(RDMStatesThree.S6) && action.equals(RDMActionsThree.RT)) {
					
					if (observation.equals(RDMObservationsThree.O1)) {
						return 0.02142;
					} else if (observation.equals(RDMObservationsThree.O2)) {
						return 0.0085;
					} else if (observation.equals(RDMObservationsThree.O3)) {
						return 0.00408;
					} else if (observation.equals(RDMObservationsThree.O4)) {
						return 0.06426;
					} else if (observation.equals(RDMObservationsThree.O5)) {
						return 0.0255;
					} else if (observation.equals(RDMObservationsThree.O6)) {
						return 0.01224;
					} else if (observation.equals(RDMObservationsThree.O7)) {
						return 0.34272;
					} else if (observation.equals(RDMObservationsThree.O8)) {
						return 0.136;
					} else if (observation.equals(RDMObservationsThree.O9)) {
						return 0.06528;
					}
					
					else if (observation.equals(RDMObservationsThree.O10)) {
						return 0.0063;
					} else if (observation.equals(RDMObservationsThree.O11)) {
						return 0.0025;
					} else if (observation.equals(RDMObservationsThree.O12)) {
						return 0.0012;
					} else if (observation.equals(RDMObservationsThree.O13)) {
						return 0.0189;
					} else if (observation.equals(RDMObservationsThree.O14)) {
						return 0.0075;
					} else if (observation.equals(RDMObservationsThree.O15)) {
						return 0.0036;
					} else if (observation.equals(RDMObservationsThree.O16)) {
						return 0.1008;
					} else if (observation.equals(RDMObservationsThree.O17)) {
						return 0.04;
					} else if (observation.equals(RDMObservationsThree.O18)) {
						return 0.0192;
					} else if (observation.equals(RDMObservationsThree.O19)) {
						return 0.00378;
					} else if (observation.equals(RDMObservationsThree.O20)) {
						return 0.0015;
					} else if (observation.equals(RDMObservationsThree.O21)) {
						return 0.00072;
					} else if (observation.equals(RDMObservationsThree.O22)) {
						return 0.01134;
					} else if (observation.equals(RDMObservationsThree.O23)) {
						return 0.0045;
					} else if (observation.equals(RDMObservationsThree.O24)) {
						return 0.00216;
					} else if (observation.equals(RDMObservationsThree.O25)) {
						return 0.06048;
					} else if (observation.equals(RDMObservationsThree.O26)) {
						return 0.024;
					} else if (observation.equals(RDMObservationsThree.O27)) {
						return 0.01152;
					}

				}
				
				// Case 7
				// P(O|Action=RT,State=S3)
				if (statePrime.equals(RDMStatesThree.S7) && action.equals(RDMActionsThree.RT)) {
					
					if (observation.equals(RDMObservationsThree.O1)) {
						return 0.0544;
					} else if (observation.equals(RDMObservationsThree.O2)) {
						return 0.0102;
					} else if (observation.equals(RDMObservationsThree.O3)) {
						return 0.0034;
					} else if (observation.equals(RDMObservationsThree.O4)) {
						return 0.09792;
					} else if (observation.equals(RDMObservationsThree.O5)) {
						return 0.01836;
					} else if (observation.equals(RDMObservationsThree.O6)) {
						return 0.00612;
					} else if (observation.equals(RDMObservationsThree.O7)) {
						return 0.39168;
					} else if (observation.equals(RDMObservationsThree.O8)) {
						return 0.07344;
					} else if (observation.equals(RDMObservationsThree.O9)) {
						return 0.02448;
					} 
					
					else if (observation.equals(RDMObservationsThree.O10)) {
						return 0.016;
					} else if (observation.equals(RDMObservationsThree.O11)) {
						return 0.003;
					} else if (observation.equals(RDMObservationsThree.O12)) {
						return 0.001;
					} else if (observation.equals(RDMObservationsThree.O13)) {
						return 0.0288;
					} else if (observation.equals(RDMObservationsThree.O14)) {
						return 0.0054;
					} else if (observation.equals(RDMObservationsThree.O15)) {
						return 0.0018;
					} else if (observation.equals(RDMObservationsThree.O16)) {
						return 0.1152;
					} else if (observation.equals(RDMObservationsThree.O17)) {
						return 0.0216;
					} else if (observation.equals(RDMObservationsThree.O18)) {
						return 0.0072;
					} 
					else if (observation.equals(RDMObservationsThree.O19)) {
						return 0.0096;
					} else if (observation.equals(RDMObservationsThree.O20)) {
						return 0.0018;
					} else if (observation.equals(RDMObservationsThree.O21)) {
						return 0.0006;
					} else if (observation.equals(RDMObservationsThree.O22)) {
						return 0.01728;
					} else if (observation.equals(RDMObservationsThree.O23)) {
						return 0.00324;
					} else if (observation.equals(RDMObservationsThree.O24)) {
						return 0.00108;
					} else if (observation.equals(RDMObservationsThree.O25)) {
						return 0.06912;
					} else if (observation.equals(RDMObservationsThree.O26)) {
						return 0.01296;
					} else if (observation.equals(RDMObservationsThree.O27)) {
						return 0.00432;
					}

				}
				
				// Case :8
				// P(O|Action=RT,State=S4)
				if (statePrime.equals(RDMStatesThree.S8) && action.equals(RDMActionsThree.RT)) {
					
					if (observation.equals(RDMObservationsThree.O1)) {
						return 0.04284;
					} else if (observation.equals(RDMObservationsThree.O2)) {
						return 0.017;
					} else if (observation.equals(RDMObservationsThree.O3)) {
						return 0.00816;
					} else if (observation.equals(RDMObservationsThree.O4)) {
						return 0.077112;
					} else if (observation.equals(RDMObservationsThree.O5)) {
						return 0.0306;
					} else if (observation.equals(RDMObservationsThree.O6)) {
						return 0.014688;
					} else if (observation.equals(RDMObservationsThree.O7)) {
						return 0.308448;
					} else if (observation.equals(RDMObservationsThree.O8)) {
						return 0.1224;
					} else if (observation.equals(RDMObservationsThree.O9)) {
						return 0.058752;
					} 
					else if (observation.equals(RDMObservationsThree.O10)) {
						return 0.0126;
					} else if (observation.equals(RDMObservationsThree.O11)) {
						return 0.005;
					} else if (observation.equals(RDMObservationsThree.O12)) {
						return 0.0024;
					} else if (observation.equals(RDMObservationsThree.O13)) {
						return 0.02268;
					} else if (observation.equals(RDMObservationsThree.O14)) {
						return 0.009;
					} else if (observation.equals(RDMObservationsThree.O15)) {
						return 0.00432;
					} else if (observation.equals(RDMObservationsThree.O16)) {
						return 0.09072;
					} else if (observation.equals(RDMObservationsThree.O17)) {
						return 0.036;
					} else if (observation.equals(RDMObservationsThree.O18)) {
						return 0.01728;
					}
					
					else if (observation.equals(RDMObservationsThree.O19)) {
						return 0.00756;
					} else if (observation.equals(RDMObservationsThree.O20)) {
						return 0.003;
					} else if (observation.equals(RDMObservationsThree.O21)) {
						return 0.00144;
					} else if (observation.equals(RDMObservationsThree.O22)) {
						return 0.013608;
					} else if (observation.equals(RDMObservationsThree.O23)) {
						return 0.0054;
					} else if (observation.equals(RDMObservationsThree.O24)) {
						return 0.002592;
					} else if (observation.equals(RDMObservationsThree.O25)) {
						return 0.054432;
					} else if (observation.equals(RDMObservationsThree.O26)) {
						return 0.0216;
					} else if (observation.equals(RDMObservationsThree.O27)) {
						return 0.010368;
					}

				}


		return 0;
	}

	@Override
	public Integer getObservation(Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		Integer obs = null;

		double rec_sMEC = CentralStatics.getCentralRandom().nextDouble();
		double anl_sMR = CentralStatics.getCentralRandom().nextDouble();
		double sMP = CentralStatics.getCentralRandom().nextDouble();

		if (rec_sMEC < 0.70 && anl_sMR < 0.08&& sMP<0.70) {
			// return the observation
			obs = RDMObservationsThree.O1;

		}
		else if (rec_sMEC < 0.70 && anl_sMR < 0.08&&(sMP>=0.70&&sMP<=0.90)) {
			// return the observation
			obs = RDMObservationsThree.O2;

		}  
		else if (rec_sMEC < 0.70 && anl_sMR < 0.08&& sMP>0.90) {
			// return the observation
			obs = RDMObservationsThree.O3;

		}  
		else if (rec_sMEC < 0.70 && (anl_sMR >= 0.08 && anl_sMR <= 0.4)&&sMP<0.70) {
			obs = RDMObservationsThree.O4;
		} 
		else if (rec_sMEC < 0.70 && (anl_sMR >= 0.08 && anl_sMR <= 0.4)&&(sMP>=0.70&&sMP<=0.90)) {
			obs = RDMObservationsThree.O5;
		}
		else if (rec_sMEC < 0.70 && (anl_sMR >= 0.08 && anl_sMR <= 0.4)&&sMP>0.90) {
			obs = RDMObservationsThree.O6;
		} 
		else if (rec_sMEC < 0.70 && anl_sMR > 0.4&&sMP<0.70) {
			obs = RDMObservationsThree.O7;
		} 
		else if (rec_sMEC < 0.70 && anl_sMR > 0.4&&(sMP>=0.70&&sMP<=0.90)) {
			obs = RDMObservationsThree.O8;
		} 
		else if (rec_sMEC < 0.70 && anl_sMR > 0.4&&sMP>0.90) {
			obs = RDMObservationsThree.O9;
		} 
		
		else if ((rec_sMEC >= 0.70 && rec_sMEC <= 0.80) && anl_sMR < 0.08&&sMP<0.70) {
			// return the observation
			obs = RDMObservationsThree.O10;
		}
		else if ((rec_sMEC >= 0.70 && rec_sMEC <= 0.80) && anl_sMR < 0.08&&(sMP>=0.70&&sMP<=0.90)) {
			// return the observation
			obs = RDMObservationsThree.O11;
		}
		else if ((rec_sMEC >= 0.70 && rec_sMEC <= 0.80) && anl_sMR < 0.08&&sMP>0.90) {
			// return the observation
			obs = RDMObservationsThree.O12;
		}
		
		else if ((rec_sMEC >= 0.70 && rec_sMEC <= 0.80) && (anl_sMR >= 0.08 && anl_sMR <= 0.4)&&sMP<0.70) {
			obs = RDMObservationsThree.O13;
		}
		else if ((rec_sMEC >= 0.70 && rec_sMEC <= 0.80) && (anl_sMR >= 0.08 && anl_sMR <= 0.4)&&(sMP>=0.70&&sMP<=0.90)) {
			obs = RDMObservationsThree.O14;
		}
		else if ((rec_sMEC >= 0.70 && rec_sMEC <= 0.80) && (anl_sMR >= 0.08 && anl_sMR <= 0.4)&&sMP>0.90) {
			obs = RDMObservationsThree.O15;
		}
		
		else if ((rec_sMEC >= 0.70 && rec_sMEC <= 0.80) && anl_sMR > 0.40&&sMP<0.70) {
			obs = RDMObservationsThree.O16;
		}
		else if ((rec_sMEC >= 0.70 && rec_sMEC <= 0.80) && anl_sMR > 0.40&&(sMP>=0.70&&sMP<=0.90)) {
			obs = RDMObservationsThree.O17;
		}
		else if ((rec_sMEC >= 0.70 && rec_sMEC <= 0.80) && anl_sMR > 0.40&&sMP>0.90) {
			obs = RDMObservationsThree.O18;
		}
		
		
		else if ((rec_sMEC >= 0.80 && rec_sMEC <= 1.0) && anl_sMR < 0.08&&sMP<0.70) {
			// return the observation
			obs = RDMObservationsThree.O19;
		} 
		else if ((rec_sMEC >= 0.80 && rec_sMEC <= 1.0) && anl_sMR < 0.08&&(sMP>=0.70&&sMP<=0.90)) {
			// return the observation
			obs = RDMObservationsThree.O20;
		} 
		else if ((rec_sMEC >= 0.80 && rec_sMEC <= 1.0) && anl_sMR < 0.08&&sMP>0.90) {
			// return the observation
			obs = RDMObservationsThree.O21;
		} 
		
		
		else if ((rec_sMEC >= 0.80 && rec_sMEC <= 1.0) && (anl_sMR >= 0.08 && anl_sMR <= 0.40)&&sMP<0.70) {
			obs = RDMObservationsThree.O22;
		} 
		else if ((rec_sMEC >= 0.80 && rec_sMEC <= 1.0) && (anl_sMR >= 0.08 && anl_sMR <= 0.40)&&(sMP>=0.70&&sMP<=0.90)) {
			obs = RDMObservationsThree.O23;
		} 
		else if ((rec_sMEC >= 0.80 && rec_sMEC <= 1.0) && (anl_sMR >= 0.08 && anl_sMR <= 0.40)&&sMP>0.90) {
			obs = RDMObservationsThree.O24;
		} 
		
		else if ((rec_sMEC >= 0.80 && rec_sMEC <= 1.0) && anl_sMR > 0.40&&sMP<0.70) {
			obs = RDMObservationsThree.O25;
		}
		else if ((rec_sMEC >= 0.80 && rec_sMEC <= 1.0) && anl_sMR > 0.40&&(sMP>=0.70&&sMP<=0.90)) {
			obs = RDMObservationsThree.O26;
		}
		else if ((rec_sMEC >= 0.80 && rec_sMEC <= 1.0) && anl_sMR > 0.40&&sMP>0.90) {
			obs = RDMObservationsThree.O27;
		}

		//System.out.println("observation: "+obs.intValue());
		return obs;
	}

}
