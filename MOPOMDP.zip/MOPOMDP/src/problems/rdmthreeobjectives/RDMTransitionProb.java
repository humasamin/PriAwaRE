package problems.rdmthreeobjectives;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



public class RDMTransitionProb {

	
	double MC_MST[];
	double MR_MST[];
	double MP_MST[];
	
	double MC_RT[];
	double MR_RT[];
	double MP_RT[];
	
	
	/*double MC_MST[]= {0.9,0.88,0.92,0.9,0.85,0.83,0.87,0.85};
	double MR_MST[]= {0.91,0.93,0.89,0.91,0.93,0.95,0.91,0.93};
	double MP_MST[]= {0.9,0.85,0.92,0.87,0.88,0.83,0.9,0.85};
	
	double MC_RT[]= {0.86,0.84,0.88,0.86,0.73,0.71,0.75,0.73};
	double MR_RT[]= {0.95,0.97,0.93,0.95,0.97,0.99,0.95,0.97};
	double MP_RT[]= {0.82,0.75,0.84,0.77,0.8,0.73,0.82,0.75};*/
	
	
	
	double vec[];
	public static int random_int;
	public static int random_int1;
	public static int random_int2;
	public static int deviation;
	public static int deviation_timesteps;
	
	public RDMTransitionProb() {
		// TODO Auto-generated constructor stub
		
		vec=new double[8];
		
		MC_MST=RDMConfiguration.MC_MST;
		MR_MST=RDMConfiguration.MR_MST;
		MP_MST=RDMConfiguration.MP_MST;
		
		MC_RT=RDMConfiguration.MC_RT;
		MR_RT=RDMConfiguration.MR_RT;
		MP_RT=RDMConfiguration.MP_RT;
		
				
		
	}
	
	
	public double[] getCaseRT(int casenum)
	{
		
		vec[0]=(MC_RT[casenum])*(MR_RT[casenum])*(MP_RT[casenum]);
		vec[1]=(MC_RT[casenum])*(MR_RT[casenum])*((1-MP_RT[casenum]));
		vec[2]=(MC_RT[casenum])*((1-MR_RT[casenum]))*(MP_RT[casenum]);
		vec[3]=(MC_RT[casenum])*((1-MR_RT[casenum]))*((1-MP_RT[casenum]));
		
		vec[4]=((1-MC_RT[casenum]))*(MR_RT[casenum])*(MP_RT[casenum]);
		vec[5]=((1-MC_RT[casenum]))*(MR_RT[casenum])*((1-MP_RT[casenum]));
		vec[6]=((1-MC_RT[casenum]))*((1-MR_RT[casenum]))*(MP_RT[casenum]);
		vec[7]=((1-MC_RT[casenum]))*((1-MR_RT[casenum]))*((1-MP_RT[casenum]));
		
		return vec;
		
	}
	
	///stable scenario
	public double[] getCaseMST(int casenum)
	{
		vec[0]=MC_MST[casenum]*MR_MST[casenum]*MP_MST[casenum];
		vec[1]=MC_MST[casenum]*MR_MST[casenum]*(1-MP_MST[casenum]);
		vec[2]=MC_MST[casenum]*(1-MR_MST[casenum])*MP_MST[casenum];
		vec[3]=MC_MST[casenum]*(1-MR_MST[casenum])*(1-MP_MST[casenum]);
		
		vec[4]=(1-MC_MST[casenum])*MR_MST[casenum]*MP_MST[casenum];
		vec[5]=(1-MC_MST[casenum])*MR_MST[casenum]*(1-MP_MST[casenum]);
		vec[6]=(1-MC_MST[casenum])*(1-MR_MST[casenum])*MP_MST[casenum];
		vec[7]=(1-MC_MST[casenum])*(1-MR_MST[casenum])*(1-MP_MST[casenum]);
		
	/*	System.out.println("Transistion probability");
		for(int i=0;i<vec.length;i++)
		{
			System.out.print(vec[i]+"  ");
		}
		System.out.println();*/
		
		return vec;
		
	}
	
	////detrimental scenario
	public double[] getCaseMSTDet(int casenum)
	{
		
		
		/*BigDecimal randval=BigDecimal.valueOf((double)random_int).divide(BigDecimal.valueOf(100.0));
		BigDecimal deviationvalue=BigDecimal.valueOf(MR_MST[casenum]).multiply(randval);
		//System.out.println(randval);
		
		BigDecimal sub_deviationvalue=BigDecimal.valueOf(MR_MST[casenum]).subtract(randval);
		
		BigDecimal f_probMR=BigDecimal.valueOf(1.0).subtract(BigDecimal.valueOf(MR_MST[casenum]));
		BigDecimal add_deviationvalue=f_probMR.add(randval);
		
		//System.out.println(MR_MST[casenum]+"   "+sub_deviationvalue.doubleValue()+"   "+add_deviationvalue.doubleValue());
		
		BigDecimal f_probMC=BigDecimal.valueOf(1.0).subtract(BigDecimal.valueOf(MC_MST[casenum]));
		BigDecimal f_probMP=BigDecimal.valueOf(1.0).subtract(BigDecimal.valueOf(MP_MST[casenum]));
		
		vec[0]=((BigDecimal.valueOf(MC_MST[casenum]).multiply(sub_deviationvalue)).multiply(BigDecimal.valueOf(MP_MST[casenum]))).doubleValue();
		vec[1]=((BigDecimal.valueOf(MC_MST[casenum]).multiply(sub_deviationvalue)).multiply(f_probMP)).doubleValue();
		vec[2]=((BigDecimal.valueOf(MC_MST[casenum]).multiply(add_deviationvalue)).multiply(BigDecimal.valueOf(MP_MST[casenum]))).doubleValue();
		vec[3]=((BigDecimal.valueOf(MC_MST[casenum]).multiply(add_deviationvalue)).multiply(f_probMP)).doubleValue();
		
		vec[4]=((f_probMC.multiply(sub_deviationvalue)).multiply(BigDecimal.valueOf(MP_MST[casenum]))).doubleValue();
		vec[5]=((f_probMC.multiply(sub_deviationvalue)).multiply(f_probMP)).doubleValue();
		vec[6]=((f_probMC.multiply(add_deviationvalue)).multiply(BigDecimal.valueOf(MP_MST[casenum]))).doubleValue();
		vec[7]=((f_probMC.multiply(add_deviationvalue)).multiply(f_probMP)).doubleValue();
		*/
		/*for(int i=0;i<vec.length;i++)
		{
			System.out.print(vec[i]+" ");
		
		}
		System.out.println();*/
		  //double deviationvalue=0.12;
		
	   /*double deviationvalue=MR_MST[casenum]*((double)random_int/100.0);
	   
		vec[0]=MC_MST[casenum]*(MR_MST[casenum]-deviationvalue)*MP_MST[casenum];
		vec[1]=MC_MST[casenum]*(MR_MST[casenum]-deviationvalue)*(1-MP_MST[casenum]);
		vec[2]=MC_MST[casenum]*((1-MR_MST[casenum])+deviationvalue)*MP_MST[casenum];
		vec[3]=MC_MST[casenum]*((1-MR_MST[casenum])+deviationvalue)*(1-MP_MST[casenum]);
		
		vec[4]=(1-MC_MST[casenum])*(MR_MST[casenum]-deviationvalue)*MP_MST[casenum];
		vec[5]=(1-MC_MST[casenum])*(MR_MST[casenum]-deviationvalue)*(1-MP_MST[casenum]);
		vec[6]=(1-MC_MST[casenum])*((1-MR_MST[casenum])+deviationvalue)*MP_MST[casenum];
		vec[7]=(1-MC_MST[casenum])*((1-MR_MST[casenum])+deviationvalue)*(1-MP_MST[casenum]);
		
		*/
		
		 double deviationvalue=MR_MST[casenum]*((double)random_int/100.0);
		// System.out.println(deviationvalue+"  "+random_int);
		    
			vec[0]=(MC_MST[casenum])*(MR_MST[casenum]-deviationvalue)*(MP_MST[casenum]);
			vec[1]=(MC_MST[casenum])*(MR_MST[casenum]-deviationvalue)*((1-MP_MST[casenum]));
			vec[2]=(MC_MST[casenum])*((1-MR_MST[casenum])+deviationvalue)*(MP_MST[casenum]);
			vec[3]=(MC_MST[casenum])*((1-MR_MST[casenum])+deviationvalue)*((1-MP_MST[casenum]));
			
			vec[4]=((1-MC_MST[casenum]))*(MR_MST[casenum]-deviationvalue)*(MP_MST[casenum]);
			vec[5]=((1-MC_MST[casenum]))*(MR_MST[casenum]-deviationvalue)*((1-MP_MST[casenum]));
			vec[6]=((1-MC_MST[casenum]))*((1-MR_MST[casenum])+deviationvalue)*(MP_MST[casenum]);
			vec[7]=((1-MC_MST[casenum]))*((1-MR_MST[casenum])+deviationvalue)*((1-MP_MST[casenum]));
			
		
		
		
		
		
		
		
		return vec;
		
	}
	
	
	public double[] getCaseRTDet(int casenum)
	{
		/////change it to redundant topology
		//System.out.println("deviation:::::::::::::::::"+ RDMTransitionProb.random_int+" Time::::"+RDMTransitionProb.deviation_timesteps);
	    double deviationvalue1=MC_RT[casenum]*((double)random_int1/100.0);
	    double deviationvalue2=MP_RT[casenum]*((double)random_int2/100.0);
	    
	    //System.out.println("deviation1"+deviationvalue1+"  "+deviationvalue2);
	    
		vec[0]=(MC_RT[casenum]-deviationvalue1)*(MR_RT[casenum])*(MP_RT[casenum]-deviationvalue2);
		vec[1]=(MC_RT[casenum]-deviationvalue1)*(MR_RT[casenum])*((1-MP_RT[casenum])+deviationvalue2);
		vec[2]=(MC_RT[casenum]-deviationvalue1)*((1-MR_RT[casenum]))*(MP_RT[casenum]-deviationvalue2);
		vec[3]=(MC_RT[casenum]-deviationvalue1)*((1-MR_RT[casenum]))*((1-MP_RT[casenum])+deviationvalue2);
		
		vec[4]=((1-MC_RT[casenum])+deviationvalue1)*(MR_RT[casenum])*(MP_RT[casenum]-deviationvalue2);
		vec[5]=((1-MC_RT[casenum])+deviationvalue1)*(MR_RT[casenum])*((1-MP_RT[casenum])+deviationvalue2);
		vec[6]=((1-MC_RT[casenum])+deviationvalue1)*((1-MR_RT[casenum]))*(MP_RT[casenum]-deviationvalue2);
		vec[7]=((1-MC_RT[casenum])+deviationvalue1)*((1-MR_RT[casenum]))*((1-MP_RT[casenum])+deviationvalue2);
		
		return vec;
		
	}

	
	
}
