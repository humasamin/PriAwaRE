package problems.rdmthreeobjectives;


import problems.RewardFunction;
import problems.rdmthreeobjectives.RDMConfiguration;

public class RDMRewardsThree implements RewardFunction<Integer, Integer> {

	private boolean threeObjectives;

	public RDMRewardsThree(boolean obj) {
		// TODO Auto-generated constructor stub
		threeObjectives = obj;
	}

	@Override
	public int numberOfObjectives() {
		// TODO Auto-generated method stub
		return 3;
	}

	@Override
	public double[] expectedReward(Integer state, Integer action, Integer statePrime) {
		// TODO Auto-generated method stub

double[] rew=null;
		
		if (state.equals(RDMStatesThree.S1) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] { 75,40,68 };
			rew=new double[] {RDMConfiguration.rewards_mec_mst[0],RDMConfiguration.rewards_mr_mst[0],RDMConfiguration.rewards_mp_mst[0]};
		} else if (state.equals(RDMStatesThree.S2) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] { 63, 56,53 };
			rew=new double[] {RDMConfiguration.rewards_mec_mst[1],RDMConfiguration.rewards_mr_mst[1],RDMConfiguration.rewards_mp_mst[1]};
		} else if (state.equals(RDMStatesThree.S3) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] { 94, 24,74 };
			//rew=new double[]{39,38,38.5};
			rew=new double[] {RDMConfiguration.rewards_mec_mst[2],RDMConfiguration.rewards_mr_mst[2],RDMConfiguration.rewards_mp_mst[2]};
		} else if (state.equals(RDMStatesThree.S4) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] { 78, 40,58};
			//rew=new double[]{17,16,15};
			
			rew=new double[] {RDMConfiguration.rewards_mec_mst[3],RDMConfiguration.rewards_mr_mst[3],RDMConfiguration.rewards_mp_mst[3]};
		}
		if (state.equals(RDMStatesThree.S5) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] { 63, 56,60 };
			// rew=new double[]{44,43,43.5};
			
			rew=new double[] {RDMConfiguration.rewards_mec_mst[4],RDMConfiguration.rewards_mr_mst[4],RDMConfiguration.rewards_mp_mst[4]};
		
		} else if (state.equals(RDMStatesThree.S6) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] {29,28,27};
			// rew=new double[]{75,-50};
			rew=new double[] {RDMConfiguration.rewards_mec_mst[5],RDMConfiguration.rewards_mr_mst[5],RDMConfiguration.rewards_mp_mst[5]};
		
		} else if (state.equals(RDMStatesThree.S7) && action.equals(RDMActionsThree.MST)) {
			
			rew=new double[] {RDMConfiguration.rewards_mec_mst[6],RDMConfiguration.rewards_mr_mst[6],RDMConfiguration.rewards_mp_mst[6]};
			//rew = new double[] {14,13,13.5};
			// rew=new double[]{50,-25};
		} else if (state.equals(RDMStatesThree.S8) && action.equals(RDMActionsThree.MST)) {
			
			rew=new double[] {RDMConfiguration.rewards_mec_mst[7],RDMConfiguration.rewards_mr_mst[7],RDMConfiguration.rewards_mp_mst[7]};
			
			//rew = new double[] {2,1,1};
			// rew=new double[]{-100,-100};
		}
		if (state.equals(RDMStatesThree.S1) && action.equals(RDMActionsThree.RT)) {
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[0],RDMConfiguration.rewards_mr_rt[0],RDMConfiguration.rewards_mp_rt[0]};
			//rew = new double[] {41,43,41};
			// rew=new double[]{100,100};
		} else if (state.equals(RDMStatesThree.S2) && action.equals(RDMActionsThree.RT)) {
			//rew = new double[] {32,33,31};
			// rew=new double[]{-25,50};
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[1],RDMConfiguration.rewards_mr_rt[1],RDMConfiguration.rewards_mp_rt[1]};
			
			
		} else if (state.equals(RDMStatesThree.S3) && action.equals(RDMActionsThree.RT)) {
			//rew = new double[] {28,29,27};
			// rew=new double[]{-50,75};
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[2],RDMConfiguration.rewards_mr_rt[2],RDMConfiguration.rewards_mp_rt[2]};
			
		} else if (state.equals(RDMStatesThree.S4) && action.equals(RDMActionsThree.RT)) {
			//rew = new double[] {26,27,25};
			// rew=new double[]{-100,-100};
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[3],RDMConfiguration.rewards_mr_rt[3],RDMConfiguration.rewards_mp_rt[3]};
			
		}
		if (state.equals(RDMStatesThree.S5) && action.equals(RDMActionsThree.RT)) {
			//rew = new double[] {28,29,27};
			// rew=new double[]{100,100};
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[4],RDMConfiguration.rewards_mr_rt[4],RDMConfiguration.rewards_mp_rt[4]};
			
		} else if (state.equals(RDMStatesThree.S6) && action.equals(RDMActionsThree.RT)) {
			//rew = new double[] { 16,17,15};
			// rew=new double[]{-25,50};
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[5],RDMConfiguration.rewards_mr_rt[5],RDMConfiguration.rewards_mp_rt[5]};
			
		} else if (state.equals(RDMStatesThree.S7) && action.equals(RDMActionsThree.RT)) {
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[6],RDMConfiguration.rewards_mr_rt[6],RDMConfiguration.rewards_mp_rt[6]};
			
			//rew = new double[] {23,24,22};
			// rew=new double[]{-50,75};
		} else if (state.equals(RDMStatesThree.S8) && action.equals(RDMActionsThree.RT)) {
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[7],RDMConfiguration.rewards_mr_rt[7],RDMConfiguration.rewards_mp_rt[7]};
			
			//rew = new double[] {11,12,10};
			// rew=new double[]{-100,-100};
		}
		return rew;					
	}			
						
								
	

	@Override
	public double[] expectedReward(Integer state, Integer action) {
		// TODO Auto-generated method stub
double[] rew=null;
		
		if (state.equals(RDMStatesThree.S1) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] { 75,40,68 };
			rew=new double[] {RDMConfiguration.rewards_mec_mst[0],RDMConfiguration.rewards_mr_mst[0],RDMConfiguration.rewards_mp_mst[0]};
		} else if (state.equals(RDMStatesThree.S2) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] { 63, 56,53 };
			rew=new double[] {RDMConfiguration.rewards_mec_mst[1],RDMConfiguration.rewards_mr_mst[1],RDMConfiguration.rewards_mp_mst[1]};
		} else if (state.equals(RDMStatesThree.S3) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] { 94, 24,74 };
			//rew=new double[]{39,38,38.5};
			rew=new double[] {RDMConfiguration.rewards_mec_mst[2],RDMConfiguration.rewards_mr_mst[2],RDMConfiguration.rewards_mp_mst[2]};
		} else if (state.equals(RDMStatesThree.S4) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] { 78, 40,58};
			//rew=new double[]{17,16,15};
			
			rew=new double[] {RDMConfiguration.rewards_mec_mst[3],RDMConfiguration.rewards_mr_mst[3],RDMConfiguration.rewards_mp_mst[3]};
		}
		if (state.equals(RDMStatesThree.S5) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] { 63, 56,60 };
			// rew=new double[]{44,43,43.5};
			
			rew=new double[] {RDMConfiguration.rewards_mec_mst[4],RDMConfiguration.rewards_mr_mst[4],RDMConfiguration.rewards_mp_mst[4]};
		
		} else if (state.equals(RDMStatesThree.S6) && action.equals(RDMActionsThree.MST)) {
			//rew = new double[] {29,28,27};
			// rew=new double[]{75,-50};
			rew=new double[] {RDMConfiguration.rewards_mec_mst[5],RDMConfiguration.rewards_mr_mst[5],RDMConfiguration.rewards_mp_mst[5]};
		
		} else if (state.equals(RDMStatesThree.S7) && action.equals(RDMActionsThree.MST)) {
			
			rew=new double[] {RDMConfiguration.rewards_mec_mst[6],RDMConfiguration.rewards_mr_mst[6],RDMConfiguration.rewards_mp_mst[6]};
			//rew = new double[] {14,13,13.5};
			// rew=new double[]{50,-25};
		} else if (state.equals(RDMStatesThree.S8) && action.equals(RDMActionsThree.MST)) {
			
			rew=new double[] {RDMConfiguration.rewards_mec_mst[7],RDMConfiguration.rewards_mr_mst[7],RDMConfiguration.rewards_mp_mst[7]};
			
			//rew = new double[] {2,1,1};
			// rew=new double[]{-100,-100};
		}
		if (state.equals(RDMStatesThree.S1) && action.equals(RDMActionsThree.RT)) {
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[0],RDMConfiguration.rewards_mr_rt[0],RDMConfiguration.rewards_mp_rt[0]};
			//rew = new double[] {41,43,41};
			// rew=new double[]{100,100};
		} else if (state.equals(RDMStatesThree.S2) && action.equals(RDMActionsThree.RT)) {
			//rew = new double[] {32,33,31};
			// rew=new double[]{-25,50};
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[1],RDMConfiguration.rewards_mr_rt[1],RDMConfiguration.rewards_mp_rt[1]};
			
			
		} else if (state.equals(RDMStatesThree.S3) && action.equals(RDMActionsThree.RT)) {
			//rew = new double[] {28,29,27};
			// rew=new double[]{-50,75};
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[2],RDMConfiguration.rewards_mr_rt[2],RDMConfiguration.rewards_mp_rt[2]};
			
		} else if (state.equals(RDMStatesThree.S4) && action.equals(RDMActionsThree.RT)) {
			//rew = new double[] {26,27,25};
			// rew=new double[]{-100,-100};
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[3],RDMConfiguration.rewards_mr_rt[3],RDMConfiguration.rewards_mp_rt[3]};
			
		}
		if (state.equals(RDMStatesThree.S5) && action.equals(RDMActionsThree.RT)) {
			//rew = new double[] {28,29,27};
			// rew=new double[]{100,100};
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[4],RDMConfiguration.rewards_mr_rt[4],RDMConfiguration.rewards_mp_rt[4]};
			
		} else if (state.equals(RDMStatesThree.S6) && action.equals(RDMActionsThree.RT)) {
			//rew = new double[] { 16,17,15};
			// rew=new double[]{-25,50};
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[5],RDMConfiguration.rewards_mr_rt[5],RDMConfiguration.rewards_mp_rt[5]};
			
		} else if (state.equals(RDMStatesThree.S7) && action.equals(RDMActionsThree.RT)) {
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[6],RDMConfiguration.rewards_mr_rt[6],RDMConfiguration.rewards_mp_rt[6]};
			
			//rew = new double[] {23,24,22};
			// rew=new double[]{-50,75};
		} else if (state.equals(RDMStatesThree.S8) && action.equals(RDMActionsThree.RT)) {
			
			rew=new double[] {RDMConfiguration.rewards_mec_rt[7],RDMConfiguration.rewards_mr_rt[7],RDMConfiguration.rewards_mp_rt[7]};
			
			//rew = new double[] {11,12,10};
			// rew=new double[]{-100,-100};
		}
		return rew;
		
	}

	@Override
	public double[] getReward(Integer state, Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		return this.expectedReward(state, action, statePrime);
	}

	@Override
	public double[] getReward(Integer state, Integer action) {
		// TODO Auto-generated method stub
		return this.expectedReward(state, action);
	}

	@Override
	public double[] minRewards() {
		// TODO Auto-generated method stub
		double[] rew = { RDMConfiguration.min_rewards[0],RDMConfiguration.min_rewards[1],RDMConfiguration.min_rewards[2]};
				
		return rew;
	}

}
