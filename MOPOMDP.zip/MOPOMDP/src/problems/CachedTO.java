package problems;

public class CachedTO<S,A,O> {

	private double[][][][] toMatrix;
	
	public CachedTO(EnumerableStates<S> states, 
			DiscreteActions<A,S> actions, 
			DiscreteObservations<O> observations, Mopomdp<S,A,O> m){
		this.toMatrix = new double[states.numberOfStates()][actions.size()][observations.size()][states.numberOfStates()];
		for(int s=0; s<states.numberOfStates(); s++){
			S state = states.stateIdentifier(s);
			for(int a=0; a<actions.size(); a++){
				A act = actions.actionIdentifier(a);
				for(int o=0; o<observations.size(); o++){
					O obs = observations.observationIdentifier(o);
					for(int s_=0; s_<states.numberOfStates(); s_++){
						S statePrime = states.stateIdentifier(s_);
						this.toMatrix[s][a][o][s_] = m.observationProb(act, statePrime, obs)*
								m.transitionProb(state, act, statePrime);
					}
				}
			}
		}
	}
	
	public double getTO(int s, int a, int o, int s_){
		return this.toMatrix[s][a][o][s_];
	}
}
