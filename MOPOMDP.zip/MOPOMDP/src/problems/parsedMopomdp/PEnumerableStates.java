package problems.parsedMopomdp;

import java.util.ArrayList;

import problems.EnumerableStates;

public class PEnumerableStates implements EnumerableStates<Integer>{

	private ArrayList<Integer> states; 
	
	
	public PEnumerableStates(int max){
		states = new ArrayList<Integer>(max);
		for(int i=0; i<max; i++){
			states.add(new Integer(i));
		}
	}
	@Override
	public int numberOfStates() {
		return states.size();
	}

	@Override
	public int stateNumber(Integer identifier) {
		return identifier.intValue();
	}

	@Override
	public Integer stateIdentifier(int number) {
		return this.states.get(number);
	}

	@Override
	public boolean isTerminal(Integer identifier) {
		return false;
	}

	@Override
	public boolean isTerminal(int number) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String printState(Integer identifier) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String[] stateList() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
