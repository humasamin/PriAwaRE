package problems.parsedMopomdp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import problems.Actions;
import problems.DiscreteActions;
import problems.EnumerableStates;
import problems.Mopomdp;
import problems.ObservationFunction;
import problems.DiscreteObservations;
import problems.Observations;
import problems.RewardFunction;
import problems.TransitionFunction;

public class ParsedMopomdp extends Mopomdp<Integer,Integer,Integer>{

	public ParsedMopomdp(EnumerableStates<Integer> s_,
			TransitionFunction<Integer, Integer> t_, Actions<Integer> a_,
			RewardFunction<Integer, Integer> r_,
			ObservationFunction<Integer, Integer, Integer> o_,
			Observations<Integer> om_) {
		super(s_, t_, a_, r_, o_, om_);
	}
	
	public ParsedMopomdp(String filename){
		super();
		
		ArrayList<String> s = this.readLinesFromFile(filename);
		for(int i=0; i<s.size(); i++){
			System.out.println(s.get(i));
		}
	}
	
	private ArrayList<String> readLinesFromFile(String filename){
		ArrayList<String> strs = new ArrayList<String>();

	    // wrap a BufferedReader around FileReader
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(filename));
			while (bufferedReader.ready())
		    {
		    	String line = bufferedReader.readLine();
		        strs.add(line);
		    }
			bufferedReader.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		ArrayList<String> strs2 = new ArrayList<String>();
		for(int i=0; i<strs.size(); i++){
			String curr = strs.get(i);
			if(!curr.startsWith("#")){
				if(!(curr.length()==0)){
					strs2.add(curr);
				}
			}
		}
		
		return strs2;
	}

}
