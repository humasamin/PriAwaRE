package problems.tiger;

import problems.DiscreteActions;
import problems.DiscreteObservations;
import problems.Mopomdp;

public class MOTiger extends Mopomdp<Integer, Integer, Integer> {

	//Infinite horizon discounted MOTiger
	public MOTiger(boolean obj3, double[] b0, double pCorrectObservation, double gamma){
		
		super(new TigerStates(), new TigerTransitions(), 
				new TigerActions(), new TigerRewards(obj3), 
				new TigerObsFunction(pCorrectObservation), 
				new TigerObservations(), b0);
		
		this.finiteHorizon=false;
		this.discountFactor=gamma;
		this.horizon = Integer.MAX_VALUE;
		this.problemName+=""+this.numberOfObjectives()+"-objective Tiger";
	}
	
	//Finite horizon MOTiger
	public MOTiger(boolean obj3, double[] b0, double pCorrectObservation, int horiz){
		
		super(new TigerStates(), new TigerTransitions(), 
				new TigerActions(), new TigerRewards(obj3), 
				new TigerObsFunction(pCorrectObservation),  
				new TigerObservations(), b0);
		
		this.finiteHorizon=true;
		this.discountFactor=1;
		this.horizon = horiz;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public DiscreteActions<Integer,Integer> getActionSet(){
		return ((DiscreteActions<Integer,Integer>) this.actions);
	}
	
	@Override
	public DiscreteObservations<Integer> getObservationSet(){
		return ((DiscreteObservations<Integer>) this.omega);
	}
}
