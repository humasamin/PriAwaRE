package problems.tiger;

import problems.EnumerableStates;

public class TigerStates implements EnumerableStates<Integer> {

	public static final Integer LEFT    = new Integer(0);
	public static final Integer RIGHT   = new Integer(1);
	public static final Integer TERMINAL= new Integer(2);
	
	public static final boolean DEBUG   = false;
	
	public TigerStates(){
		
	}
	
	@Override
	public int numberOfStates() {
		return 3;
	}

	@Override
	public int stateNumber(Integer identifier) {
		return identifier.intValue();
	}

	@Override
	public Integer stateIdentifier(int number) {
		if(DEBUG){
			System.out.print("Called state id retrieval: "+number);
		}
		if(number == 0){
			if(DEBUG) System.out.println(" (LEFT)");
			return TigerStates.LEFT;
		}
		if(number == 1){
			if(DEBUG) System.out.println(" (RIGHT)");
			return TigerStates.RIGHT;
		}
		if(number == TigerStates.TERMINAL.intValue()){
			if(DEBUG) System.out.println(" (TERMINAL)");
			return TigerStates.TERMINAL;
		}
		System.err.println("Invalid tiger state.");
		return null;
	}

	@Override
	public boolean isTerminal(Integer identifier) {
		return identifier.equals(TERMINAL);
	}

	@Override
	public boolean isTerminal(int number) {
		return this.isTerminal(this.stateIdentifier(number));
	}

	@Override
	public String printState(Integer identifier) {
		if(identifier.intValue()==TigerStates.LEFT.intValue()){
			return "L";
		}
		if(identifier.intValue()==TigerStates.RIGHT.intValue()){
			return "R";
		}
		if(identifier.intValue()==TigerStates.TERMINAL.intValue()){
			return "T";
		}
		return "UKNOWN STATE";
	}

	@Override
	public String[] stateList() {
		String[] result = new String[this.numberOfStates()];
		for(int i=0; i<this.numberOfStates(); i++){
			result[i] = this.printState(this.stateIdentifier(i));
		}
		return result;
	}

}
