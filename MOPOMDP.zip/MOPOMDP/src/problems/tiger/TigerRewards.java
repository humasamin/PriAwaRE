package problems.tiger;

import problems.RewardFunction;

public class TigerRewards implements RewardFunction<Integer,Integer>{

	private int noObj;
	
	public TigerRewards(boolean threeObjectives){
		if(threeObjectives){
			this.noObj = 3;
		} else {
			this.noObj=2;
		}
	}
	
	public int numberOfObjectives(){
		return noObj;
	}
	public double[] expectedReward(Integer state, Integer action, Integer statePrime){
		return expectedReward(state,action);
	}
	
	public double[] expectedReward(Integer state, Integer action){
		double[] result;
		if(noObj == 3){
			if(state.equals(TigerStates.TERMINAL)){
				double[] r = {0,0,0};
				result = r;
			} else if(action.equals(TigerActions.LISTEN)){
				double[] r = {-3,0,0};
				result = r;
			} else {
				if( (action.equals(TigerActions.OPENLEFT)&&state.equals(TigerStates.LEFT)) ||
					(action.equals(TigerActions.OPENRIGHT)&&state.equals(TigerStates.RIGHT))	){
					double[] r = {0,30,0};
					result = r;
				} else {
					//TIGERRRRRR!!!!
					double[] r = {0,0,-300};
					result = r;
				}
			}
		} else {
			if(state.equals(TigerStates.TERMINAL)){
				double[] r = {0,0};
				result = r;
			} else if(action.equals(TigerActions.LISTEN)){
				double[] r = {-2,0};
				result = r;
			} else {
				if( (action.equals(TigerActions.OPENLEFT)&&state.equals(TigerStates.LEFT)) ||
					(action.equals(TigerActions.OPENRIGHT)&&state.equals(TigerStates.RIGHT))	){
					double[] r = {20,0};
					result = r;
				} else {
					//TIGERRRRRR!!!!
					double[] r = {0,-200};
					result = r;
				}
			}
		}
		return result;
	}
	
	public double[] getReward(Integer state, Integer action, Integer statePrime){
		return getReward(state, action);
	}
	
	public double[] getReward(Integer state, Integer action){
		return expectedReward(state,action);
	}

	@Override
	public double[] minRewards() {
		
		if(this.noObj==2){
			double[] result = {-2,-200};
			return result;
		}
		if(this.noObj==3){
			double[] result = {-3,0,-300};
			return result;
		}
		return null;
	}
}
