package problems.tiger;

import globals.CentralStatics;

import java.util.Random;
import problems.DiscreteActions;

public class TigerActions implements DiscreteActions<Integer,Integer>{

	public final static Integer LISTEN = new Integer(0);
	public final static Integer OPENLEFT = new Integer(1);
	public final static Integer OPENRIGHT = new Integer(2);
	
	private Integer[] all;
	
	public TigerActions(){
		this.all = new Integer[3];
		this.all[0] = TigerActions.LISTEN;
		this.all[1] = TigerActions.OPENLEFT;
		this.all[2] = TigerActions.OPENRIGHT;
	}
	
	@Override
	public boolean isDiscrete() {
		return true;
	}

	@Override
	public boolean validAction(Integer action) {
		return action.intValue()==0||action.intValue()==1;
	}

	@Override
	public Integer randomAction() {
		Random r = CentralStatics.getCentralRandom();
		if(r.nextBoolean()){
			return TigerActions.LISTEN;
		} else {
			if(r.nextBoolean()){
				return TigerActions.OPENLEFT;
			} else {
				return TigerActions.OPENRIGHT;
			}
		}
	}

	@Override
	public int size() {
		return 3;
	}

	@Override
	public Integer[] allActions() {
		return this.all;
	}

	@Override
	public Integer[] actionsInState(Integer state) {
		return this.all;
	}

	@Override
	public int numberOfActionsInState(Integer state) {
		return 3;
	}

	@Override
	public Integer actionIdentifier(int a) {
		return this.all[a];
	}

	@Override
	public String printAction(Integer action) {
		if(TigerActions.LISTEN.intValue() == action.intValue()){
			return "LI"; 
		}
		if(TigerActions.OPENLEFT.intValue() == action.intValue()){
			return "OL"; 
		}
		if(TigerActions.OPENRIGHT.intValue() == action.intValue()){
			return "OR"; 
		}
		return "UKNOWN ACTION";
	}

}
