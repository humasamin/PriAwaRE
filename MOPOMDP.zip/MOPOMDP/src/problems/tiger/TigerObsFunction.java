package problems.tiger;

import globals.CentralStatics;

import java.util.Random;

import problems.ObservationFunction;

public class TigerObsFunction implements ObservationFunction<Integer, Integer, Integer> {

	private double p;
	
	public TigerObsFunction(double pCorrect){
		this.p = pCorrect;
	}
	
	public double observationProbability(Integer action, Integer statePrime, Integer observation){
		if(statePrime.equals(TigerStates.LEFT)){
			if(observation.equals(TigerObservations.HEARLEFT)){
				return this.p;
			} else {
				return (1.0-this.p);
			}
		} else {
			if(observation.equals(TigerObservations.HEARRIGHT)){
				return this.p;
			} else {
				return (1.0-this.p);
			}
		}
	}
	
	
	public Integer getObservation(Integer action, Integer statePrime){
		Random r = CentralStatics.getCentralRandom();
			if(statePrime.equals(TigerStates.LEFT)){
					if(r.nextDouble()<this.p){
						return TigerObservations.HEARLEFT;
					} else {
						return TigerObservations.HEARRIGHT;
					}
			} else {
					if(r.nextDouble()<this.p){
						return TigerObservations.HEARRIGHT;
					} else {
						return TigerObservations.HEARLEFT;
					}
			}
			//System.err.println("Invalid combination of s' and a in simulated observation");
			//return null;
	}
}
