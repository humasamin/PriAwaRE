package problems.tiger;

import problems.TransitionFunction;

public class TigerTransitions implements TransitionFunction<Integer, Integer> {

	@Override
	public double probabilityOfTransition(Integer state, Integer action,
			Integer statePrime) {
		
		if(action.equals(TigerActions.OPENLEFT) || 
				action.equals(TigerActions.OPENRIGHT)){
			if(statePrime.equals(TigerStates.TERMINAL)){
				return 1;
			} else {
				return 0;
			}
		} else {
			if(state.equals(statePrime)){
				return 1;
			} else {
				return 0;
			}
		}
	}

	@Override
	public double[] probabilityVector(Integer state, Integer action) {
		if(action.equals(TigerActions.LISTEN)){
			if(state.equals(TigerStates.LEFT)){
				double[] r = {1,0,0};
				return r;
			} else {
				double[] r = {0,1,0};
				return r;
			}
		} else {
			double[] r = {0,0,1};
			return r;
		}
	}

	@Override
	public Integer nextState(Integer currentState, Integer action) {
		if(action.equals(TigerActions.LISTEN)){
			return currentState;
		} else {
			return TigerStates.TERMINAL;
		}
	}

}
