package problems.tiger;

import problems.DiscreteObservations;

public class TigerObservations implements DiscreteObservations<Integer>{

	public static final Integer HEARLEFT = new Integer(0);
	public static final Integer HEARRIGHT = new Integer(1);
	private Integer[] allObs;
	
	public TigerObservations(){
		this.allObs = new Integer[2];
		allObs[0] = HEARLEFT;
		allObs[1] = HEARRIGHT;
	}
	
	@Override
	public int size() {
		return 2;
	}

	@Override
	public Integer[] allObservations() {
		return this.allObs;
	}

	@Override
	public boolean isDiscrete() {
		return true;
	}

	@Override
	public boolean validObservation(Integer observation) {
		return this.allObs[0].equals(observation) || this.allObs[1].equals(observation);
	}

	@Override
	public Integer observationIdentifier(int o) {
		return this.allObs[o];
	}

	@Override
	public String toString(Integer obs) {
		if(obs.intValue()==TigerObservations.HEARLEFT.intValue()){
			return "HearLeft";
		}
		if(obs.intValue()==TigerObservations.HEARRIGHT.intValue()){
			return "HearRight";
		}
		return null;
	}

}
