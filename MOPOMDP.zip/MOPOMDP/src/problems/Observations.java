package problems;

public interface Observations<O> {
	public boolean isDiscrete();
	public boolean validObservation(O action);
}
