package problems.iot;

import problems.DiscreteObservations;

public class IOTObservations implements DiscreteObservations<Integer>{
	
	public final static Integer O1 = new Integer(0);//SNR<0
	public final static Integer O2 = new Integer(1);//SNR=0
	public final static Integer O3 = new Integer(2);//SNR>0
	
	private Integer[] allObs;
	
	public IOTObservations()
	{
		allObs = new Integer[]{O1,O2,O3};
	}

	@Override
	public boolean isDiscrete() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean validObservation(Integer action) {
		// TODO Auto-generated method stub
		return action.intValue()>=0 && action.intValue()<=2;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 3;
	}

	@Override
	public Integer[] allObservations() {
		// TODO Auto-generated method stub
		return allObs;
	}

	@Override
	public Integer observationIdentifier(int o) {
		// TODO Auto-generated method stub
		if(o<0||o>2){
			System.err.println("Observation number (IOT) out of range: "+o);
			return null;
		}
		return this.allObs[o];
	}

	@Override
	public String toString(Integer obs) {
		// TODO Auto-generated method stub
		int o = obs.intValue();
		String[] os = {"O1","O2","O3"};
		return os[obs];
	}

}
