package problems.iot;

import java.util.ArrayList;

import deltaiot.services.Link;
import deltaiot.services.Mote;
import globals.CentralStatics;
import problems.ObservationFunction;
import problems.rdm.RDMActions;
import problems.rdm.RDMObservations;
import problems.rdm.RDMStates;

public class IOTObsFunction implements ObservationFunction<Integer, Integer, Integer>{

	@Override
	public double observationProbability(Integer action, Integer statePrime, Integer observation) {
		// TODO Auto-generated method stub
				//Case 1
				//P(O|Action=DTP,State=S1)
				if(statePrime.equals(IOTStates.S1)&&action.equals(IOTActions.DTP)){
					
					if(observation.equals(IOTObservations.O1)){
						return 0.33;
					} 
					else if(observation.equals(IOTObservations.O2)){
						return 0.33;
					}
					else if(observation.equals(IOTObservations.O3)){
						return 0.33;
					}
				}
				
				//Case 2
				//P(O|Action=MPG,State=S2)
				if(statePrime.equals(IOTStates.S2)&&action.equals(IOTActions.DTP)){
					
					if(observation.equals(IOTObservations.O1)){
						return 0.33;
					} 
					else if(observation.equals(IOTObservations.O2)){
						return 0.33;
					}
					else if(observation.equals(IOTObservations.O3)){
						return 0.33;
					}
				}
				
				//Case 3
				//P(O|Action=MPG,State=S3)
				if(statePrime.equals(IOTStates.S3)&&action.equals(IOTActions.DTP)){
					
					if(observation.equals(IOTObservations.O1)){
						return 0.33;
					} 
					else if(observation.equals(IOTObservations.O2)){
						return 0.33;
					}
					else if(observation.equals(IOTObservations.O3)){
						return 0.33;
					}
				}
				
				//Case 4
				//P(O|Action=MPG,State=S4)
				if(statePrime.equals(IOTStates.S4)&&action.equals(IOTActions.DTP)){
					
					if(observation.equals(IOTObservations.O1)){
						return 0.33;
					} 
					else if(observation.equals(IOTObservations.O2)){
						return 0.33;
					}
					else if(observation.equals(IOTObservations.O3)){
						return 0.33;
					}
				}
				
				//Case 1
				//P(O|Action=ITP,State=S1)
				if(statePrime.equals(IOTStates.S1)&&action.equals(IOTActions.ITP)){
					
					if(observation.equals(IOTObservations.O1)){
						return 0.33;
					} 
					else if(observation.equals(IOTObservations.O2)){
						return 0.33;
					}
					else if(observation.equals(IOTObservations.O3)){
						return 0.33;
					}
				}
				
				//Case 2
				//P(O|Action=ITP,State=S2)
				if(statePrime.equals(IOTStates.S2)&&action.equals(IOTActions.ITP)){
					
					if(observation.equals(IOTObservations.O1)){
						return 0.33;
					} 
					else if(observation.equals(IOTObservations.O2)){
						return 0.33;
					}
					else if(observation.equals(IOTObservations.O3)){
						return 0.33;
					}
				}
				
				//Case 3
				//P(O|Action=ITP,State=S3)
				if(statePrime.equals(IOTStates.S3)&&action.equals(IOTActions.ITP)){
					
					if(observation.equals(IOTObservations.O1)){
						return 0.33;
					} 
					else if(observation.equals(IOTObservations.O2)){
						return 0.33;
					}
					else if(observation.equals(IOTObservations.O3)){
						return 0.33;
					}
				}
				
				//Case 4
				//P(O|Action=ITP,State=S4)
				if(statePrime.equals(IOTStates.S4)&&action.equals(IOTActions.ITP)){
					
					if(observation.equals(IOTObservations.O1)){
						return 0.33;
					} 
					else if(observation.equals(IOTObservations.O2)){
						return 0.33;
					}
					else if(observation.equals(IOTObservations.O3)){
						return 0.33;
					}
				}
				
				return 0.0;
	}
/*
	@Override
	public Integer getObservation(Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		Integer obs=null;
		
		if(MOIOT.refsetcreation==true)
		{
		
			double SNR =CentralStatics.getCentralRandom().nextDouble();
		
		if(SNR<0.5)
		{
			//return the observation
			obs=IOTObservations.O1;
			
		}
		else if(SNR==0.5)
		{
			obs= IOTObservations.O2;
		}
		else if(SNR>0.5)
		{
			obs= IOTObservations.O3;
		}
		
		}
		
		else{
			
			//System.out.println("observation function");
		for (Link link : MOIOT.selectedmote.getLinks()) {
			
			if (link.getSNR() > 0||link.getPower()>0) {
				return IOTObservations.O3;
			}
			else if (link.getSNR() == 0) {
				return IOTObservations.O2;
			}
			else if (link.getSNR() <0||link.getPower()<15) {
				return IOTObservations.O1;
			}
		}
		}
		
		//}
		//if (mote.getLinks().size() == 2) {
			//if (mote.getLinks().get(0).getPower() != mote.getLinks().get(1).getPower())
				//return true;
		////}
		
		return obs;
	}*/
	
	
	//For DeltaIOT Check
	//@Override
	/*public Integer getObservation(Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		Integer obs=null;
		
		if(DeltaIOTConnector.refsetcreation==true)
		{
		
			double SNR =CentralStatics.getCentralRandom().nextDouble();
		
		if(SNR<0.5)
		{
			//return the observation
			obs=IOTObservations.O1;
			
		}
		else if(SNR==0.5)
		{
			obs= IOTObservations.O2;
		}
		else if(SNR>0.5)
		{
			obs= IOTObservations.O3;
		}
		
		}
		
		else{
			
		//DeltaIOTConnector.motes = DeltaIOTConnector.networkMgmt.getProbe().getAllMotes();
			
		//DeltaIOTConnector.motes = DeltaIOTConnector.networkMgmt.getProbe().getAllMotes();
		//ArrayList<Mote> motesobs=DeltaIOTConnector.networkMgmt.getProbe().getAllMotes();	
		for(Mote m:DeltaIOTConnector.motes)
		{
			System.out.println("observation function: mote no:  "+m.getMoteid());
		//for (Link link : DeltaIOTConnector.selectedmote.getLinks()) {
		for (Link link : m.getLinks()) {	
		//if (link.getSNR() > 0 && link.getPower()>0) {
			if (link.getSNR() > 0) {
				//DeltaIOTConnector.selectedmote=m;
				//DeltaIOTConnector.selectedlink=link;
				return IOTObservations.O3;
			}
			else if (link.getSNR() == 0) {
				//DeltaIOTConnector.selectedmote=m;
				//DeltaIOTConnector.selectedlink=link;
				return IOTObservations.O2;
			}
			//else if (link.getSNR()<0 && link.getPower()<15) {
			else if (link.getSNR() <0) {
				//DeltaIOTConnector.selectedmote=m;
				//DeltaIOTConnector.selectedlink=link;
				return IOTObservations.O1;
			}
		}
		}
		//}
		}
		/*if (mote.getLinks().size() == 2) {
			if (mote.getLinks().get(0).getPower() != mote.getLinks().get(1).getPower())
				return true;
		}
		*/
		//return obs;
	//}*/
	
	
	
	@Override
	public Integer getObservation(Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		Integer obs=null;
		
		if(DeltaIOTConnector.refsetcreation==true)
		{
		
			double SNR =CentralStatics.getCentralRandom().nextDouble();
		//System.out.println("refset true");
			if(SNR<0.5)
			{
			//return the observation
			obs=IOTObservations.O1;
			
			}
			if(SNR==0.5)
			{
			obs= IOTObservations.O2;
			}
			if(SNR>0.5)
			{
			obs= IOTObservations.O3;
			}
		
		}
		
		if(DeltaIOTConnector.refsetcreation==false){
			
		//DeltaIOTConnector.motes = DeltaIOTConnector.networkMgmt.getProbe().getAllMotes();
			
		//DeltaIOTConnector.motes = DeltaIOTConnector.networkMgmt.getProbe().getAllMotes();
		//ArrayList<Mote> motesobs=DeltaIOTConnector.networkMgmt.getProbe().getAllMotes();	
			
			//SF example
		//for(Mote m:DeltaIOTConnector.motes)
		//{
		System.out.println("observation function: mote no:  "+DeltaIOTConnector.selectedmote.getMoteid());
		//for (Link link : DeltaIOTConnector.selectedmote.getLinks()) {
		for (Link link : DeltaIOTConnector.selectedmote.getLinks()) {	
			System.out.println("SNR: "+link.getSNR());
			System.out.println("Distribution factor:"+link.getDistribution());
		//if (link.getSNR() > 0 && link.getPower()>0) {
			if (link.getSNR() > 0) {
				//DeltaIOTConnector.selectedmote=m;
				//DeltaIOTConnector.selectedlink=link;
				return IOTObservations.O3;
			}
			else if (link.getSNR() == 0) {
				//DeltaIOTConnector.selectedmote=m;
				//DeltaIOTConnector.selectedlink=link;
				return IOTObservations.O2;
			}
			//else if (link.getSNR()<0 && link.getPower()<15) {
			else if (link.getSNR() <0) {
				//DeltaIOTConnector.selectedmote=m;
				//DeltaIOTConnector.selectedlink=link;
				return IOTObservations.O1;
			}
		}
		}
		//}
		//}
		/*if (mote.getLinks().size() == 2) {
			if (mote.getLinks().get(0).getPower() != mote.getLinks().get(1).getPower())
				return true;
		}
		*/
		return obs;
	}
	
	

}
