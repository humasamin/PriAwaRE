package problems.iot;

import globals.CentralStatics;
import problems.DiscreteActions;
import problems.rdm.RDMActions;

public class IOTActions implements DiscreteActions<Integer,Integer>{
	
	/////Need to check it
	//public final static Integer ITP = new Integer(1); //Increase Transmission Power
	//public final static Integer MPG = new Integer(0);  //Modify Path to Gateway
	
	public final static Integer ITP = new Integer(1); //Increase Transmission Power
	public final static Integer DTP = new Integer(0);  //Decrease Transmission Power
	
	private Integer[] all;
	
	public IOTActions()
	{
		this.all = new Integer[2];
		this.all[0] = IOTActions.DTP;
		this.all[1] = IOTActions.ITP;
		
	}

	@Override
	public boolean isDiscrete() {
		// TODO Auto-generated method stub
		return true;
	}

	/////Both MST and RT are valid actions to be taken???????
	@Override
	public boolean validAction(Integer action) {
		// TODO Auto-generated method stub
		return action.intValue()==0||action.intValue()==1;
	}

	@Override
	public Integer randomAction() {
		// TODO Auto-generated method stub
		/*Random r = CentralStatics.getCentralRandom();
		if(r.nextBoolean()){
			return RDMActions.RT;
		} else {
			return RDMActions.MST;
		}*/
		
		int r = CentralStatics.getCentralRandom().nextInt(2);
		return this.actionIdentifier(r);
		
	}

	@Override
	public String printAction(Integer action) {
		// TODO Auto-generated method stub
		if(IOTActions.ITP.intValue() == action.intValue()){
			return "ITP"; 
		}
		if(IOTActions.DTP.intValue() == action.intValue()){
			return "DTP"; 
		}
		
		return "UKNOWN ACTION";
		
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public Integer actionIdentifier(int a) {
		// TODO Auto-generated method stub
		return this.all[a];
	}

	@Override
	public Integer[] allActions() {
		// TODO Auto-generated method stub
		return this.all;
	}

	@Override
	public Integer[] actionsInState(Integer state) {
		// TODO Auto-generated method stub
		return this.all;
	}

	@Override
	public int numberOfActionsInState(Integer state) {
		// TODO Auto-generated method stub
		return 2;
	}


}
