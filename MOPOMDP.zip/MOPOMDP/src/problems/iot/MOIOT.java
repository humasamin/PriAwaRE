package problems.iot;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import deltaiot.client.Effector;
import deltaiot.client.Probe;
import deltaiot.client.SimulationClient;
import deltaiot.services.Link;
import deltaiot.services.Mote;
import globals.Tuple;
import problems.DiscreteActions;
import problems.DiscreteObservations;
import problems.Mopomdp;
import simulator.QoS;
import solvers.linearsupport.LinearSupporter;
import solvers.linearsupport.ReusingPerseusSolver;
import value.CPruner;
import value.SimpleVector;
import value.ValueAtBeliefVector;
import globals.StopWatch;


public class MOIOT extends Mopomdp<Integer, Integer, Integer> {
	
	public static StopWatch stopwatchiot;
	/*public static Probe probe;
	public static Effector effector;
	public static Mote selectedmote;
	public static Link selectedlink;
	public static boolean refsetcreation=false;
	public static ArrayList<Mote> motes;
	public static SimulationClient networkMgmt;
	public static int timestepiot;*/
	
public MOIOT(boolean obj3, double[] b0, double gamma){
		
		super(IOTStates.getStates(), IOTTransitions.getTransitions(), 
				new IOTActions(), new IOTRewards(obj3), //add dim/obj to reward
				new IOTObsFunction(), 
				new IOTObservations(), b0);
		
		this.finiteHorizon=false;
		this.discountFactor=gamma;
		this.horizon = Integer.MAX_VALUE;
		this.problemName+=""+this.numberOfObjectives()+"-objective IOT";
		stopwatchiot = StopWatch.getGlobalStopWatch();
	}

	@Override
	public DiscreteActions<Integer,Integer> getActionSet(){
		return ((DiscreteActions<Integer,Integer>) this.actions);
	}

	@Override
	public DiscreteObservations<Integer> getObservationSet(){
		return ((DiscreteObservations<Integer>) this.omega);
	}
	
	
	
	
	
}
