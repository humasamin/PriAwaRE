package problems.iot;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import deltaiot.services.Link;
import deltaiot.services.LinkSettings;
import deltaiot.services.Mote;
import globals.CentralStatics;
import problems.TransitionFunction;
import simulator.QoS;


public class IOTTransitions implements TransitionFunction<Integer, Integer> {
	
	private static IOTTransitions trans = null;

	@Override
	public double probabilityOfTransition(Integer state, Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		double[] vec = this.probabilityVector(state, action);
		return vec[statePrime.intValue()];
	}

	@Override
	public double[] probabilityVector(Integer state, Integer action) {
		// TODO Auto-generated method stub
		double[] vec = {0,0,0,0};
		//For MST
				//First Case
				if(action.equals(IOTActions.DTP)&&state.equals(IOTStates.S1)){
					
					
					/*vec[0]=0.7482;
					vec[1]=0.1218;
					vec[2]=0.1118;
					vec[3]=0.0182;*/
					
					vec[0]=0.8188;
					vec[1]=0.0712;
					vec[2]=0.1012;
					vec[3]=0.0088;
					
					
				}
				
				
				//Second Case
				if(action.equals(IOTActions.DTP)&&state.equals(IOTStates.S2)){
					
					/*vec[0]=0.2088;
					vec[1]=0.6612;
					vec[2]=0.0988;
					vec[3]=0.0312;*/
					
					vec[0]=0.8188;
					vec[1]=0.1012;
					vec[2]=0.0712;
					vec[3]=0.0088;
					
					
					
				}


				
				//third case
				
				if(action.equals(IOTActions.DTP)&&state.equals(IOTStates.S3)){
					
					
					/*vec[0]=0.6622;
					vec[1]=0.1978;
					vec[2]=0.1078;
					vec[3]=0.0322;*/
					
					vec[0]=0.8064;
					vec[1]=0.0336;
					vec[2]=0.1536;
					vec[3]=0.0064;
				}
					
				
				//Fourth case
				
				if(action.equals(IOTActions.DTP)&&state.equals(IOTStates.S4)){
					
					/*vec[0]=0.1848;
					vec[1]=0.5852;
					vec[2]=0.1748;
					vec[3]=0.0552;*/
					
					vec[0]=0.7917;
					vec[1]=0.0783;
					vec[2]=0.1183;
					vec[3]=0.0117;
					
				}
				
				//For RT
				//First Case
						if(action.equals(IOTActions.ITP)&&state.equals(IOTStates.S1)){
							
							
							/*vec[0]=0.7029;
							vec[1]=0.0071;
							vec[2]=0.2871;
							vec[3]=0.0029;*/
							
							vec[0]=0.833;
							vec[1]=0.017;
							vec[2]=0.147;
							vec[3]=0.003;
						}
						//Second Case
						if(action.equals(IOTActions.ITP)&&state.equals(IOTStates.S2)){
							
							
													
							/*vec[0]=0.6319;
							vec[1]=0.0781;
							vec[2]=0.2581;
							vec[3]=0.0319;*/
							
							vec[0]=0.8448;
							vec[1]=0.0352;
							vec[2]=0.1152;
							vec[3]=0.0048;
						
							
						}
						
						//third case
						
						if(action.equals(IOTActions.ITP)&&state.equals(IOTStates.S3)){
							
							/*vec[0]=0.3861;
							vec[1]=0.0061;
							vec[2]=0.6039;
							vec[3]=0.0039;*/
							
							vec[0]=0.7227;
							vec[1]=0.0073;
							vec[2]=0.2673;
							vec[3]=0.0027;
							
							
						}
						
						//Fourth case
						
						if(action.equals(IOTActions.ITP)&&state.equals(IOTStates.S4)){
							
							
							/*vec[0]=0.3471;
							vec[1]=0.0671;
							vec[2]=0.5429;
							vec[3]=0.0429;*/
							///problem with probability
							vec[0]=0.7372;
							vec[1]=0.0228;
							vec[2]=0.2328;
							vec[3]=0.0072;
							
						}
							
				
		
		return vec;
	}
	
	
/*
	@Override
	public Integer nextState(Integer currentState, Integer action) {
		// TODO Auto-generated method stub
		//Exceptional case to avoid nullpointer exception
				if(action==null)
				{
					return currentState;
				}
				
				if(MOIOT.refsetcreation==true)
				{	
					
				double r = CentralStatics.getCentralRandom().nextDouble();
				
				double[] vec = this.probabilityVector(currentState, action);
				double prob = 0.0;
				IOTStates s = IOTStates.getStates(); //returns an object of IOTStates type
				
				for(int i=0; i<vec.length; i++){
					
					prob += vec[i];
					
					if(r<=prob){

						
						if(i==IOTStates.S1.intValue())
						{
						
						return IOTStates.S1;
						}
						if(i==IOTStates.S2.intValue())
						{
						
						return IOTStates.S2;
						}
						if(i==IOTStates.S3.intValue())
						{
						
						return IOTStates.S3;
						}
						if(i==IOTStates.S4.intValue())
						{
						
						return IOTStates.S4;
						}
				}
				}
				
				}////end if refsetcreation==true
				
				
				else{
				
				
				///check for DeltaIOT//////////////////////////////
				if(action.equals(IOTActions.MPG))
				{
					performMPG();
					
					
					///check it
					ArrayList<QoS> result = MOIOT.networkMgmt.getNetworkQoS(MOIOT.timestepiot+1);
					
					double pl=result.get(result.size()-1).getPacketLoss();
					double ec=result.get(result.size()-1).getEnergyConsumption();
					
					if(ec<20 && pl<0.20)
					{
						return IOTStates.S1;
					}
					else if(ec<20 && pl>=0.20)
					{
						return IOTStates.S2;
					}
					else if(ec>=20 && pl<0.20)
					{
						return IOTStates.S3;
					}
					else if(ec>=20 && pl>=0.20)
					{
						return IOTStates.S4;
					}
					
					
				}
				else if(action.equals(IOTActions.ITP))
				{
					performITP();
					
					///check it
					ArrayList<QoS> result = MOIOT.networkMgmt.getNetworkQoS(MOIOT.timestepiot+1);
					
					
					double pl=result.get(result.size()-1).getPacketLoss();
					double ec=result.get(result.size()-1).getEnergyConsumption();
					
					if(ec<20 && pl<0.20)
					{
						return IOTStates.S1;
					}
					else if(ec<20 && pl>=0.20)
					{
						return IOTStates.S2;
					}
					else if(ec>=20 && pl<0.20)
					{
						return IOTStates.S3;
					}
					else if(ec>=20 && pl>=0.20)
					{
						return IOTStates.S4;
					}
					
				}
				
				
				}
				
				
				return null;
	}*/
	
	
	//For DeltaIOT
	@Override
	public Integer nextState(Integer currentState, Integer action) {
		// TODO Auto-generated method stub
		//Exceptional case to avoid nullpointer exception
				/*if(action==null)
				{
					action=IOTActions.DTP;
					System.out.println("Action 0 perform");
				}*/
				
				if(DeltaIOTConnector.refsetcreation==true)
				{	
					
					
				double r = CentralStatics.getCentralRandom().nextDouble();
				
				double[] vec = this.probabilityVector(currentState, action);
				double prob = 0.0;
				IOTStates s = IOTStates.getStates(); //returns an object of IOTStates type
				
				for(int i=0; i<vec.length; i++){
					
					prob += vec[i];
					
					if(r<=prob){

						
						if(i==IOTStates.S1.intValue())
						{
						
						return IOTStates.S1;
						}
						if(i==IOTStates.S2.intValue())
						{
						
						return IOTStates.S2;
						}
						if(i==IOTStates.S3.intValue())
						{
						
						return IOTStates.S3;
						}
						if(i==IOTStates.S4.intValue())
						{
						
						return IOTStates.S4;
						}
				}
				}
				
				}////end if refsetcreation==true
				else{
					
					
				///check for DeltaIOT//////////////////////////////
				if(action.equals(IOTActions.DTP))
				{
					
					
					performDTP();
					
					System.out.println("DTP");
					///check it
					ArrayList<QoS> result = DeltaIOTConnector.networkMgmt.getNetworkQoS(DeltaIOTConnector.timestepiot+1);
					
					double pl=result.get(result.size()-1).getPacketLoss();
					double ec=result.get(result.size()-1).getEnergyConsumption();
					//System.out.println("packet loss: "+pl+"   "+ec);
					if(ec<20 && pl<0.20)
					{
						return IOTStates.S1;
					}
					else if(ec<20 && pl>=0.20)
					{
						return IOTStates.S2;
					}
					else if(ec>=20 && pl<0.20)
					{
						return IOTStates.S3;
					}
					else if(ec>=20 && pl>=0.20)
					{
						return IOTStates.S4;
					}
					
					
				}
				else if(action.equals(IOTActions.ITP))
				{
					performITP();
					
					System.out.println("ITP");
					
					///check it
					ArrayList<QoS> result = DeltaIOTConnector.networkMgmt.getNetworkQoS(DeltaIOTConnector.timestepiot+1);
					
					
					double pl=result.get(result.size()-1).getPacketLoss();
					double ec=result.get(result.size()-1).getEnergyConsumption();
					
					if(ec<20 && pl<0.20)
					{
						return IOTStates.S1;
					}
					else if(ec<20 && pl>=0.20)
					{
						return IOTStates.S2;
					}
					else if(ec>=20 && pl<0.20)
					{
						return IOTStates.S3;
					}
					else if(ec>=20 && pl>=0.20)
					{
						return IOTStates.S4;
					}
					
				}
				
				
				}
				
				
				return null;
	}

	
	
	
	//Method to return an object of IOTTransitions class
		public static IOTTransitions getTransitions(){
			if(IOTTransitions.trans ==null){
				IOTTransitions.trans = new IOTTransitions();
			}
			return IOTTransitions.trans;
		}

		///perform actions for simulator DeltaIOT
		/*public void performITP()
		{ 	int value;
			for (Mote mote : DeltaIOTConnector.motes) {
				for (Link link : mote.getLinks()) {
					
					if (link.getSNR() > 0 && link.getPower() > 0) {
						value=link.getPower()-1;
						List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
						newSettings.add(new LinkSettings(mote.getMoteid(), link.getDest(), value, link.getDistribution(), link.getSF()));
			
						DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(mote.getMoteid(),newSettings);
						
					} else if (link.getSNR() < 0 && link.getPower() < 15) {
						
						
						value=link.getPower()+1;
						List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
						newSettings.add(new LinkSettings(mote.getMoteid(), link.getDest(), value, link.getDistribution(), link.getSF()));
			
						DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(mote.getMoteid(),newSettings);
						
					}
				}
			}
			
		}*/
		
		
		///perform action MPG for Delta IOT
	/*	public void performMPG()
		{
			Link left, right;
			int valueleft,valueright;
			
			for (Mote mote : MOIOT.motes) {
				for (Link link : mote.getLinks()) {
					
					if (mote.getLinks().size() == 2 ) {
						left = mote.getLinks().get(0);
						right = mote.getLinks().get(1);
						if (left.getPower() != right.getPower()) {
							// If distribution of all links is 100 then change it to 50
							// 50
							if (left.getDistribution() == 100 && right.getDistribution() == 100) {
								left.setDistribution(50);
								right.setDistribution(50);
							}
							if (left.getPower() > right.getPower() && left.getDistribution() < 100) {
								valueleft=left.getDistribution() + 10;
								 valueright=right.getDistribution() - 10;
								 left.setDistribution(valueleft);
								 right.setDistribution(valueright);
							} else if (right.getDistribution() < 100) {
								valueright=right.getDistribution() + 10;
								valueleft=left.getDistribution() - 10;
								left.setDistribution(valueleft);
								right.setDistribution(valueright);
							}
						}
					}
					
					List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
					
					newSettings.add(new LinkSettings(mote.getMoteid(), link.getDest(), link.getPower(), link.getDistribution(), link.getSF()));
		
					MOIOT.effector.setMoteSettings(mote.getMoteid(),newSettings);
				}
				}
			
		}
		*/
		
		//For DeltaIOT check//////////////////////////////////////////commented for checking SF case
		///perform actions for simulator DeltaIOT
				/*public void performITP()
				{ 	int value;
				
				Link left, right;
				int valueleft,valueright;
				
				
				
						//for (Link link : mote.getLinks()) {
							
							//if (link.getSNR() > 0 && link.getPower() > 0) {
								//value=link.getPower()-1;
								//List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
								//newSettings.add(new LinkSettings(mote.getMoteid(), link.getDest(), value, link.getDistribution(), link.getSF()));
					
								//DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(mote.getMoteid(),newSettings);
								
							//} else 
						for(Mote m:DeltaIOTConnector.motes) {
							//if(m.getLinks().size()==1)
							//{
							for(Link l:m.getLinks())
							{
							
								//DeltaIOTConnector.selectedlink=m.getLink(0);
								DeltaIOTConnector.selectedlink=l;
								
							if (DeltaIOTConnector.selectedlink.getSNR() < 0 && DeltaIOTConnector.selectedlink.getPower() < 15) {
								//DeltaIOTConnector.selectedlink=l;
							
								value=DeltaIOTConnector.selectedlink.getPower()+1;
								int valueSF=DeltaIOTConnector.selectedlink.getSF();
								if(valueSF<12)
								{
								valueSF=DeltaIOTConnector.selectedlink.getSF()+1;
								}
								List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
								newSettings.add(new LinkSettings(m.getMoteid(), DeltaIOTConnector.selectedlink.getDest(), value, DeltaIOTConnector.selectedlink.getDistribution(), valueSF));
					
								DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(m.getMoteid(),newSettings);
								
							}
							}
				}
			
						//}
						//}
					//}
					for (Mote mote : DeltaIOTConnector.motes) {
						if(mote.getLinks().size()==2)
						{
							
							left =mote.getLinks().get(0);
							right = mote.getLinks().get(1);
							if (left.getPower() != right.getPower()) {
								// If distribution of all links is 100 then change it to 50
								// 50
								if (left.getDistribution() == 100 && right.getDistribution() == 100) {
									left.setDistribution(50);
									right.setDistribution(50);
								}
								if (left.getPower() > right.getPower() && left.getDistribution() < 100) {
									valueleft=left.getDistribution() + 10;
									 valueright=right.getDistribution() - 10;
									 left.setDistribution(valueleft);
									 right.setDistribution(valueright);
								} else if (right.getDistribution() < 100) {
									valueright=right.getDistribution() + 10;
									valueleft=left.getDistribution() - 10;
									left.setDistribution(valueleft);
									right.setDistribution(valueright);
								}
							
						}
							
						}
				}
				}
				*/
				//SF checking commented 
				/*public void performDTP()
				{ 	int value;
				
				Link left, right;
				int valueleft,valueright;
				
				
				
						//for (Link link : mote.getLinks()) {
							
							//if (link.getSNR() > 0 && link.getPower() > 0) {
								//value=link.getPower()-1;
								//List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
								//newSettings.add(new LinkSettings(mote.getMoteid(), link.getDest(), value, link.getDistribution(), link.getSF()));
					
								//DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(mote.getMoteid(),newSettings);
						
							//} else 
				for(Mote m:DeltaIOTConnector.motes) {
					//if(m.getLinks().size()==1)
					//{
					for(Link l:m.getLinks())
					{
						//DeltaIOTConnector.selectedlink=m.getLink(0);
						DeltaIOTConnector.selectedlink=l;
							if (DeltaIOTConnector.selectedlink.getSNR() > 0 && DeltaIOTConnector.selectedlink.getPower() >0) {
								
							
								value=DeltaIOTConnector.selectedlink.getPower()-1;
								int valueSF=DeltaIOTConnector.selectedlink.getSF();
								if(valueSF>7)
								{
								valueSF=DeltaIOTConnector.selectedlink.getSF()-1;
								}
								List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
								newSettings.add(new LinkSettings(m.getMoteid(), DeltaIOTConnector.selectedlink.getDest(), value, DeltaIOTConnector.selectedlink.getDistribution(), valueSF));
					
								DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(m.getMoteid(),newSettings);
								
							}
					}
				}
						
							
					for (Mote mote : DeltaIOTConnector.motes) {
						if(mote.getLinks().size()>1)
						{
							
							left =mote.getLinks().get(0);
							right = mote.getLinks().get(1);
							if (left.getPower() != right.getPower()) {
								// If distribution of all links is 100 then change it to 50
								// 50
								if (left.getDistribution() == 100 && right.getDistribution() == 100) {
									left.setDistribution(50);
									right.setDistribution(50);
								}
								if (left.getPower() > right.getPower() && left.getDistribution() < 100) {
									valueleft=left.getDistribution() + 10;
									 valueright=right.getDistribution() - 10;
									 left.setDistribution(valueleft);
									 right.setDistribution(valueright);
								} else if (right.getDistribution() < 100) {
									valueright=right.getDistribution() + 10;
									valueleft=left.getDistribution() - 10;
									left.setDistribution(valueleft);
									right.setDistribution(valueright);
								}
							
						}
							
						}
				}
					
					
					
				}*/
				
				
				
				
				
				///perform action MPG for Delta IOT
				public void performMPG()
				{
					Link left, right;
					int valueleft,valueright;
					//DeltaIOTConnector dc=new DeltaIOTConnector();
					
					//for(int i=0;i<DeltaIOTConnector.moteids.length;i++)
					//{
						//Mote m=dc.getMoteById(DeltaIOTConnector.moteids[i]);
						//System.out.println(m.getMoteid()+"checking ids");
					//}
					
					//DeltaIOTConnector dc=new DeltaIOTConnector();
					
					//for(int i=0;i<DeltaIOTConnector.moteids.length;i++)
					//{
						//System.out.println(DeltaIOTConnector.moteids.length+"  checking length");
						//Mote m=dc.getMoteById(DeltaIOTConnector.moteids[i]);
						//System.out.println(DeltaIOTConnector.moteids[i]+"  checking id");
						
					//}
					
					
					for (Mote mote : DeltaIOTConnector.motes) {
						for (Link link : mote.getLinks()) {
							
							if (mote.getLinks().size() == 2 ) {
								left = mote.getLinks().get(0);
								right = mote.getLinks().get(1);
								if (left.getPower() != right.getPower()) {
									// If distribution of all links is 100 then change it to 50
									// 50
									if (left.getDistribution() == 100 && right.getDistribution() == 100) {
										left.setDistribution(50);
										right.setDistribution(50);
									}
									if (left.getPower() > right.getPower() && left.getDistribution() < 100) {
										valueleft=left.getDistribution() + 10;
										 valueright=right.getDistribution() - 10;
										 left.setDistribution(valueleft);
										 right.setDistribution(valueright);
									} else if (right.getDistribution() < 100) {
										valueright=right.getDistribution() + 10;
										valueleft=left.getDistribution() - 10;
										left.setDistribution(valueleft);
										right.setDistribution(valueright);
									}
								}
							}
							
							List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
							
							newSettings.add(new LinkSettings(mote.getMoteid(), link.getDest(), link.getPower(), link.getDistribution(), link.getSF()));
				
							DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(mote.getMoteid(),newSettings);
						}
						}
					
				}
				
				
				
				//Checking SF
				//For DeltaIOT check//////////////////////////////////////////
				///perform actions for simulator DeltaIOT
						public void performITP()
						{ 	int value;
						
						Link left, right;
						int valueleft,valueright;
						
						
						
								//for (Link link : mote.getLinks()) {
									
									//if (link.getSNR() > 0 && link.getPower() > 0) {
										//value=link.getPower()-1;
										//List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
										//newSettings.add(new LinkSettings(mote.getMoteid(), link.getDest(), value, link.getDistribution(), link.getSF()));
							
										//DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(mote.getMoteid(),newSettings);
										
									//} else 
								//for(Mote m:DeltaIOTConnector.motes) {
									//if(m.getLinks().size()==1)
									//{
									for(Link l:DeltaIOTConnector.selectedmote.getLinks())
									{
									
										//DeltaIOTConnector.selectedlink=m.getLink(0);
										DeltaIOTConnector.selectedlink=l;
										
									if (DeltaIOTConnector.selectedlink.getSNR() < 0 && DeltaIOTConnector.selectedlink.getPower() < 15) {
										//DeltaIOTConnector.selectedlink=l;
									
										value=DeltaIOTConnector.selectedlink.getPower()+1;
										int valueSF=DeltaIOTConnector.selectedlink.getSF();
										if(valueSF<12)
										{
										valueSF=DeltaIOTConnector.selectedlink.getSF()+1;
										}
										List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
										newSettings.add(new LinkSettings(DeltaIOTConnector.selectedmote.getMoteid(), DeltaIOTConnector.selectedlink.getDest(), value, DeltaIOTConnector.selectedlink.getDistribution(), valueSF));
							
										DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(DeltaIOTConnector.selectedmote.getMoteid(),newSettings);
										
									}
									}
						//}
					
								//}
								//}
							//}
							for (Mote mote : DeltaIOTConnector.motes) {
								if(mote.getLinks().size()==2)
								{
									
									left =mote.getLinks().get(0);
									right = mote.getLinks().get(1);
									if (left.getPower() != right.getPower()) {
										// If distribution of all links is 100 then change it to 50
										// 50
										if (left.getDistribution() == 100 && right.getDistribution() == 100) {
											left.setDistribution(50);
											right.setDistribution(50);
										}
										if (left.getPower() > right.getPower() && left.getDistribution() < 100) {
											valueleft=left.getDistribution() + 10;
											 valueright=right.getDistribution() - 10;
											 left.setDistribution(valueleft);
											 right.setDistribution(valueright);
										} else if (right.getDistribution() < 100) {
											valueright=right.getDistribution() + 10;
											valueleft=left.getDistribution() - 10;
											left.setDistribution(valueleft);
											right.setDistribution(valueright);
										}
									
								}
									
								}
						}
						}
						
						
						///SF Check
						public void performDTP()
						{ 	int value;
						
						Link left, right;
						int valueleft,valueright;
						
						
						
								//for (Link link : mote.getLinks()) {
									
									//if (link.getSNR() > 0 && link.getPower() > 0) {
										//value=link.getPower()-1;
										//List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
										//newSettings.add(new LinkSettings(mote.getMoteid(), link.getDest(), value, link.getDistribution(), link.getSF()));
							
										//DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(mote.getMoteid(),newSettings);
								
									//} else 
						//for(Mote m:DeltaIOTConnector.motes) {
							//if(m.getLinks().size()==1)
							//{
							for(Link l:DeltaIOTConnector.selectedmote.getLinks())
							{
								//DeltaIOTConnector.selectedlink=m.getLink(0);
								DeltaIOTConnector.selectedlink=l;
									if (DeltaIOTConnector.selectedlink.getSNR() > 0 && DeltaIOTConnector.selectedlink.getPower() >0) {
										
									
										value=DeltaIOTConnector.selectedlink.getPower()-1;
										int valueSF=DeltaIOTConnector.selectedlink.getSF();
										if(valueSF>7)
										{
										valueSF=DeltaIOTConnector.selectedlink.getSF()-1;
										}
										List<LinkSettings> newSettings=new LinkedList<LinkSettings>();
										newSettings.add(new LinkSettings(DeltaIOTConnector.selectedmote.getMoteid(), DeltaIOTConnector.selectedlink.getDest(), value, DeltaIOTConnector.selectedlink.getDistribution(), valueSF));
							
										DeltaIOTConnector.networkMgmt.getEffector().setMoteSettings(DeltaIOTConnector.selectedmote.getMoteid(),newSettings);
										
									}
							}
						//}
								
									
							for (Mote mote : DeltaIOTConnector.motes) {
								if(mote.getLinks().size()>1)
								{
									
									left =mote.getLinks().get(0);
									right = mote.getLinks().get(1);
									if (left.getPower() != right.getPower()) {
										// If distribution of all links is 100 then change it to 50
										// 50
										if (left.getDistribution() == 100 && right.getDistribution() == 100) {
											left.setDistribution(50);
											right.setDistribution(50);
										}
										if (left.getPower() > right.getPower() && left.getDistribution() < 100) {
											valueleft=left.getDistribution() + 10;
											 valueright=right.getDistribution() - 10;
											 left.setDistribution(valueleft);
											 right.setDistribution(valueright);
										} else if (right.getDistribution() < 100) {
											valueright=right.getDistribution() + 10;
											valueleft=left.getDistribution() - 10;
											left.setDistribution(valueleft);
											right.setDistribution(valueright);
										}
									
								}
									
								}
						}
							
							
							
						}
						
						
						
					
		
}
