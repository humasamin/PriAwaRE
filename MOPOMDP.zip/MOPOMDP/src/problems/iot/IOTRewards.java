package problems.iot;

import problems.RewardFunction;


public class IOTRewards implements RewardFunction<Integer,Integer> {
	
	private boolean threeObjectives;
	
	public IOTRewards(boolean obj) {
		// TODO Auto-generated constructor stub
		threeObjectives=obj;
		
	}

	@Override
	public int numberOfObjectives() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public double[] expectedReward(Integer state, Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		double[] rew=null;
		if(state.equals(IOTStates.S1)&& action.equals(IOTActions.DTP))
		{
			rew=new double[]{89,80};
			//rew=new double[]{100,100};
		}
		else if(state.equals(IOTStates.S2)&& action.equals(IOTActions.DTP))
		{
			rew=new double[]{75.1,20};
			//rew=new double[]{75,-50};
		}
		else if(state.equals(IOTStates.S3)&& action.equals(IOTActions.DTP))
		{
			rew=new double[]{75,30};
			//rew=new double[]{50,-25};
		}
		else if(state.equals(IOTStates.S4)&& action.equals(IOTActions.DTP))
		{
			rew=new double[]{10,5};
			//rew=new double[]{-100,-100};
		}
		if(state.equals(IOTStates.S1)&& action.equals(IOTActions.ITP))
		{
			rew=new double[]{80,89.67};
			//rew=new double[]{100,100};
		}
		else if(state.equals(IOTStates.S2)&& action.equals(IOTActions.ITP))
		{
			rew=new double[]{40,75};
			//rew=new double[]{-25,50};
		}
		else if(state.equals(IOTStates.S3)&& action.equals(IOTActions.ITP))
		{
			rew=new double[]{30,70};
			//rew=new double[]{-50,75};
		}
		else if(state.equals(IOTStates.S4)&& action.equals(IOTActions.ITP))
		{
			rew=new double[]{5,10};
			//rew=new double[]{-100,-100};
		}
				
		
		return rew;
	}

	@Override
	public double[] expectedReward(Integer state, Integer action) {
		// TODO Auto-generated method stub
		
		double[] rew=null;
		if(state.equals(IOTStates.S1)&& action.equals(IOTActions.DTP))
		{
			rew=new double[]{89,80};
			//rew=new double[]{100,100};
		}
		else if(state.equals(IOTStates.S2)&& action.equals(IOTActions.DTP))
		{
			rew=new double[]{75.1,20};
			//rew=new double[]{75,-50};
		}
		else if(state.equals(IOTStates.S3)&& action.equals(IOTActions.DTP))
		{
			rew=new double[]{75,30};
			//rew=new double[]{50,-25};
		}
		else if(state.equals(IOTStates.S4)&& action.equals(IOTActions.DTP))
		{
			rew=new double[]{10,5};
			//rew=new double[]{-100,-100};
		}
		if(state.equals(IOTStates.S1)&& action.equals(IOTActions.ITP))
		{
			rew=new double[]{80,89.67};
			//rew=new double[]{100,100};
		}
		else if(state.equals(IOTStates.S2)&& action.equals(IOTActions.ITP))
		{
			rew=new double[]{40,75};
			//rew=new double[]{-25,50};
		}
		else if(state.equals(IOTStates.S3)&& action.equals(IOTActions.ITP))
		{
			rew=new double[]{30,70};
			//rew=new double[]{-50,75};
		}
		else if(state.equals(IOTStates.S4)&& action.equals(IOTActions.ITP))
		{
			rew=new double[]{5,10};
			//rew=new double[]{-100,-100};
		}
				
		
		return rew;
		
	}

	@Override
	public double[] getReward(Integer state, Integer action, Integer statePrime) {
		// TODO Auto-generated method stub
		return this.expectedReward(state, action, statePrime);
	}

	@Override
	public double[] getReward(Integer state, Integer action) {
		// TODO Auto-generated method stub
		return this.expectedReward(state, action);
	}

	@Override
	public double[] minRewards() {
		// TODO Auto-generated method stub
		double[] rew = {5, 10};
		return rew;
	}

}
