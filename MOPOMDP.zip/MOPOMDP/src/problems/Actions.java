package problems;

public interface Actions<A> {
	public boolean isDiscrete();
	public boolean validAction(A action);
	public A randomAction();
	public String printAction(A action);
}
