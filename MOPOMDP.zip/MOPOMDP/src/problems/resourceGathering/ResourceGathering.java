package problems.resourceGathering;

import globals.CentralStatics;

import java.security.InvalidParameterException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The main resource gathering problem. Controls the states, transitions and rewards based on a set of parameters.
 */
public class ResourceGathering {

    /** The (negative) reward for each time step */
    private static final RewardRange TIME_REWARD = new RewardRange(-1, -1);

    /** The parameters affecting the problem */
    private final RGParameters mParameters;
    /** The resources that can be collected by the agent */
    private final List<Resource> mResources;
    /** The goal's location that when reached by the agent indicates a terminal state */
    private final Location mGoal;

    /** The state that the problem starts with */
    private final RGState mInitialState;
    /** The state that the problem is currently in */
    private RGState mCurrentState;
    /** The amount of steps taken */
    private int mStepCount = 0;

    /**
     * Creates a new resource gathering problem based on the given parameters.
     *
     * @param parameters
     *            The parameters that define the shape of the problem
     */
    public ResourceGathering(final RGParameters parameters) {
        mParameters = parameters;

        mResources = mParameters.resources;
        mGoal = new Location(mParameters.maxX, mParameters.maxY);

        mInitialState = new RGState(new Location(0, 0), mResources.size());
        reset();
    }

    /**
     * Resets the problem to the initial state. Should be called before running each episode.
     */
    public void reset() {
        mCurrentState = mInitialState;
        mStepCount = 0;
        //Log.d("ENV: New state is " + mCurrentState);
    }

    /**
     * Lets the agent perform a certain action to transition to the next state and collect a reward. This method may
     * contain stochasticity. The action must follow the parameter's action space size restrictions.
     *
     * @param action
     *            The action to perform
     *
     * @return The discounted reward resulting from performing the action
     */
    @SuppressWarnings("unused")
    public double[] performAction(final RGDiscreteAction action) {
        if (action.ordinal() > mParameters.actionMax) {
            throw new InvalidParameterException("Action value exceeds action space");
        }

        // Log possible next states for debugging purposes
        /*if (Log.D && !mParameters.fullyObservable) {
            Log.d("");
            Log.d("ENV: Performing action " + action);
            Log.d("ENV: Possible results");
            final Map<RGState, Double> stateProbabilities = getPossibleTransitions(mCurrentState, action);
            for (final RGState state : stateProbabilities.keySet()) {
                Log.d("    " + state + " - " + stateProbabilities.get(state));
            }
            Log.d("");
        }*/

        return performAction(action.getLocation());
    }

    /**
     * Lets the agent perform a certain action to transition to the next state and collect a reward. This method may
     * contain stochasticity. The action must follow the parameter's action space size restrictions.
     *
     * @param action
     *            The action to perform
     *
     * @return The discounted reward resulting from performing the action
     */
    public double[] performAction(final Location action) {
        // Determine which failure action to add to the agent's action
        final Location failAction;
        if (CentralStatics.getCentralRandom().nextDouble() < mParameters.actionFailProb) {
            // Determine which action to modify the requested action with
            if (mParameters.continuousStatesActions) {
                final double xFail = CentralStatics.getCentralRandom().nextDouble() * mParameters.maxStepSize * 2 - mParameters.maxStepSize;
                final double yFail = CentralStatics.getCentralRandom().nextDouble() * mParameters.maxStepSize * 2 - mParameters.maxStepSize;
                failAction = new Location(xFail, yFail);
            } else {
                final int failureIndex = CentralStatics.getCentralRandom().nextInt(mParameters.actionMax - 1) + 1;
                failAction = RGDiscreteAction.values()[failureIndex].getLocation();
            }
        } else {
            failAction = new Location(0, 0);
        }

        // Determine the next state
        final RGState nextState = getNextState(mCurrentState, action, failAction);
        //Log.d("ENV: New state is " + nextState);

        // Determine the rewards for the transition
        final RewardRange[] rewardRanges = getRewardRanges(mCurrentState, nextState);
        final double[] reward = new double[rewardRanges.length];
        for (int i = 0; i < reward.length; ++i) {
            reward[i] = rewardRanges[i].calculateReward() * Math.pow(mParameters.discountFactor, mStepCount);
        }

        // Make the transition to the next state
        mCurrentState = nextState;
        ++mStepCount;

        return reward;
    }

    /**
     * Determines all possible outcomes given a state and discrete action. The states contain the reward that was
     * achieved through the transition.
     *
     * @param state
     *            The current state
     * @param action
     *            The action performed by the agent
     *
     * @return All possible resulting states mapped to their probabilities
     */
    public Map<RGState, Double> getPossibleTransitions(final RGState state, final RGDiscreteAction action) {
        final Map<RGState, Double> stateProbabilities = new HashMap<RGState, Double>();

        // Add a second fail step (handles no failure with the WAIT action)
        final int numSecondActions = (mParameters.actionFailProb > 0 ? mParameters.actionMax : 1);
        for (int actionIndex = 0; actionIndex < numSecondActions; ++actionIndex) {
            final RGState nextState = getNextState(state, action.getLocation(),
                    RGDiscreteAction.values()[actionIndex].getLocation());

            // Calculate the probability of transitioning to this state
            double probability;
            if (actionIndex == 0) {
                probability = 1.0 - mParameters.actionFailProb;
            } else {
                probability = mParameters.actionFailProb / (numSecondActions - 1);
            }

            // Add the state and probability to the possible outcomes
            if (stateProbabilities.containsKey(nextState)) {
                // Sum probabilities if one state can be reached through different ways
                probability += stateProbabilities.get(nextState);
            }
            stateProbabilities.put(nextState, probability);
        }

        return stateProbabilities;
    }

    /**
     * Determines the state resulting of performing an agent action and applying the failure action. Does not contain
     * any stochasticity.
     *
     * @param state
     *            The current state
     * @param agentAction
     *            The action chosen by the agent
     * @param failAction
     *            The action added as a failure
     *
     * @return The resulting next state
     */
    private RGState getNextState(final RGState state, final Location agentAction, final Location failAction) {
        // Set the agent's new location bound within the problem size
        Location nextAgent = Location.sum(state.getAgent(), Location.sum(agentAction, failAction));
        nextAgent = nextAgent.bound(0, mParameters.maxX, 0, mParameters.maxY);

        // Calculate the reward for this state and picks items up if needed
        final boolean[] pickedUp = state.getPickedUp();
        if (mParameters.pickUpOnCollect && state.getNumPickedUp(mParameters.resources) < mParameters.maxPickedUp) {
            int resourceIndex = 0;
            for (final Resource resource : mResources) {
                if (!pickedUp[resourceIndex] && resource.isCollected(nextAgent)) {
                    pickedUp[resourceIndex] = true;
                }
                ++resourceIndex;
            }
        }

        // Add the state and probability to the possible outcomes
        return new RGState(nextAgent, pickedUp);
    }

    /**
     * Determines the reward ranges that can be given for a state transition for every objective. Does NOT take discount
     * factors into account.
     *
     * @param initialState
     *            The state before transitioning
     * @param resultingState
     *            The state after transitioning
     *
     * @return The reward ranges for every objective
     */
    public RewardRange[] getRewardRanges(final RGState initialState, final RGState resultingState) {
        // Initialise the reward ranges and set the time reward
        final RewardRange[] reward = new RewardRange[mParameters.numResourceTypes + 1];
        reward[0] = TIME_REWARD;
        for (int i = 1; i < reward.length; ++i) {
            reward[i] = new RewardRange(0, 0);
        }

        // Sum the reward ranges of every picked up resource in their respective objective
        int resourceIndex = 0;
        if (initialState.getNumPickedUp(mParameters.resources) < mParameters.maxPickedUp) {
            for (final Resource resource : mResources) {
                if (!initialState.isPickedUp(resourceIndex) && resource.isCollected(resultingState.getAgent())) {
                    final int rewardIndex = resource.getType() + 1;
                    reward[rewardIndex] = reward[rewardIndex].sum(resource.getReward());
                }
                ++resourceIndex;
            }
        }

        return reward;
    }

    /**
     * Checks if the given state is terminal.
     *
     * @param state
     *            The state to check
     *
     * @return True iff the state is terminal
     */
    public boolean isTerminal(final RGState state) {
        return state.getAgent().equals(mGoal);
    }

    /**
     * @return The list of resources in the game
     */
    public List<Resource> getResources() {
        return Collections.unmodifiableList(mResources);
    }

    /**
     * @return The state that the problem is currently in
     */
    public RGState getCurrentState() {
        return mCurrentState;
    }

    /**
     * @return The location of the goal
     */
    public Location getGoal() {
        return mGoal;
    }

}