import globals.StopWatch;
import globals.Tuple;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import deltaiot.services.Link;
import deltaiot.services.Mote;
import problems.Mopomdp;
import problems.iot.DeltaIOTConnector;
import problems.iot.IOTActions;
import problems.iot.IOTStates;
import problems.iot.MOIOT;
import problems.maze20.MOMaze20;
import problems.maze20.Maze20States;
import problems.maze20.Maze20Transitions;
import problems.rdm.MORDM;
import problems.rdm.RDMStates;
import problems.rdm.RDMTransitions;
import problems.rdmthreeobjectives.MORDMThree;
import problems.rdmthreeobjectives.RDMActionsThree;
import problems.rdmthreeobjectives.RDMConfiguration;
import problems.rdmthreeobjectives.RDMStatesThree;
import problems.rdmthreeobjectives.RDMTransitionProb;
import problems.rdmthreeobjectives.RDMTransitionsThree;
import problems.tiger.MOTiger;
import simulator.QoS;
import solvers.linearsupport.LinearSupporter;
import solvers.linearsupport.RandomSampler;
import solvers.linearsupport.ReusingPerseusSolver;
import solvers.linearsupport.ValueVector;

import value.AlphaMatrix;
import value.CPruner;
import value.LazyScalarizedVector;
import value.SimpleVector;
import value.ValueAtBeliefVector;


public class ExperimentorIoT<A, V, O, X, Y> {

	private StopWatch stopwatch;
	
	
	
	
	public ExperimentorIoT(){	
		this.stopwatch = StopWatch.getGlobalStopWatch();
	}
	
	public ArrayList<Double> emptyEpsilonMatrix(int length){
		ArrayList<Double> row = new ArrayList<Double>(length);
		for(int i=0; i<length; i++){
			row.add(new Double(0));
		}
		return row;
	}
	
	private double getMean(ArrayList<ArrayList<Double>> data, int index)
    {
        double sum = 0.0;
        for(ArrayList<Double> a  : data)
            sum += a.get(index);
        return sum/data.size();
    }
	
	private Tuple<Double,Double> getMeanVariance(ArrayList<ArrayList<Double>> data, int index)
    {
        double mean = getMean(data, index);
        double temp = 0;
        for(ArrayList<Double> a : data)
            temp += (mean-a.get(index))*(mean-a.get(index));
        double var = temp/(data.size());
        return new Tuple<Double,Double>(mean,var);
    }

    private Tuple<Double,Double> getMeanStdDev(ArrayList<ArrayList<Double>> data, int index)
    {
    	Tuple<Double,Double> tup = getMeanVariance(data, index);
        return new Tuple<Double,Double>(tup.x,Math.sqrt(tup.y));
    }
	
	public ArrayList<Double> toEpsilon(ArrayList<SimpleVector<?>> vecs, ArrayList<SimpleVector<?>> refSet){
		ArrayList<Double> result = new ArrayList<Double>();
		ArrayList<SimpleVector<?>> part = new ArrayList<SimpleVector<?>>(vecs.size());
		for(int i=0; i<vecs.size(); i++){
			part.add(vecs.get(i));
			result.add(compareToRefSet(part, refSet));
		}
		return result;
	}
	
	public ArrayList<Double> epsilonTimeVector(ArrayList<Double> eps, ArrayList<Long> fromTimes, ArrayList<Long> toTimes){
		ArrayList<Double> result = new ArrayList<Double>(toTimes.size());
		long cTime; 
		int index = 0;
		for(int i=0; i<toTimes.size(); i++){
			cTime = toTimes.get(i);
			boolean b = true;
			while(b){
				if(index==(eps.size()-1)){
					b=false;
				} else {
					if(fromTimes.get(index+1)<cTime){
						index++;
					} else {
						b=false;
					}
				}
			}
			result.add(eps.get(index).doubleValue());
		}
		return result;
	}
	
		
	
	
	
	/////////////////////////////////////////////////////////////
	
	public <V extends SimpleVector<?>> boolean createRefSet(String filename, ArrayList<V> vecs){
		try {
			PrintWriter bw = new PrintWriter(new FileWriter(filename));
			System.out.println("value vector size"+vecs.size());
			for(int i=0; i<vecs.size(); i++){
				bw.println(vecs.get(i).toString()+"");
			}
			bw.flush();
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	@SuppressWarnings("resource")
	public ArrayList<SimpleVector<?>> readRefSetFromFile(String filename){
		ArrayList<String> sVecs = new ArrayList<String>();

	    // wrap a BufferedReader around FileReader
	    BufferedReader bufferedReader;
		try {
			bufferedReader = new BufferedReader(new FileReader(filename));
			while (bufferedReader.ready())
		    {
		    	String line = bufferedReader.readLine();
		        sVecs.add(line);
		    }
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}

		ArrayList<SimpleVector<?>> refSet = new ArrayList<SimpleVector<?>>(sVecs.size());
		for(int i=0; i<sVecs.size(); i++){
			SimpleVector<Integer> sv = new SimpleVector<Integer>(sVecs.get(i));
			refSet.add(sv);
		}
		
		return refSet;
	}
	
	public double compareToRefSet(ArrayList<SimpleVector<?>> vecs, ArrayList<SimpleVector<?>> refSet){
		CPruner<SimpleVector<?>> cpr = new CPruner<SimpleVector<?>>();
		double highestLoss = Double.NEGATIVE_INFINITY;
		for(int i=0; i<refSet.size(); i++){
			double imp = cpr.findImprovement(refSet.get(i), vecs);
			if(imp>highestLoss){
				highestLoss = imp;
			}
		}
		return highestLoss;
	}
	
	
	
	
			
		
		
		//@param dim3 boolean refers to the number of objectives true = 3 objectives and false=2 objectives
				public <A> boolean createRefSetIOT(boolean dim3){
					ReusingPerseusSolver.LOG = false;
					stopwatch.start();
					//double[] b0 = {0.3, 0, 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.4 };
					IOTStates s=new IOTStates();
					double[] b0=Mopomdp.uniformBelief(s);
					
					//double[] b0= {0.801,0.099,0.089,0.011};		
					MOIOT moiot = new MOIOT(dim3, b0, 0.9);
					//////////////////////////////////////////////////////////////////////
					
					//@param MOPOMDP, initial belief, nsamples 5000, maxiterations 500, precision, type of perseus solver
					ReusingPerseusSolver<Integer,Integer,Integer> reuser = 
							new ReusingPerseusSolver<Integer,Integer,Integer>(moiot,b0,500,500,0.000001, ReusingPerseusSolver.TYPE_FULL);
					reuser.initSamples();
					int d3 = dim3? 3 : 2;
					
					//@param Reusing Perseus Solver, precision, stopcrit, number of objectives
					LinearSupporter<Integer> lstst = new LinearSupporter<Integer>(reuser, 0.00000001, 0.00001, d3);
					reuser.setCPSreference(lstst);
					/////////////////////////////////////////////////////////////////////////////////////
					//ArrayList<ValueAtBeliefVector<Integer>> lst = lstst.runLinearSupport(48000000);
					
					//@param maxtime as a parameter
					ArrayList<ValueAtBeliefVector<Integer>> lst = lstst.runLinearSupport(48000000);
					
					
					/*
					for(int i=0;i<mordm.currentBelief().length;i++)
					{
						System.out.println("current belief  "+ mordm.currentBelief()[i]);
						
					}
					*/
					
					
					

					///////////Just to display values
					////Code to print values of the ValueAtBelief Vector ArrayList
					//System.out.println("size   "+lst.size());
					
				//	double scalarizedvals[]=new double[lst.size()];
					//for(int i=0;i<lst.size();i++)
					//{
						//System.out.println("Size of alpha matrix");
						//System.out.println(lst.get(i).alphas.size());
						//System.out.println("Value for state 0 and objective 0 in alpha matrix");
						//for(int j=0;j<lst.get(i).alphas.size();j++)
						//{ 
							//System.out.println("alpha matrix# "+j+"####################");
							/*for(int state=0;state<20;state++)
							{
								for(int obj=0;obj<2;obj++)
								{
									//System.out.println("Value for state"+state+ " and objective "+obj+" in alpha matrix");
									System.out.print(lst.get(0).alphas.get(0).getValue(state, obj)+"  ");
									
								}
								System.out.println("");
							}
						}*/
						/*
						System.out.println("\n\nweight length :"+lst.get(i).weight.length +" weight values  "+lst.get(i).weight[0]+"    "+lst.get(i).weight[1]);
						System.out.println("Simple Vector values"+lst.get(i).getValue().length);
						System.out.println("Values");
						System.out.println(lst.get(i).getValue()[0]+"    "+lst.get(i).getValue()[1]);
						
						System.out.println("Action Tag");
						System.out.println(lst.get(i).retrieveTags().size()+"   "+ lst.get(i).retrieveTags().toString());
						
						
						
						System.out.println(mordm.currentState()+"----current state");
						RDMTransitions mt=new RDMTransitions();
						Integer nxtst=mt.nextState(mordm.currentState(), lst.get(0).retrieveTags().get(0));
						System.out.println("next state-----"+nxtst);
						
						//Scalarization with weights
						
						scalarizedvals[i]=lst.get(i).linearScalValue(lst.get(i).weight);
						System.out.println("##########################################\n");
						System.out.println("scalarized value    "+ scalarizedvals[i]);
						System.out.println("\n##########################################\n");
						
						
						
						
						
						
						}
					
					double maxValue = scalarizedvals[0];
					  for(int j=1;j < scalarizedvals.length;j++){
					    if(scalarizedvals[j] > maxValue){
						  maxValue = scalarizedvals[j];
						}
					  }
					System.out.println("maxValue:  "+maxValue);
					 for(int j=1;j < scalarizedvals.length;j++){
						    if(scalarizedvals[j] == maxValue){
							  System.out.println("The selected action is:"+lst.get(j).retrieveTags().get(0).toString());
							  mordm.performAction(lst.get(j).retrieveTags().get(0));
							  System.out.println("new current state"+mordm.currentState());
							  //System.out.println("new current belief "+doolhof.currentBelief()[0]);
							  
							  
							}
						  }*/
					/*
					for(int timestep=0;timestep<5;timestep++) 
					{	
						System.out.println("\n\ntimestep  "+timestep);
					 /////////////////////////////////////////////////////
					 ///Executing for next action
					 ReusingPerseusSolver<Integer,Integer,Integer> reuser1 = 
								new ReusingPerseusSolver<Integer,Integer,Integer>(mordm,mordm.currentBelief(),5,5,0.000001, ReusingPerseusSolver.TYPE_FULL);
						reuser1.initSamples();
						int d33 = dim3? 3 : 2;
						
						//@param Reusing Perseus Solver, precision, stopcrit, number of objectives
						LinearSupporter<Integer> lstst1 = new LinearSupporter<Integer>(reuser1, 0.00000001, 0.00001, d33);
						reuser1.setCPSreference(lstst1);
						ArrayList<ValueAtBeliefVector<Integer>> lst1 = lstst1.runLinearSupport(600000);
						
						double scalarizedvals1[]=new double[lst1.size()];
						double maxValue1 = scalarizedvals1[0];
						  for(int j=1;j < scalarizedvals1.length;j++){
						    if(scalarizedvals1[j] > maxValue1){
							  maxValue1 = scalarizedvals1[j];
							}
						  }
						System.out.println("maxValue:  "+maxValue1);
						 for(int j=1;j < scalarizedvals1.length;j++){
							    if(scalarizedvals1[j] == maxValue1){
							    	if(lst1.get(j).retrieveTags().get(0)!=null)
							    	{
								  System.out.println("The selected action is:"+lst1.get(j).retrieveTags().get(0));
								  mordm.performAction(lst1.get(j).retrieveTags().get(0));
								  System.out.println("new current state"+mordm.currentState());
								  //System.out.println("new current belief "+doolhof.currentBelief()[0]);
							    	}
								  
								  
								}
							  }
						
					}
					 /////////////////////////////////////////////////////
						*/
					
					
					
					
					boolean b = this.createRefSet("iot"+d3+"ref.txt", lst);
					
					stopwatch.stop();
					System.out.println("iot"+d3+"ref.txt created in "+ stopwatch.totalElapsedTime() + "ms");
					return b;
				}
				
				/**
				 * Method to test IoT case study using MRPOMDP
				 * 
				 * @param dim3
				 * @param type_none
				 * @param type_full
				 * @param random_solver
				 * @param random_solver_without
				 * @param maxTime
				 * @param timeInterval
				 * @param bsetsize
				 */
				public void testIOT(boolean dim3, 
						boolean type_none, boolean type_full, 
						boolean random_solver, boolean random_solver_without,
						long maxTime, int timeInterval, int bsetsize){
					
					
					
					DeltaIOTConnector dc=new DeltaIOTConnector();
					
					ArrayList<SimpleVector<?>> refset;
					if(dim3)
						refset = readRefSetFromFile("iot3ref.txt"); 
					else 
						refset = readRefSetFromFile("iot2ref.txt"); 
					
					ReusingPerseusSolver.LOG = true;
					
					ArrayList<Long> times = new ArrayList<Long>(); 
					long time = 0; 
					while(time<maxTime){
						time+=timeInterval;
						times.add(time);
					}
					
					int repeat=1;
					
					int nSamples = 1000;
					int d3 = dim3? 3 : 2;
					//double[] b02 = {0.5, 0.5, 0}; double[] vc = {0.5, 0.5, 0};
					ArrayList<Long> endTimesNone = new ArrayList<Long>(repeat);
					ArrayList<Long> endTimesFull = new ArrayList<Long>(repeat);
					ArrayList<Long> endTimesCPS  = new ArrayList<Long>(repeat);
					ArrayList<Long> endTimesClose= new ArrayList<Long>(repeat);
					ArrayList<Long> endTimesRandom= new ArrayList<Long>(repeat);
					ArrayList<Long> endTimesRW= new ArrayList<Long>(repeat);
					
					ArrayList<Double> epsMeanNone = new ArrayList<Double>(repeat);
					ArrayList<Double> epsMeanFull = new ArrayList<Double>(repeat);
					ArrayList<Double> epsMeanCPS  = new ArrayList<Double>(repeat);
					ArrayList<Double> epsMeanClose= new ArrayList<Double>(repeat);
					ArrayList<Double> epsMeanRandom= new ArrayList<Double>(repeat);
					ArrayList<Double> epsMeanRW= new ArrayList<Double>(repeat);
					
					ArrayList<Double> epsStdvNone = new ArrayList<Double>(repeat);
					ArrayList<Double> epsStdvFull = new ArrayList<Double>(repeat);
					ArrayList<Double> epsStdvCPS  = new ArrayList<Double>(repeat);
					ArrayList<Double> epsStdvClose= new ArrayList<Double>(repeat);
					ArrayList<Double> epsStdvRandom= new ArrayList<Double>(repeat);
					ArrayList<Double> epsStdvRW= new ArrayList<Double>(repeat);
					
					////////////////////////////////////
					// need to assign current belief value
					/////////////////////////////////////
					IOTStates rs=new IOTStates();
					double[] b0=Mopomdp.uniformBelief(rs);
					//double[] b0= {0.801,0.099,0.089,0.011};	
					//System.out.println("Belief value: "+b0[0]);
					MOIOT moiot = new MOIOT(dim3, b0, 0.9);
					ReusingPerseusSolver<Integer,Integer,Integer> reuser;
					LinearSupporter<Integer> lstst=null;
					ArrayList<ValueAtBeliefVector<Integer>> lst=null;
					String res="";
					String res_ValMec="";
					String res_ValMr="";
					String res_WtMec="";
					String res_WtMr="";
					String res_action="";
					
					Integer cstate=moiot.currentState();
					double cbelief[]=moiot.currentBelief;
			try {
				FileWriter fw=new FileWriter("ResultsIOT.txt");
				PrintWriter pw=new PrintWriter(fw);
				FileWriter fw1=new FileWriter("ValMECIOT.txt");
				PrintWriter pw1=new PrintWriter(fw1);
				FileWriter fw2=new FileWriter("ValRPLIOT.txt");
				PrintWriter pw2=new PrintWriter(fw2);
				FileWriter fww1=new FileWriter("WtMECIOT.txt");
				PrintWriter pww1=new PrintWriter(fww1);
				FileWriter fww2=new FileWriter("WtRPLIOT.txt");
				PrintWriter pww2=new PrintWriter(fww2);
				FileWriter fwact=new FileWriter("selectedactionIOT.txt");
				PrintWriter pwact=new PrintWriter(fwact);
				
				FileWriter fwmec=new FileWriter("IoTMECsat.txt");
				PrintWriter pwmec=new PrintWriter(fwmec);
				FileWriter fwrpl=new FileWriter("IoTRPLsat.txt");
				PrintWriter pwrpl=new PrintWriter(fwrpl);
				
				FileWriter fwmectimestep=new FileWriter("IoTMECsattimestep.txt");
				PrintWriter pwmectimestep=new PrintWriter(fwmectimestep);
				FileWriter fwrpltimestep=new FileWriter("IoTRPLsattimestep.txt");
				PrintWriter pwrpltimestep=new PrintWriter(fwrpltimestep);
				
				FileWriter fwmecsat=new FileWriter("IoTMECSATprob.txt");
				PrintWriter pwmecsat=new PrintWriter(fwmecsat);
				FileWriter fwrplsat=new FileWriter("IoTRPLSATprob.txt");
				PrintWriter pwrplsat=new PrintWriter(fwrplsat);
				
				FileWriter fwalt =new FileWriter("AlternativeValuesIoT.txt");
				PrintWriter pwalt=new PrintWriter(fwalt);
				
				
			/*	for(int i=0;i<90;i++)
				{
					
				DeltaIOTConnector.motes = DeltaIOTConnector.networkMgmt.getProbe().getAllMotes();
				//group[i].add(DeltaIOTConnector.motes);
				System.out.println("motes received");
				}*/
				
				


				
				for(int timestep=0;timestep<50;timestep++)
				{
					
					DeltaIOTConnector.timestepiot=timestep;
					System.out.println("timestep: "+timestep);
					
					////Monitor Checking
					DeltaIOTConnector.motes = DeltaIOTConnector.networkMgmt.getProbe().getAllMotes();
					
					
					System.out.println("motes recieved");
					//monitor Checking
					
					for(Mote m:DeltaIOTConnector.motes)
					{
						
						//System.out.println("Mote"+m.getMoteid()+" traffic load: "+m.getLoad());
						
						//System.out.println("MOte Distribution factor"+DeltaIOTConnector.networkMgmt.getProbe().getLinkDistributionFactor(m.getMoteid(), m.getParents()));
					////Monitor
						//DeltaIOTConnector.motes = DeltaIOTConnector.networkMgmt.getProbe().getAllMotes();
						DeltaIOTConnector.networkMgmt.simulator.doSingleRun();
						
						//System.out.println("motes recieved");
					
					DeltaIOTConnector.selectedmote=m;
					//DeltaIOTConnector.motes=null;
					
					//for (int j1=0;j1<dc.moteids.length;j1++) {
						//System.out.println(dc.moteids[j1]);
						//dc.selectedindex=j1;
						
						//DeltaIOTConnector.selectedmote=m;
						//System.out.println(DeltaIOTConnector.selectedmote.getMoteid());
						
					//}
						
						//DeltaIOTConnector.selectedmote=dc.getMoteById(dc.moteids[j1]);
					
					//for(Mote m:DeltaIOTConnector.motes)
					//{
						//DeltaIOTConnector.selectedmote=m;
						
					
					if(type_full){
						ArrayList<ArrayList<Double>> epsCollection = new ArrayList<ArrayList<Double>>(repeat);
						for(int i=0; i<repeat; i++){
							MOIOT.stopwatchiot.reset();
							System.out.println("running type full");
							ReusingPerseusSolver.resetMeasurement(true);
							
							System.out.print("checking Current Belief~~~~~~~~~~~~~~");
							for(int i1=0;i1<moiot.currentBelief().length;i1++)
								{
									System.out.print(moiot.currentBelief()[i1]+"  ");
									
								}
								
							System.out.println();
							
						//////Current Belief Marginilization/////////////////////////////////////////////////////////////

							String iotMECSat="";
							double mecsat=moiot.currentBelief()[0]+moiot.currentBelief()[1];
							iotMECSat=iotMECSat+timestep+" "+mecsat;	
							pwmecsat.println(iotMECSat);

							String RPLSat="";
							double RPLsat=moiot.currentBelief()[0]+moiot.currentBelief()[2];
							RPLSat=RPLSat+timestep+" "+RPLsat;	
							pwrplsat.println(RPLSat);
							
							////////////////////////////////////////////////////////////////////
							
							
							if(timestep==0) {
								//cstate=mordm.currentState();
								//reuser = new ReusingPerseusSolver<Integer,Integer,Integer>(moiot,b0,bsetsize,500,0.000001, ReusingPerseusSolver.TYPE_FULL);
								reuser = new ReusingPerseusSolver<Integer,Integer,Integer>(moiot,moiot.currentBelief(),bsetsize,500,0.000001, ReusingPerseusSolver.TYPE_FULL);
							}
							else {
								//cstate=mordm.currentState();
								reuser = new ReusingPerseusSolver<Integer,Integer,Integer>(moiot,moiot.currentBelief(),bsetsize,100,0.000001, ReusingPerseusSolver.TYPE_FULL);
								//reuser = new ReusingPerseusSolver<Integer,Integer,Integer>(moiot,b0,bsetsize,500,0.000001, ReusingPerseusSolver.TYPE_FULL);
								
								System.out.println("Perseus");
							}
							//reuser = new ReusingPerseusSolver<Integer,Integer,Integer>(mordm,b0,bsetsize,500,0.000001, ReusingPerseusSolver.TYPE_FULL);
							DeltaIOTConnector.refsetcreation=true;
							reuser.initSamples();
							DeltaIOTConnector.refsetcreation=false;
							//System.out.println("DeltaIOTConnector.refsetcreation"+DeltaIOTConnector.refsetcreation);
							lstst = new LinearSupporter<Integer>(reuser, 0.00000001, 0.00001, d3);
							reuser.setCPSreference(lstst);
							//System.out.println("DeltaIOTConnector.refsetcreation"+DeltaIOTConnector.refsetcreation);

							MOIOT.stopwatchiot.start();
							lst = lstst.runLinearSupport(1500);
							
							//System.out.println("DeltaIOTConnector.refsetcreation"+DeltaIOTConnector.refsetcreation);

							/*for(int il=0;il<lst.size();il++)
							{
								System.out.println("Checking lst tags");
								System.out.println("Tag: "+lst.get(il).retrieveTags().get(0));
								
							}*/
							
							ArrayList<SimpleVector<?>> veccies = ReusingPerseusSolver.valuelist; 
							refset.addAll(veccies);
							ArrayList<Long> timez = ReusingPerseusSolver.timelist; 
							//endTimesFull.add(timez.get(timez.size()-1));
							System.out.print("f");
							ArrayList<Double> epss = this.toEpsilon(veccies, refset);
							ArrayList<Double> epssbis = this.epsilonTimeVector(epss, timez, times);
							epsCollection.add(epssbis);	
							
							DeltaIOTConnector.refsetcreation=false;
							
							
							
						}
						for(int i=0; i<times.size(); i++){
							Tuple<Double,Double> meanStdv = this.getMeanStdDev(epsCollection, i);
							epsMeanFull.add(meanStdv.x);
							epsStdvFull.add(meanStdv.y);
						}
						System.out.println("+");
					} else {
						for(int i=0; i<times.size(); i++){
							epsMeanFull.add(0.0);
							epsStdvFull.add(0.0);
						}
					}
					
					
					if(timestep==0)//timestep check
					{
						
					//Display Epsilon Value (error value)
					System.out.println();
					for(int i=0; i<times.size(); i++){
						System.out.print(""+times.get(i)+" milliseconds ");
						System.out.print("Epsilon Mean: "+epsMeanFull.get(i)+", Epsilon Std Deviation: "+epsStdvFull.get(i)+",");
						
						System.out.println();
					}
					
					
					System.out.println();
					System.out.print("endFull <- c(");
					/*for(int i=0; i<endTimesFull.size(); i++){
						System.out.print(endTimesFull.get(i));
						if(i<endTimesFull.size()-1)
							System.out.print(",");
						else
							System.out.print(")");
					}*/
					}//end of timestep check
					
					res+="current belief: ";
					
					for(int i=0;i<moiot.currentBelief().length;i++)
					{
						res+=moiot.currentBelief()[i]+"  ";
						
					}
					res+="\n";
					
					
					
			System.out.println("\nValue at Belief Vector size"+lst.size());
			
			for(int i=0;i<lstst.vvs.size();i++)
			{
				System.out.println(""+lstst.vvs.get(i).valueAtSearchWeights[0]);
				System.out.println(""+lstst.vvs.get(i).p.retrieveTags());
				System.out.println(""+lstst.vvs.get(i).p.getValue()[0]+" "+lstst.vvs.get(i).p.getValue()[1]+" ");
				
				System.out.println(""+lstst.vvs.get(i).searchWeights.get(0)[0]+"  "+lstst.vvs.get(i).searchWeights.get(0)[1]);
				lst.get(i).weight=lstst.vvs.get(i).searchWeights.get(0);
				
				
			}
			
			/*for(int i=0;i<lst.size();i++)
			{
				System.out.println(lst.get(i).retrieveTags());
				Double valvb=lst.get(i).linearScalValue(lst.get(i).weight);
				System.out.println(valvb);	
				System.out.println(lst.get(i).getValue()[0]+"  "+lst.get(i).getValue()[1]);
				System.out.println(lst.get(i).weight[0]+"  "+lst.get(i).weight[1]);
				
			}*/
					
		////////////////////////////
		//////checking max value at belief vector
		ArrayList<Double> maxxvall=new ArrayList<Double>();

		for(int i=0;i<lst.size();i++)
		{

		Double valvb=lst.get(i).linearScalValue(lst.get(i).weight);
		maxxvall.add(valvb);

		}

		double maxValue2 = maxxvall.get(0);
		for(int j=1;j < maxxvall.size();j++){
		if(maxxvall.get(j) > maxValue2){
		maxValue2 = maxxvall.get(j);
		}
		}

		for(int i=0;i<maxxvall.size();i++)
		{
		if(maxValue2==maxxvall.get(i))
		{ 
			
		System.out.println("###############################################################");
		System.out.println("selected weights :"+lst.get(i).weight[0]+" "+lst.get(i).weight[1]);
		System.out.println("selected action    tag :"+lst.get(i).retrieveTags().get(0));
		System.out.println("selected value    valuevec:"+lst.get(i).getValue()[0]+" "+lst.get(i).getValue()[1]);
		System.out.println("###############################################################");
		

		res+="Time Step: "+timestep+" ";
		res_ValMec+=timestep+" ";
		res_ValMr+=timestep+" ";
		res_WtMec+=timestep+" ";
		res_WtMr+=timestep+" ";
		res_action+=timestep+" ";
		
		
		

		moiot.currentState=cstate.intValue();
		moiot.currentBelief=cbelief;

		res+="Current State: "+moiot.currentState()+"  ";
		

		System.out.println("hello Current State: "+moiot.currentState());
		//if(lstst.listmaxlnsupp.get(i).retrieveTags().get(0)!=null)
		//{
			
		res+="Selected Action: "+lst.get(i).retrieveTags().get(0).toString()+" ";
		res_action+=lst.get(i).retrieveTags().get(0).toString();
		//DeltaIOTConnector.refsetcreation=false;
		//moiot.performAction(IOTActions.DTP);
		//System.out.println("Action:   "+lstst.listmaxlnsupp.get(i).retrieveTags().get(0));
		System.out.println("performing actionnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
		moiot.performAction(lst.get(i).retrieveTags().get(0));
		//DeltaIOTConnector.refsetcreation=true;
		//}
		System.out.println("hello new current state"+moiot.currentState());
		res+="Next State: "+moiot.currentState()+"  ";
		cstate=moiot.currentState();
		cbelief=moiot.currentBelief();
		System.out.println();
		

		res+="value vector:"+lst.get(i).getValue()[0]+" "+lst.get(i).getValue()[1]+" ";
		res_ValMec+=lst.get(i).getValue()[0];
		res_ValMr+=lst.get(i).getValue()[1];

		res+="selected weights"+lst.get(i).weight[0]+" "+lst.get(i).weight[1]+" ";
		res_WtMec+=lst.get(i).weight[0];
		res_WtMr+=lst.get(i).weight[1];

		pw.println(res);
		pw1.println(res_ValMec);
		pw2.println(res_ValMr);
		pww1.println(res_WtMec);
		pww2.println(res_WtMr);
		pwact.println(res_action);
		res="";
		res_action="";
		res_ValMec="";
		res_ValMr="";
		res_WtMec="";
		res_WtMr="";
		}

		}
		
		
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("vb scalarized maxValuelsssssss:  "+maxValue2);

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		lstst.listmaxlnsupp.clear();
		maxxvall.clear();

					
					
					
					
					///////////Just to display values
					////Code to print values of the ValueAtBelief Vector ArrayList
					//System.out.println("size   "+lst.size());
					//////////////////////////////////////////////////////////////////////////*************
					
					
			
					//////~~~~~~~~~~double scalarizedvals[]=new double[lst.size()];
					///////~~~for(int i=0;i<lst.size();i++)
					//////~#############{
						//System.out.println("Size of alpha matrix");
						//System.out.println(lst.get(i).alphas.size());
						//System.out.println("Value for state 0 and objective 0 in alpha matrix");
						//for(int j=0;j<lst.get(i).alphas.size();j++)
						//{ 
							//System.out.println("alpha matrix# "+j+"####################");
							/*for(int state=0;state<20;state++)
							{
								for(int obj=0;obj<2;obj++)
								{
									//System.out.println("Value for state"+state+ " and objective "+obj+" in alpha matrix");
									System.out.print(lst.get(0).alphas.get(0).getValue(state, obj)+"  ");
									
								}
								System.out.println("");
							}
						}*/
						
						//new comment
						///////////////////*****************************
						/*System.out.println("\n\nweight length :"+lst.get(i).weight.length +" weight values  "+lst.get(i).weight[0]+"    "+lst.get(i).weight[1]);
						//System.out.println("Simple Vector values"+lst.get(i).getValue().length);
						System.out.println("Values");
						System.out.println(lst.get(i).getValue()[0]+"    "+lst.get(i).getValue()[1]);
						
						System.out.println("Action Tag");
						System.out.println(lst.get(i).retrieveTags().size()+"   "+ lst.get(i).retrieveTags().toString());
						*/
						/////////////////******************
						
						//System.out.println("current state: "+mordm.currentState());
						//RDMTransitions mt=new RDMTransitions();
						//Integer nxtst=mt.nextState(mordm.currentState(), lst.get(0).retrieveTags().get(0));
						//System.out.println("next state:"+nxtst);
						
						//Scalarization with weights
						
						/////////~~~~~~~~~~~~scalarizedvals[i]=lst.get(i).linearScalValue(lst.get(i).weight);
						//System.out.println("##########################################\n");
						//System.out.println("scalarized value    "+ scalarizedvals[i]);
						//System.out.println("\n##########################################\n");
						
						
						//////////~~~~~~~~~~~~~~~~~~~~}
					
					/*for(int i=0;i<scalarizedvals.length;i++)
					{
						System.out.println(i+": scalarized value: "+scalarizedvals[i]);
					}*/
					
				/*	double maxValue = scalarizedvals[0];
					  for(int j=1;j < scalarizedvals.length;j++){
					    if(scalarizedvals[j] > maxValue){
						  maxValue = scalarizedvals[j];
						}
					  }
					  
					System.out.println("maxValue:  "+maxValue);
					
					
					 for(int j=1;j < scalarizedvals.length;j++){
						    if(scalarizedvals[j] == maxValue){
						       res+="Time Step: "+timestep+" ";
						       mordm.currentState=cstate.intValue();
						       res+="Current State: "+mordm.currentState()+"  ";
						       res+="Selected Action: "+lst.get(j).retrieveTags().get(0).toString()+" ";
						       
						       //mordm.currentState=cstate.intValue();
						       
						      System.out.println("Value Vector: "+lst.get(j).getValue()[0]+"  "+lst.get(j).getValue()[1]);
						      
						      //System.out.println("current state"+mordm.currentState());
							  System.out.println("The selected action is:"+lst.get(j).retrieveTags().get(0).toString());
							  System.out.println("The ccurrent weights :"+lst.get(j).weight[0]+"  "+lst.get(j).weight[1]);
							  mordm.performAction(lst.get(j).retrieveTags().get(0));
							  System.out.println("new current state"+mordm.currentState());
							  cstate=mordm.currentState();
							  res+=" Next State: "+mordm.currentState()+" ";
							  res+="Value Vector: "+lst.get(j).getValue()[0]+"  "+lst.get(j).getValue()[1]+" \n ";
							  
							  pw.println(res);
							  res="";
							  
							}
						  }*/
					 /*///////////////////////////***********************************
					 	///////////////////////////////////////********************
					/*for(int timestep=0;timestep<5;timestep++) 
					{	
						System.out.println("\n\ntimestep  "+timestep);
					 /////////////////////////////////////////////////////
					 ///Executing for next action
					 ReusingPerseusSolver<Integer,Integer,Integer> reuser1 = 
								new ReusingPerseusSolver<Integer,Integer,Integer>(mordm,mordm.currentBelief(),bsetsize,50,0.000001, ReusingPerseusSolver.TYPE_FULL);
						reuser1.initSamples();
						int d33 = dim3? 3 : 2;
						
						//@param Reusing Perseus Solver, precision, stopcrit, number of objectives
						LinearSupporter<Integer> lstst1 = new LinearSupporter<Integer>(reuser1, 0.00000001, 0.00001, d33);
						reuser1.setCPSreference(lstst1);
						ArrayList<ValueAtBeliefVector<Integer>> lst1 = lstst1.runLinearSupport(600000);
						
						double scalarizedvals1[]=new double[lst1.size()];
						double maxValue1 = scalarizedvals1[0];
						  for(int j=1;j < scalarizedvals1.length;j++){
						    if(scalarizedvals1[j] > maxValue1){
							  maxValue1 = scalarizedvals1[j];
							}
						  }
						System.out.println("maxValue:  "+maxValue1);
						 for(int j=1;j < scalarizedvals1.length;j++){
							    if(scalarizedvals1[j] == maxValue1){
							    	if(lst1.get(j).retrieveTags().get(0)!=null)
							    	{
							    		System.out.println("The selected action is:"+lst1.get(j).retrieveTags().get(0));
							    		mordm.performAction(lst1.get(j).retrieveTags().get(0));
							    		System.out.println("new current state"+mordm.currentState());
							    	}
								  
								  
								  
								}
							  }
						
					}*/
					 /////////////////////////////////////////////////////
						
				//}///end of time step for loop	
				String pls="";
				String ecs="";
				
				//ArrayList<QoS> result = DeltaIOTConnector.networkMgmt.getNetworkQoS(DeltaIOTConnector.timestepiot+1);
				//DeltaIOTConnector.networkMgmt.simulator.resetGatewaysAggregatedValues();
				
				
				
				ArrayList<QoS> result = DeltaIOTConnector.networkMgmt.getNetworkQoS(DeltaIOTConnector.timestepiot+1);
				
				//ArrayList<QoS> result=(ArrayList<QoS>)DeltaIOTConnector.networkMgmt.simulator.getQosValues();
				System.out.println("QOS list size: "+result.size());
				
				double pl=result.get(result.size()-1).getPacketLoss();
				double ec=result.get(result.size()-1).getEnergyConsumption();
				System.out.println("packet loss: "+pl+"   "+ec);
				pls=timestep+" ";
				ecs=timestep+" ";
				pls=pls+pl;
				ecs=ecs+ec;
				pwmec.println(ecs);
				pwrpl.println(pls);
				
				
				
				
				
						
				}// motes for loop	
					
					String plstimestep="";
					String ecstimestep="";
					ArrayList<QoS> result1 = (ArrayList<QoS>)DeltaIOTConnector.networkMgmt.simulator.getQosValues();
					
					double pl1=result1.get(result1.size()-1).getPacketLoss();
					double ec1=result1.get(result1.size()-1).getEnergyConsumption();
					plstimestep=timestep+" ";
					ecstimestep=timestep+" ";
					plstimestep=plstimestep+pl1;
					ecstimestep=ecstimestep+ec1;
					pwmectimestep.println(ecstimestep);
					pwrpltimestep.println(plstimestep);
					
					
					
					//DeltaIOTConnector.motes = DeltaIOTConnector.networkMgmt.getProbe().getAllMotes();
					//DeltaIOTConnector.motes=DeltaIOTConnector.getAllMotes();
					DeltaIOTConnector.timestepiot++;
					//System.gc();
			}//timestep for loop
				
				ArrayList<QoS> result = DeltaIOTConnector.networkMgmt.getNetworkQoS(DeltaIOTConnector.timestepiot+1);
				
				System.out.println("Run, PacketLoss, EnergyConsumption");
				result.forEach(qos -> System.out.println(qos)); 
			 	pw.flush();
			 	pw1.flush();
			 	pw2.flush();
			 	pww1.flush();
			 	pww2.flush();
			 	pwact.flush();
			 	pwmec.flush();
				pwrpl.flush();
				pwmectimestep.flush();
				pwrpltimestep.flush();
				pwrplsat.flush();
				pwmecsat.flush();
				
				pwrplsat.close();
				pwmecsat.close();
				fwmecsat.close();
				fwrplsat.close();
			 	
			 	pw.close();
			 	pw1.close();
			 	pw2.close();
			 	pww1.close();
			 	pww2.close();
			 	pwact.close();
			 	pwmec.close();
				pwrpl.close();
				pwrpltimestep.close();
				pwmectimestep.close();
			 	
			 	fw.close();
			 	fw1.close();
			 	fw2.close();
			 	fww1.close();
			 	fww2.close();
			 	fwact.close();
			 	fwmec.close();
			 	fwrpl.close();
			 	fwrpltimestep.close();
			 	fwmectimestep.close();
			  }catch(Exception ioex)
			  {
				  ioex.printStackTrace();
			 
			  }		
		 }
				
	
		
}