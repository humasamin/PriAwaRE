package solvers.linearsupport;

import globals.CentralStatics;

import java.util.ArrayList;
import java.util.Random;

import value.ValueAtBeliefVector;

public class RandomSampler<T> implements ValueCollection<T>{

	private SingleSolver<T> singleSolver;
	private int dim;
	public ArrayList<ValueVector<T>> vvs;
	
	public RandomSampler(SingleSolver<T> sw, int dimensions){
		this.dim = dimensions;
		this.singleSolver = sw;
		this.vvs = new ArrayList<ValueVector<T>>();
	}
	
	public ArrayList<ValueAtBeliefVector<T>> runSampleSolver(long maxTime, int maxIter){
		ArrayList<ValueAtBeliefVector<T>> result = new ArrayList<ValueAtBeliefVector<T>>();
		
		long startTime = System.currentTimeMillis();
		boolean timeout = maxTime < (System.currentTimeMillis()-startTime);
		int iter = 0;
		while(iter<maxIter && !timeout){
			Random r = CentralStatics.getCentralRandom();
			double[] w = new double[dim];
			double tot = 0;
			for(int i=0; i<dim; i++){
				w[i] = r.nextDouble();
				tot += w[i];
			}
			for(int i=0; i<dim; i++){
				w[i] = w[i]/tot;
			}
			ValueAtBeliefVector<T> p = singleSolver.solveForW(w);
			ValueVector<T> vv = new ValueVector<T>(p,w);
			this.vvs.add(vv);
			result.add(p);
			timeout = maxTime < (System.currentTimeMillis()-startTime);
			iter++;
		}
		return result;
	}
	
	public ArrayList<ValueVector<T>> getValueVectors(){
		return this.vvs;
	}
}
