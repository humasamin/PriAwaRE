package solvers.linearsupport;

import value.ValueAtBeliefVector;

public interface SingleSolver<T> {
	public ValueAtBeliefVector<T> solveForW(CornerPoint<T> cp);
	public ValueAtBeliefVector<T> solveForW(double[] w);
}
