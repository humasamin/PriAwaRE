package solvers.linearsupport;

import java.util.Comparator;

public class CPComparator<T> implements Comparator<CornerPoint<T>> {

	@Override
	public int compare(CornerPoint<T> arg0, CornerPoint<T> arg1) {
		if(arg0.maxError==arg1.maxError){
			return 0;
		} else if (arg0.maxError>arg1.maxError){
			return -1;
		} else {
			return 1;
		}
	}

}
