package solvers.linearsupport;
import globals.CentralStatics;

import java.text.DecimalFormat;
import java.util.ArrayList;

import value.ValueAtBeliefVector;

public class ValueVector<T> {
	public ValueAtBeliefVector<T> p;//The payoff vector
	public ArrayList<double[]> searchWeights;//weight vectors searched for which this ValueVector was found.
	public ArrayList<CornerPoint<T>> cornerPoints;//CornerPoints involving this ValueVector
	
	public double[] valueAtSearchWeights;
	
	public ValueVector(ValueAtBeliefVector<T> p_, double[] w){
		searchWeights = new ArrayList<double[]>();
		searchWeights.add(w);
		p=p_;
		cornerPoints = new ArrayList<CornerPoint<T>>();
		//valueAtSearchWeights = 
		calcValAtSearchWeights();
	}
	
	public void calcValAtSearchWeights(){
		this.valueAtSearchWeights = new double[this.searchWeights.size()];
		for(int i=0; i<this.valueAtSearchWeights.length; i++){
			this.valueAtSearchWeights[i] = CentralStatics.innerProduct(this.searchWeights.get(i), this.p.getValue());
		}
	}
	
	public void addSearchWeight(double[] w){
		this.searchWeights.add(w);
		this.calcValAtSearchWeights();
	}
	
	public ArrayList<double[]> getSearchWeights(){
		return this.searchWeights;
	}
	
	public String toString(){
		DecimalFormat df = new DecimalFormat("#.##");
		String result="@";
		for(int x=0; x<this.searchWeights.size(); x++){
			result+="(";
			for(int i=0; i<this.searchWeights.get(x).length;i++){
				result+=df.format(this.searchWeights.get(x)[i]);
				if(i!=this.searchWeights.get(x).length-1){
					result+=",";
				} else {
					result+=")";
				}
			}
		}
		
		return result;
	}
	
	public boolean equals(ValueVector<T> vv){
		for(int i=0; i<this.p.getValue().length; i++){
			if(this.p.getValue(i) != vv.p.getValue(i)){
				return false;
			}
		}
		return true;
	}
	
	public boolean equals(ValueAtBeliefVector<T> py){
		for(int i=0; i<this.p.length(); i++){
			if(this.p.getValue(i) != py.getValue(i)){
				return false;
			}
		}
		return true;
	}
}
