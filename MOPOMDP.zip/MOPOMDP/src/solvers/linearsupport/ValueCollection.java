package solvers.linearsupport;

import java.util.ArrayList;

public interface ValueCollection<T> {
	public ArrayList<ValueVector<T>> getValueVectors();
}
