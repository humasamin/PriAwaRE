package solvers.linearsupport;

import globals.CentralStatics;

import java.util.ArrayList;
import java.util.Random;

import value.ValueAtBeliefVector;

public class ListMaximizor<T> implements SingleSolver<T>{

	public ArrayList<ValueAtBeliefVector<T>> list;
	
	public ListMaximizor(ArrayList<ValueAtBeliefVector<T>> in){
		list = in;
	}
	
	public ListMaximizor(){
		list = new ArrayList<ValueAtBeliefVector<T>>();
	}
	
	public void setExampleList(){
		double[] w = new double[3];
		ValueAtBeliefVector<T> p;
		w[0]= 1; w[1]= 0; w[2]=0;
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
		w[0]= 0; w[1]= 0; w[2]= 1;
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
		w[0]= 0; w[1]= 1; w[2]= 0;
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
		w[0]= 0.4; w[1]= 0.4; w[2]=0.4;
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
		w[0]= 0.7; w[1]= 0; w[2]= 0.2;
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
		w[0]= 0.5; w[1]= 0.25; w[2]= 0.5;
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
	}
	
	public void setExampleList2D(){
		double[] w = new double[2];
		ValueAtBeliefVector<T> p;
		w[0]= 12; w[1]= 0; 
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
		w[0]= 0; w[1]= 0; 
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
		w[0]= 0; w[1]= 12;
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
		w[0]= 8; w[1]= 8; 
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
		w[0]= 7; w[1]= 9; 
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
		w[0]= 6; w[1]= 5;
		p = new ValueAtBeliefVector<T>(w);
		this.list.add(p);
	}
	
	public void setExampleList2DRandom(int n){
		double[] w = new double[2];
		Random r = CentralStatics.getCentralRandom();
		//r.setSeed(11142);
		for(int i=0; i<n; i++){
			w[0]= r.nextDouble()*1000; 
			w[1]= r.nextDouble()*1000; 
			ValueAtBeliefVector<T> p = new ValueAtBeliefVector<T>(w);
			this.list.add(p);
		}
	}
	
	@Override
	public ValueAtBeliefVector<T> solveForW(CornerPoint<T> cp) {
		double[] w = cp.weightVector;
		return this.solveForW(w);
	}

	@Override
	public ValueAtBeliefVector<T> solveForW(double[] w) {
		ValueAtBeliefVector<T> best = null;
		double scalValueBest = Double.MIN_VALUE;
		
		for(int i=0; i<list.size(); i++){
			ValueAtBeliefVector<T> curr = list.get(i);
			double currScalVal = curr.linearScalValue(w);
			if(currScalVal>scalValueBest){
				best=curr;
				scalValueBest = currScalVal;
			}
		}
		if(best==null){System.err.println("wtf! "+w[0]+","+w[1]);}
		return best;
	}

}
