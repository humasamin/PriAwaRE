package solvers.vi;

import globals.CentralStatics;
import globals.Tuple;

import java.awt.Desktop.Action;
import java.util.ArrayList;

import problems.Mopomdp;

public class BeliefSampler<S,A,O> {
	
	private Mopomdp<S,A,O> pomdp; 
	
	private final static boolean DEBUG=false;
	
	public BeliefSampler(Mopomdp<S,A,O> problem){
		this.pomdp = problem;
	}
	
	private boolean contains (ArrayList<double[]> list, double[] candidate){
		for(int i=0; i<list.size(); i++){
			double[] compare = list.get(i);
			if(CentralStatics.equalVectors(compare, candidate)){
				return true;
			}
		}
		return false;
	}
	
	public ArrayList<double[]> randomExplorationPerseus(int nSamples){
		//nSamples=100;
		ArrayList<double[]> result = new ArrayList<double[]>(nSamples);
		this.pomdp.reInitialize(); 
		result.add(this.pomdp.currentBelief());
		
		while(result.size()<nSamples+1){
			/////checking
			//System.out.println("checking results size"+result.size());
			//System.out.println("checking nsamples"+nSamples+1);
			A act = this.pomdp.randomAction();
			//System.out.println("Action checking"+this.pomdp.randomAction());
			//DeltaIOTConnector.refsetcreation=true;
			Tuple<O,double[]> next = this.pomdp.performAction(act);
			//DeltaIOTConnector.refsetcreation=false;
			double[] b = this.pomdp.currentBelief();
			
			if(!this.contains(result, b)){
				result.add(b);
				if(DEBUG) {
					if(result.size()%25==0){
						System.out.print("+");
						System.out.flush();
					}
				}
			} else {
				//System.out.print("-");
			}
			
			if(this.pomdp.inTerminalState()){
				this.pomdp.reInitialize();
				/////////////////////////////////////////
				
			}
		}
		return result;
	}
}
