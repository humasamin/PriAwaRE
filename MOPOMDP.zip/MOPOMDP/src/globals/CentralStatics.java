package globals;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;

import value.*;

public class CentralStatics {
	private static Random r=null;
	private static int problemID = 0;
	
	public static Random getCentralRandom(){
		if(CentralStatics.r==null){
			CentralStatics.r = new Random(System.currentTimeMillis());
		}
		return r;
	}
	
	public static int getNextProblemIdentifier(){
		return ++problemID;
	}
	
	public static boolean weakParetoDominates(double[] x, double[] y){
		if(x.length!=y.length){
			System.err.println("unequal length Pareto test... crashing");
			System.exit(9);
		}
		for(int i=0; i<x.length; i++){
			if(y[i]>x[i]){
				return false;
			}
		}
		return true;
	}
	
	public static double innerProduct(double[] x, double[] y){
		if(x.length!=y.length){
			System.err.println("unequal length inner product... crashing");
			System.exit(10);
		}
		double result = 0;
		for(int i=0; i<x.length; i++){
			result += y[i]*x[i];
		}
		return result;
	}
	
	public static double euclDistance(double[] x, double[] y){
		if(x.length!=y.length){
			System.err.println("unequal length distance... crashing");
			System.exit(121);
		}
		double result = 0;
		for(int i=0; i<x.length; i++){
			result += (y[i]-x[i])*(y[i]-x[i]);
		}
		return Math.sqrt(result);
	}
	
	public static double[] addVec(double[] x, double[] y){
		/*if(x.length!=y.length){
			System.err.println("unequal length inner product... crashing");
			System.exit(10);
		}*/
		double[] result = new double[x.length];
		for(int i=0; i<x.length; i++){
			result[i] = y[i]+x[i];
		}
		return result;
	}
	
	public static String vecToString(double[] x){
		DecimalFormat df = new DecimalFormat("#.##");
		String result ="(";
			for(int i=0; i<x.length;i++){
				result+=df.format(x[i]);
				if(i!=x.length-1){
					result+=",";
				} else {
					result+=")";
				}
			}
		return result;
	}
	
	public static boolean equalVectors(double[] x, double[] y){
		if(x.length!=y.length){
			return false;
		}
		for(int i=0; i<x.length; i++){
			if(y[i]!=x[i]){return false;}
		}
		return true;
	}
	
	public static <V extends SimpleVector<?>> String vectorsTo2DROutput(ArrayList<V> list, String prefix){
		String lsX = ""+prefix+"X <- c(";
		String lsY = ""+prefix+"Y <- c(";
		for(int i=0; i<list.size(); i++){
			Vector vec = list.get(i);
			lsX+=vec.getValue(0);
			lsY+=vec.getValue(1);
			if( i!=(list.size()-1) ){
				lsX+=",";
				lsY+=",";
			}
		}
		return lsX+")\n"+lsY+")";
	}
}
