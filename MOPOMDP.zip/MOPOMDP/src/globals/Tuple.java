package globals;

public class Tuple<X,Y> {
	public X x;
	public Y y;

	public Tuple(X x_, Y y_){
		x=x_;
		y=y_;
	}
	
	@Override
    public int hashCode() {
        int hash = 1;
        hash = hash * 17 + x.hashCode();
        hash = hash * 31 + y.hashCode();
        return hash;
    }
}