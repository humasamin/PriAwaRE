

import globals.StopWatch;
import globals.Tuple;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import problems.Mopomdp;

import problems.rdmthreeobjectives.connected.*;
import rdm.management.NetworkManagment;
import rdm.management.RDMSimulator;
import solvers.linearsupport.LinearSupporter;
import solvers.linearsupport.RandomSampler;
import solvers.linearsupport.ReusingPerseusSolver;
import solvers.linearsupport.ValueVector;
import value.AlphaMatrix;
import value.CPruner;
import value.LazyScalarizedVector;
import value.SimpleVector;
import value.ValueAtBeliefVector;


public class ExperimentorRDMConnected<A, V, O, X, Y> {

	private StopWatch stopwatch;

	int rtnum,mstnum;
	Integer cstate;
	double cbelief[];

	//Model object
	MORDMThree mordm;
	ArrayList<ValueAtBeliefVector<Integer>> lst;
	
	ResultsLog res_log;



	public ExperimentorRDMConnected(){	
		this.stopwatch = StopWatch.getGlobalStopWatch();
		
		res_log=new ResultsLog();


	}

	public ArrayList<Double> emptyEpsilonMatrix(int length){
		ArrayList<Double> row = new ArrayList<Double>(length);
		for(int i=0; i<length; i++){
			row.add(new Double(0));
		}
		return row;
	}

	private double getMean(ArrayList<ArrayList<Double>> data, int index)
	{
		double sum = 0.0;
		for(ArrayList<Double> a  : data)
			sum += a.get(index);
		return sum/data.size();
	}

	private Tuple<Double,Double> getMeanVariance(ArrayList<ArrayList<Double>> data, int index)
	{
		double mean = getMean(data, index);
		double temp = 0;
		for(ArrayList<Double> a : data)
			temp += (mean-a.get(index))*(mean-a.get(index));
		double var = temp/(data.size());
		return new Tuple<Double,Double>(mean,var);
	}

	private Tuple<Double,Double> getMeanStdDev(ArrayList<ArrayList<Double>> data, int index)
	{
		Tuple<Double,Double> tup = getMeanVariance(data, index);
		return new Tuple<Double,Double>(tup.x,Math.sqrt(tup.y));
	}

	public ArrayList<Double> toEpsilon(ArrayList<SimpleVector<?>> vecs, ArrayList<SimpleVector<?>> refSet){
		ArrayList<Double> result = new ArrayList<Double>();
		ArrayList<SimpleVector<?>> part = new ArrayList<SimpleVector<?>>(vecs.size());
		for(int i=0; i<vecs.size(); i++){
			part.add(vecs.get(i));
			result.add(compareToRefSet(part, refSet));
		}
		return result;
	}

	public ArrayList<Double> epsilonTimeVector(ArrayList<Double> eps, ArrayList<Long> fromTimes, ArrayList<Long> toTimes){
		ArrayList<Double> result = new ArrayList<Double>(toTimes.size());
		long cTime; 
		int index = 0;
		for(int i=0; i<toTimes.size(); i++){
			cTime = toTimes.get(i);
			boolean b = true;
			while(b){
				if(index==(eps.size()-1)){
					b=false;
				} else {
					if(fromTimes.get(index+1)<cTime){
						index++;
					} else {
						b=false;
					}
				}
			}
			result.add(eps.get(index).doubleValue());
		}
		return result;
	}


	/////////////////////////////////////////////////////////////

	public <V extends SimpleVector<?>> boolean createRefSet(String filename, ArrayList<V> vecs){
		try {
			PrintWriter bw = new PrintWriter(new FileWriter(filename));
			System.out.println("value vector size"+vecs.size());
			for(int i=0; i<vecs.size(); i++){
				bw.println(vecs.get(i).toString()+"");
			}
			bw.flush();
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}


	@SuppressWarnings("resource")
	public ArrayList<SimpleVector<?>> readRefSetFromFile(String filename){
		ArrayList<String> sVecs = new ArrayList<String>();

		// wrap a BufferedReader around FileReader
		BufferedReader bufferedReader;
		try {
			bufferedReader = new BufferedReader(new FileReader(filename));
			while (bufferedReader.ready())
			{
				String line = bufferedReader.readLine();
				sVecs.add(line);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}

		ArrayList<SimpleVector<?>> refSet = new ArrayList<SimpleVector<?>>(sVecs.size());
		for(int i=0; i<sVecs.size(); i++){
			SimpleVector<Integer> sv = new SimpleVector<Integer>(sVecs.get(i));
			refSet.add(sv);
		}

		return refSet;
	}

	public double compareToRefSet(ArrayList<SimpleVector<?>> vecs, ArrayList<SimpleVector<?>> refSet){
		CPruner<SimpleVector<?>> cpr = new CPruner<SimpleVector<?>>();
		double highestLoss = Double.NEGATIVE_INFINITY;
		for(int i=0; i<refSet.size(); i++){
			double imp = cpr.findImprovement(refSet.get(i), vecs);
			if(imp>highestLoss){
				highestLoss = imp;
			}
		}
		return highestLoss;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////
	//@param dim3 boolean refers to the number of objectives true = 3 objectives and false=2 objectives
	public <A> boolean createRefSetRDMThreeConnected(boolean dim3){

		ReusingPerseusSolver.LOG = false;
		stopwatch.start();
		//double[] b0 = {0.3, 0, 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.4 };
		RDMStatesThree s=new RDMStatesThree();
		double[] b0=Mopomdp.uniformBelief(s);

		//double[] b0= {0.4,0.1,0.1,0.4};		
		mordm = new MORDMThree(dim3, b0, 0.9);
		//////////////////////////////////////////////////////////////////////

		//@param MOPOMDP, initial belief, nsamples 5000, maxiterations 500, precision 0.000001, type of perseus solver
		ReusingPerseusSolver<Integer,Integer,Integer> reuser = 
				new ReusingPerseusSolver<Integer,Integer,Integer>(mordm,b0,1000,500,0.0000001, ReusingPerseusSolver.TYPE_NONE);
		reuser.initSamples();
		int d3 = dim3? 3 : 2;

		//@param Reusing Perseus Solver, precision, stopcrit, number of objectives
		LinearSupporter<Integer> lstst = new LinearSupporter<Integer>(reuser, 0.0000001, 0.00001, d3);
		reuser.setCPSreference(lstst);

		
		lst = lstst.runLinearSupport(25000);

		for(int i=0;i<lstst.vvs.size();i++)
		{
			System.out.println(""+lstst.vvs.get(i).valueAtSearchWeights[0]);
			System.out.println(""+lstst.vvs.get(i).p.retrieveTags());
			System.out.println(""+lstst.vvs.get(i).p.getValue()[0]+" "+lstst.vvs.get(i).p.getValue()[1]+" "+lstst.vvs.get(i).p.getValue()[2]);

			System.out.println(""+lstst.vvs.get(i).searchWeights.get(0)[0]+"  "+lstst.vvs.get(i).searchWeights.get(0)[1]+" "+lstst.vvs.get(i).searchWeights.get(0)[2]);

		}

		boolean b = this.createRefSet("rdm"+d3+"refConnected.txt", lst);

		stopwatch.stop();
		System.out.println("rdm"+d3+"ref.txt created in "+ stopwatch.totalElapsedTime() + "ms");
		return b;
	}






	/////////////////////////////////////////////////////////////
	/////test RDM 3 NFRs
	public void testRDMThreeConnected(boolean dim3, 
			boolean type_none, boolean type_full, 
			boolean random_solver, boolean random_solver_without,
			long maxTime, int timeInterval, int bsetsize){

		

		ArrayList<SimpleVector<?>> refset;
		if(dim3)
			refset = readRefSetFromFile("rdm3refConnected.txt"); 
		else 
			refset = readRefSetFromFile("rdm2refConnected.txt"); 

		ReusingPerseusSolver.LOG = true;

		ArrayList<Long> times = new ArrayList<Long>(); 
		long time = 0; 
		while(time<maxTime){
			time+=timeInterval;
			times.add(time);
		}

		int repeat=1;


		int d3 = dim3? 3 : 2;


		ArrayList<Long> endTimesFull = new ArrayList<Long>(repeat);		
		ArrayList<Double> epsMeanFull = new ArrayList<Double>(repeat);		
		ArrayList<Double> epsStdvFull = new ArrayList<Double>(repeat);

		////////////////////////////////////
		// Set initial belief
		/////////////////////////////////////
		RDMStatesThree rs=new RDMStatesThree();
		double[] b0=Mopomdp.uniformBelief(rs);

		//Create MOPOMDP object--to represent the model
		mordm = new MORDMThree(dim3, b0, 0.9);

		//Declare an object of Persues Solver and LinearSupport
		ReusingPerseusSolver<Integer,Integer,Integer> reuser;
		LinearSupporter<Integer> lstst=null;

		//Variables to store current state and current belief
		cstate=mordm.currentState();
		cbelief=mordm.currentBelief;


		rtnum=0;
		mstnum=0;

		try {

			int devtotsteps;

			//Generate an initial deviation value and deviation timesteps
			int timestepcounter=0;
			RDMTransitionProb.deviation_timesteps = (int)(Math.random() * (RDMConfigurationConnected.deviation_timesteps_max- RDMConfigurationConnected.deviation_timesteps_min + 1) + RDMConfigurationConnected.deviation_timesteps_min);

			RDMTransitionProb.random_int = (int)(Math.random() * (RDMConfigurationConnected.deviation_max- RDMConfigurationConnected.deviation_min + 1) + RDMConfigurationConnected.deviation_min);
			RDMSimConnector.timestep=0;
			devtotsteps=RDMSimConnector.timestep+RDMTransitionProb.deviation_timesteps;

			for(RDMSimConnector.timestep=0;RDMSimConnector.timestep<RDMSimConnector.network_management.simulation_properties.getSimulationRuns();RDMSimConnector.timestep++)
			{
				//Stable scenario check
				if(RDMTransitionsThree.stable_scenario==false)
				{

					int todeviate=2;
					System.out.println(todeviate);

					if(todeviate==2)
					{
						RDMTransitionProb.deviation_timesteps = (int)(Math.random() * (RDMConfigurationConnected.deviation_timesteps_max- RDMConfigurationConnected.deviation_timesteps_min + 1) + RDMConfigurationConnected.deviation_timesteps_min);
						
						RDMTransitionProb.random_int = (int)(Math.random() * (RDMConfigurationConnected.deviation_max- RDMConfigurationConnected.deviation_min + 1) + RDMConfigurationConnected.deviation_min);
						timestepcounter=0;
						/////For case 3
						RDMTransitionProb.random_int1 = (int)(Math.random() * (RDMConfigurationConnected.deviation_max- RDMConfigurationConnected.deviation_min + 1) + RDMConfigurationConnected.deviation_min);
						RDMTransitionProb.random_int2 = (int)(Math.random() * (RDMConfigurationConnected.deviation_max- RDMConfigurationConnected.deviation_min + 1) + RDMConfigurationConnected.deviation_min);


					}
					else
					{
						RDMTransitionProb.deviation_timesteps = 0;
						RDMTransitionProb.random_int = 0;
						timestepcounter=0;

						RDMTransitionProb.random_int1 = 0;
						RDMTransitionProb.random_int2 = 0;
						System.out.println("no deviation for this timestep");


					}


				}////stable scenario check
				System.out.println("deviation:::::::::::::::::"+ RDMTransitionProb.random_int+" Time::::"+RDMTransitionProb.deviation_timesteps);

				System.out.println("timestep: "+RDMSimConnector.timestep);


				if(type_full){
					ArrayList<ArrayList<Double>> epsCollection = new ArrayList<ArrayList<Double>>(repeat);
					for(int i=0; i<repeat; i++){
						stopwatch.reset();
						System.out.println("running type full");
						ReusingPerseusSolver.resetMeasurement(true);

						/////checking
						System.out.print("checking Current Belief~~~~~~~~~~~~~~");
						for(int i1=0;i1<mordm.currentBelief().length;i1++)
						{
							System.out.print(mordm.currentBelief()[i1]+"  ");

						}

						System.out.println();


						res_log.res+="current belief: ";

						for(int i1=0;i1<mordm.currentBelief().length;i1++)
						{
							res_log.res+=mordm.currentBelief()[i1]+"  ";

						}
						res_log.res+="\n";

						//////Current Belief Marginilization to calculate satisfaction probabilities/////////////////////////////////////////////////////////////

						res_log.marginalizeCurrentBelief(mordm);
						//////////////////////////////////////////////////////////

						if(RDMSimConnector.timestep==0) {
							//cstate=mordm.currentState();
							reuser = new ReusingPerseusSolver<Integer,Integer,Integer>(mordm,b0,bsetsize,500,0.00000001, ReusingPerseusSolver.TYPE_FULL);

						}
						else {

							reuser = new ReusingPerseusSolver<Integer,Integer,Integer>(mordm,mordm.currentBelief,bsetsize,500,0.00000001, ReusingPerseusSolver.TYPE_FULL);

						}

						RDMSimConnector.refsetcreation=true;
						reuser.initSamples();
						RDMSimConnector.refsetcreation=false;
						lstst = new LinearSupporter<Integer>(reuser, RDMConfigurationConnected.precision, 0.00001, d3);
						reuser.setCPSreference(lstst);

						stopwatch.start();

						System.out.println("Max Time OLSAR: "+RDMConfigurationConnected.maxtime);
						lst = lstst.runLinearSupport(RDMConfigurationConnected.maxtime);


						ArrayList<SimpleVector<?>> veccies = ReusingPerseusSolver.valuelist; 
						refset.addAll(veccies);
						ArrayList<Long> timez = ReusingPerseusSolver.timelist; 
						endTimesFull.add(timez.get(timez.size()-1));
						System.out.print("f");
						ArrayList<Double> epss = this.toEpsilon(veccies, refset);
						ArrayList<Double> epssbis = this.epsilonTimeVector(epss, timez, times);
						epsCollection.add(epssbis);	


						RDMSimConnector.refsetcreation=false;


					}
					for(int i=0; i<times.size(); i++){
						Tuple<Double,Double> meanStdv = this.getMeanStdDev(epsCollection, i);
						epsMeanFull.add(meanStdv.x);
						epsStdvFull.add(meanStdv.y);
					}
					System.out.println("+");
				} else {
					for(int i=0; i<times.size(); i++){
						epsMeanFull.add(0.0);
						epsStdvFull.add(0.0);
					}
				}


				if(RDMSimConnector.timestep==0)//timestep check
				{

					//Display Epsilon Value (error value)
					System.out.println();
					for(int i=0; i<times.size(); i++){
						System.out.print(""+times.get(i)+" milliseconds ");
						System.out.print("Epsilon Mean: "+epsMeanFull.get(i)+", Epsilon Std Deviation: "+epsStdvFull.get(i)+",");

						System.out.println();
					}


					System.out.println();
					System.out.print("endFull <- c(");
					for(int i=0; i<endTimesFull.size(); i++){
						System.out.print(endTimesFull.get(i));
						if(i<endTimesFull.size()-1)
							System.out.print(",");
						else
							System.out.print(")");
					}
				}//end of timestep check



				//////checking max value at belief vector
				ArrayList<Double> maxxvall=new ArrayList<Double>();
				System.out.println("List size: "+lst.size());


				for(int i=0;i<lstst.vvs.size();i++)
				{
					System.out.println(""+lstst.vvs.get(i).valueAtSearchWeights[0]);
					System.out.println(""+lstst.vvs.get(i).p.retrieveTags());
					System.out.println(""+lstst.vvs.get(i).p.getValue()[0]+" "+lstst.vvs.get(i).p.getValue()[1]+" "+lstst.vvs.get(i).p.getValue()[2]);

					System.out.println(""+lstst.vvs.get(i).searchWeights.get(0)[0]+"  "+lstst.vvs.get(i).searchWeights.get(0)[1]+" "+lstst.vvs.get(i).searchWeights.get(0)[2]);
					lst.get(i).weight=lstst.vvs.get(i).searchWeights.get(0);
				}


				System.out.println("List size: "+lst.size());



				for(int i=0;i<lst.size();i++)
				{

					Double valvb=lst.get(i).linearScalValue(lst.get(i).weight);
					maxxvall.add(valvb);

				}

				double maxValue2 = maxxvall.get(0);
				for(int j=1;j < maxxvall.size();j++){
					if(maxxvall.get(j) > maxValue2){
						maxValue2 = maxxvall.get(j);
					}
				}

				for(int i=0;i<maxxvall.size();i++)
				{
					if(maxValue2==maxxvall.get(i))
					{ 



						System.out.println("###############################################################");
						System.out.println("selected weights :"+lst.get(i).weight[0]+" "+lst.get(i).weight[1]+" "+lst.get(i).weight[2]);
						System.out.println("selected action    tag :"+lst.get(i).retrieveTags().get(0));
						System.out.println("selected value    valuevec:"+lst.get(i).getValue()[0]+" "+lst.get(i).getValue()[1]+" "+lst.get(i).getValue()[2]);
						System.out.println("###############################################################");

						res_log.res+="Time Step: "+RDMSimConnector.timestep+" ";


						mordm.currentState=cstate.intValue();
						mordm.currentBelief=cbelief;

						res_log.res+="Current State: "+mordm.currentState()+"  ";




						System.out.println("Current State: "+mordm.currentState());
						if(lst.get(i).retrieveTags().get(0)!=null)
						{
							res_log.res+="Selected Action: "+lst.get(i).retrieveTags().get(0)+" ";


							mordm.performAction(lst.get(i).retrieveTags().get(0));

							if(lst.get(i).retrieveTags().get(0).equals(RDMActionsThree.MST))
							{
								mstnum++;
								res_log.mstnum=this.mstnum;
							}
							else
							{
								rtnum++;
								res_log.rtnum=this.rtnum;
							}

						}



						System.out.println(" new current state"+mordm.currentState());
						res_log.res+="Next State: "+mordm.currentState()+"  ";
						cstate=mordm.currentState();
						cbelief=mordm.currentBelief();




						System.out.println();


						res_log.res+=" value vector:"+lst.get(i).getValue()[0]+" "+lst.get(i).getValue()[1]+" "+" "+lst.get(i).getValue()[2];
						res_log.res+="  selected weights"+lst.get(i).weight[0]+" "+lst.get(i).weight[1]+" "+lst.get(i).weight[2]+" ";
						res_log.outputResultLog(res_log.res);

						res_log.res="";
					}

				}
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				System.out.println("vb scalarized maxValuelsssssss:  "+maxValue2);

				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

				lst.clear();
				maxxvall.clear();



			}//End of timestep for loop

			System.out.println("RT:  "+rtnum+"  MST: "+mstnum);	 

			//close connection to files
			res_log.closeConn();

		}catch(IOException ioex)
		{
			ioex.printStackTrace();

		}		




	}




	/////////////////////////////////////////////////////////////
	/////test RDM 3 NFRs
	public void testRDMThreeConnectedOLS(boolean dim3, 
			boolean type_none, boolean type_full, 
			boolean random_solver, boolean random_solver_without,
			long maxTime, int timeInterval, int bsetsize){

		

		ArrayList<SimpleVector<?>> refset;
		if(dim3)
			refset = readRefSetFromFile("rdm3refConnected.txt"); 
		else 
			refset = readRefSetFromFile("rdm2refConnected.txt"); 

		ReusingPerseusSolver.LOG = true;

		ArrayList<Long> times = new ArrayList<Long>(); 
		long time = 0; 
		while(time<maxTime){
			time+=timeInterval;
			times.add(time);
		}

		int repeat=1;

		int d3 = dim3? 3 : 2;


		ArrayList<Long> endTimesNone = new ArrayList<Long>(repeat);
		ArrayList<Double> epsMeanNone = new ArrayList<Double>(repeat);
		ArrayList<Double> epsStdvNone = new ArrayList<Double>(repeat);


		////////////////////////////////////
		// Set initial belief
		/////////////////////////////////////
		RDMStatesThree rs=new RDMStatesThree();
		double[] b0=Mopomdp.uniformBelief(rs);

		//Create MOPOMDP object--to represent the model
		mordm = new MORDMThree(dim3, b0, 0.9);

		//Declare an object of Persues Solver and LinearSupport
		ReusingPerseusSolver<Integer,Integer,Integer> reuser;
		LinearSupporter<Integer> lstst=null;

		//Variables to store current state and current belief
		cstate=mordm.currentState();
		cbelief=mordm.currentBelief;


		rtnum=0;
		mstnum=0;
		try {


			int devtotsteps;

			//Generate an initial deviation value and deviation timesteps
			int timestepcounter=0;
			RDMTransitionProb.deviation_timesteps = (int)(Math.random() * (RDMConfigurationConnected.deviation_timesteps_max- RDMConfigurationConnected.deviation_timesteps_min + 1) + RDMConfigurationConnected.deviation_timesteps_min);
			//RDMTransitionProb.deviation_timesteps = 0;
			RDMTransitionProb.random_int = (int)(Math.random() * (RDMConfigurationConnected.deviation_max- RDMConfigurationConnected.deviation_min + 1) + RDMConfigurationConnected.deviation_min);
			RDMSimConnector.timestep=0;
			devtotsteps=RDMSimConnector.timestep+RDMTransitionProb.deviation_timesteps;




			for(RDMSimConnector.timestep=0;RDMSimConnector.timestep<RDMSimConnector.network_management.simulation_properties.getSimulationRuns();RDMSimConnector.timestep++)
			{


				if(RDMTransitionsThree.stable_scenario==false)
				{

					int todeviate=2;
					System.out.println(todeviate);

					if(todeviate==2)
					{
						RDMTransitionProb.deviation_timesteps = (int)(Math.random() * (RDMConfigurationConnected.deviation_timesteps_max- RDMConfigurationConnected.deviation_timesteps_min + 1) + RDMConfigurationConnected.deviation_timesteps_min);
						//RDMTransitionProb.deviation_timesteps = 100;
						RDMTransitionProb.random_int = (int)(Math.random() * (RDMConfigurationConnected.deviation_max- RDMConfigurationConnected.deviation_min + 1) + RDMConfigurationConnected.deviation_min);
						timestepcounter=0;
						/////For case 3
						RDMTransitionProb.random_int1 = (int)(Math.random() * (RDMConfigurationConnected.deviation_max- RDMConfigurationConnected.deviation_min + 1) + RDMConfigurationConnected.deviation_min);
						RDMTransitionProb.random_int2 = (int)(Math.random() * (RDMConfigurationConnected.deviation_max- RDMConfigurationConnected.deviation_min + 1) + RDMConfigurationConnected.deviation_min);


					}
					else
					{
						RDMTransitionProb.deviation_timesteps = 0;
						RDMTransitionProb.random_int = 0;
						timestepcounter=0;

						RDMTransitionProb.random_int1 = 0;
						RDMTransitionProb.random_int2 = 0;
						System.out.println("no deviation for this timestep");


					}


				}////stable scenario check

				System.out.println("deviation:::::::::::::::::"+ RDMTransitionProb.random_int+" Time::::"+RDMTransitionProb.deviation_timesteps);
				System.out.println("timestep: "+RDMSimConnector.timestep);

				if(type_none){
					ArrayList<ArrayList<Double>> epsCollection = new ArrayList<ArrayList<Double>>(repeat);
					for(int i=0; i<repeat; i++){
						stopwatch.reset();
						System.out.println("running type none");
						ReusingPerseusSolver.resetMeasurement(true);

						/////checking
						System.out.print("checking Current Belief~~~~~~~~~~~~~~");
						for(int i1=0;i1<mordm.currentBelief().length;i1++)
						{
							System.out.print(mordm.currentBelief()[i1]+"  ");

						}

						System.out.println();


						res_log.res+="current belief: ";

						for(int i1=0;i1<mordm.currentBelief().length;i1++)
						{
							res_log.res+=mordm.currentBelief()[i1]+"  ";

						}
						res_log.res+="\n";

						//////Current Belief Marginilization/////////////////////////////////////////////////////////////
						res_log.marginalizeCurrentBelief(mordm);

						////////////////////////////////////////////////////////////////////////////////////////////////

						reuser = new ReusingPerseusSolver<Integer,Integer,Integer>(mordm,mordm.currentBelief,bsetsize,500,0.00000001, ReusingPerseusSolver.TYPE_NONE);
						RDMSimConnector.refsetcreation=true;
						reuser.initSamples();
						RDMSimConnector.refsetcreation=false;
						lstst = new LinearSupporter<Integer>(reuser, RDMConfigurationConnected.precision, 0.00001, d3);
						reuser.setCPSreference(lstst);
						stopwatch.start();
						lst = lstst.runLinearSupport(RDMConfigurationConnected.maxtime);
						ArrayList<SimpleVector<?>> veccies = ReusingPerseusSolver.valuelist; 
						ArrayList<Long> timez = ReusingPerseusSolver.timelist; 
						endTimesNone.add(timez.get(timez.size()-1));
						System.out.print("n");
						ArrayList<Double> epss = this.toEpsilon(veccies, refset);
						ArrayList<Double> epssbis = this.epsilonTimeVector(epss, timez, times);
						epsCollection.add(epssbis);	


						RDMSimConnector.refsetcreation=false;

					}
					for(int i=0; i<times.size(); i++){
						Tuple<Double,Double> meanStdv = this.getMeanStdDev(epsCollection, i);
						epsMeanNone.add(meanStdv.x);
						epsStdvNone.add(meanStdv.y);
					}
					System.out.println("+");
				} else {
					for(int i=0; i<times.size(); i++){
						epsMeanNone.add(0.0);
						epsStdvNone.add(0.0);
					}
				}

				if(RDMSimConnector.timestep==0)//timestep check
				{

					//Display Epsilon Value (error value)
					System.out.println();
					for(int i=0; i<times.size(); i++){
						System.out.print(""+times.get(i)+" milliseconds ");
						System.out.print("Epsilon Mean: "+epsMeanNone.get(i)+", Epsilon Std Deviation: "+epsStdvNone.get(i)+",");

						System.out.println();
					}
				}//End of timestep check


				//////checking max value at belief vector
				ArrayList<Double> maxxvall=new ArrayList<Double>();
				System.out.println("List size: "+lst.size());


				for(int i=0;i<lstst.vvs.size();i++)
				{
					System.out.println(""+lstst.vvs.get(i).valueAtSearchWeights[0]);
					System.out.println(""+lstst.vvs.get(i).p.retrieveTags());
					System.out.println(""+lstst.vvs.get(i).p.getValue()[0]+" "+lstst.vvs.get(i).p.getValue()[1]+" "+lstst.vvs.get(i).p.getValue()[2]);

					System.out.println(""+lstst.vvs.get(i).searchWeights.get(0)[0]+"  "+lstst.vvs.get(i).searchWeights.get(0)[1]+" "+lstst.vvs.get(i).searchWeights.get(0)[2]);
					lst.get(i).weight=lstst.vvs.get(i).searchWeights.get(0);
				}


				System.out.println("List size: "+lst.size());



				for(int i=0;i<lst.size();i++)
				{					
					Double valvb=lst.get(i).linearScalValue(lst.get(i).weight);
					maxxvall.add(valvb);

				}

				double maxValue2 = maxxvall.get(0);
				for(int j=1;j < maxxvall.size();j++){
					if(maxxvall.get(j) > maxValue2){
						maxValue2 = maxxvall.get(j);
					}
				}

				for(int i=0;i<maxxvall.size();i++)
				{
					if(maxValue2==maxxvall.get(i))
					{ 



						System.out.println("###############################################################");
						System.out.println("selected weights :"+lst.get(i).weight[0]+" "+lst.get(i).weight[1]+" "+lst.get(i).weight[2]);
						System.out.println("selected action    tag :"+lst.get(i).retrieveTags().get(0));
						System.out.println("selected value    valuevec:"+lst.get(i).getValue()[0]+" "+lst.get(i).getValue()[1]+" "+lst.get(i).getValue()[2]);
						System.out.println("###############################################################");

						res_log.res+="Time Step: "+RDMSimConnector.timestep+" ";

						mordm.currentState=cstate.intValue();
						mordm.currentBelief=cbelief;

						res_log.res+="Current State: "+mordm.currentState()+"  ";

						System.out.println("Current State: "+mordm.currentState());
						if(lst.get(i).retrieveTags().get(0)!=null)
						{
							res_log.res+="Selected Action: "+lst.get(i).retrieveTags().get(0)+" ";

							mordm.performAction(lst.get(i).retrieveTags().get(0));

							if(lst.get(i).retrieveTags().get(0).equals(RDMActionsThree.MST))
							{
								mstnum++;
								res_log.mstnum=this.mstnum;
							}
							else
							{
								rtnum++;
								res_log.rtnum=this.rtnum;
							}

						}



						System.out.println(" new current state"+mordm.currentState());
						res_log.res+="Next State: "+mordm.currentState()+"  ";
						cstate=mordm.currentState();
						cbelief=mordm.currentBelief();


						System.out.println();


						res_log.res+=" value vector:"+lst.get(i).getValue()[0]+" "+lst.get(i).getValue()[1]+" "+" "+lst.get(i).getValue()[2];
						res_log.res+="  selected weights"+lst.get(i).weight[0]+" "+lst.get(i).weight[1]+" "+lst.get(i).weight[2]+" ";
						res_log.outputResultLog(res_log.res);

						res_log.res="";

					}

				}
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				System.out.println("vb scalarized maxValuelsssssss:  "+maxValue2);

				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

				lst.clear();
				maxxvall.clear();


			}//End of timestep for loop

			System.out.println("RT:  "+rtnum+"  MST: "+mstnum);	 


			//closing connection to files
			res_log.closeConn();


		}catch(IOException ioex)
		{
			ioex.printStackTrace();

		}		

	}


	

}