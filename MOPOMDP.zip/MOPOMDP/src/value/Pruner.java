package value;

import java.util.ArrayList;

public interface Pruner<V extends SimpleVector<?>> {
	public ArrayList<V> prune(ArrayList<V> in); 
}
