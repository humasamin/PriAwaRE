package value;

import globals.CentralStatics;

import java.util.ArrayList;

public class ParetoPruner<V extends SimpleVector<?>> implements Pruner<V>{

	@Override
	public ArrayList<V> prune(ArrayList<V> in) {
		ArrayList<V> uset = in;
		ArrayList<V> result = new ArrayList<V>(uset.size());
		while(!uset.isEmpty()){
			V u = uset.get(0);
			for(int i=1; i<uset.size();i++){
				V v = uset.get(i);
				if(CentralStatics.weakParetoDominates(v.getValue(), u.getValue())){
					u=v;
				}
			}
			ArrayList<V> uset2 = new ArrayList<V>(uset.size());
			for(int i=0; i<uset.size();i++){
				V v = uset.get(i);
				if(!CentralStatics.weakParetoDominates(u.getValue(), v.getValue())){
					uset2.add(v);
				}
			}
			result.add(u);
			uset=uset2;
		}
		return result;
	}

}
