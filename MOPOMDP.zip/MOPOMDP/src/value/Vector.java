package value;

import java.util.Iterator;

public interface Vector extends Iterable<Double>, Iterator<Double>{
	
	public double   linearScalValue(double[] wvec);
	public boolean  equalValues(Vector v);
	public boolean  weakParetoDominates(Vector v);
	public boolean  paretoDominates(Vector v);
	public void     setValue(double[] vec);
	public double[] getValue();
	public int      length();
	public void     setValue(int i, double val);
	public double   getValue(int i);
	public Vector   zeroVector();
	public Vector   linearTransformation(double[][] trans);
	public void     multiplyByScalar(double scalar);
	public String   className();
}
