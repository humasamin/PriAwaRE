package value;

import java.util.ArrayList;

public interface Taggable<T> {

	public void tag(T t);
	public void tag(ArrayList<T> tl);
	public ArrayList<T> retrieveTags();
}
