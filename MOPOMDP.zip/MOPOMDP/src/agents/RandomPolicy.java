package agents;

import problems.Actions;

public class RandomPolicy<A> implements Policy<A> {

	private Actions<A> actionSpace;
	
	public RandomPolicy(Actions<A> actionSpace_){
		this.actionSpace = actionSpace_;
	}
	
	@Override
	public A getAction(double[] belief) {
		return actionSpace.randomAction();
	}
}
