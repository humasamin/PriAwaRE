package agents;

public interface Policy<A> {
	public A getAction(double[] belief);
}
